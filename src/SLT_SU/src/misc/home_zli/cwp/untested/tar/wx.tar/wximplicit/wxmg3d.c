/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

This software performs 
/* w-x 90-degree 3-d poststack migration  */
/*     features:
		up-to 90 degree accuracy
		absorbing boundaries
		dispersion suppression
		stable
		implicit f.d. scheme
		splitting method used 
		f.d. errors compensation
