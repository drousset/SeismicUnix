/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include <stdio.h>
main()
{
	printf("%.4g %.4g %.4g %.4g %.4g %.4g\n",
		0.9999,9.999,99.99,999.9,9999.0,99990.0);
}
