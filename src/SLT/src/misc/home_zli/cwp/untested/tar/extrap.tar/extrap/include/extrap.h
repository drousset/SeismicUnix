/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

/* include file for extrapolation functions */

#ifndef EXTRAP_H
#define EXTRAP_H


/* INCLUDES */
#include "cwp.h"


/* TYPEDEFS */
typedef struct _eTableStruct { /* extrapolator table */
	int nhmax;	/* maximum half-length of extrapolators */
	int nwdxov;	/* number of frequency*dx/velocity values */
	float dwdxov;	/* frequency*dx/velocity sampling interval */
	float fwdxov;	/* first frequency*dx/velocity */
	float dzodx;	/* ratio of z to x sampling intervals:  dz/dx */
	int *nh;	/* array[nwdxov] of half-lengths of extrapolators */
	complex **e;	/* array[nwdxov][nhmax] of extrapolators */
} eTable;


/* FUNCTIONS */
eTable *etmake (int nwdxov, float dwdxov, float fwdxov,
	float dzodx, int nhmax, int optimal);
eTable *etread (FILE *fp);
void etwrite (eTable *et, FILE *fp);
void etextrap (eTable *et, int nx, float wdxov[], complex q[]);
void etextrap2 (eTable *et, int nx, int ny, float **wdxov, complex **q);

#endif /* EXTRAP_H */
