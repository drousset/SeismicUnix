/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"
#include "par.h"

char *sdoc =
"DUMPET - DUMP Extrapolator Table\n"
"\n"
"dumpet <infile [optional parameters]\n"
"\n"
"Optional Parameters:\n"
"efile=NONE              name of file to contain extrapolators\n"
"afile=NONE              name of file to contain amplitude errors\n"
"pfile=NONE              name of file to contain phase errors\n"
"nhfile=NONE             name of file to contain half-lengths\n"
"nangle=nwdxov           number of angles at which to compute\n"
"                        and output amplitude and phase errors\n"
"\n";

/* main program */
main (int argc, char **argv)
{
	int nhmax,nwdxov,iwdxov,nangle,iangle,nk,ik,nfft,i,nhi;
	float dzodx,dwdxov,fwdxov,wdxov,fnh,dk,fk,k,
		phase,phlast,phbase,phexa,
		dangle,fangle,angle,*kk,*ak,*pk,*aerr,*perr;
	complex *ex,*ek;
	char *efile="",*afile="",*pfile="",*nhfile="";
	FILE *infp=stdin,*outfp=stdout,*efp,*afp,*pfp,*nhfp;
	eTable *et;
	
	/* hook up getpar to handle parameters */
	initargs(argc,argv);
	askdoc(0);
	
	/* get optional parameters */
	getparstring("efile",&efile);
	getparstring("afile",&afile);
	getparstring("pfile",&pfile);
	getparstring("nhfile",&nhfile);
	
	/* read extrapolator table */
	et = etread(infp);
	nhmax = et->nhmax;
	nwdxov = et->nwdxov;
	dwdxov = et->dwdxov;
	fwdxov = et->fwdxov;
	dzodx = et->dzodx;
	
	/* print constants */
	fprintf(outfp,"Extrapolator table:\n");
	fprintf(outfp,"\tMaximum half-width (nhmax) = %d\n",nhmax);
	fprintf(outfp,"\tNumber of wdx/v (nwdxov) = %d\n",nwdxov);
	fprintf(outfp,"\tIncrement in wdx/v (dwdxov) = %g\n",dwdxov);
	fprintf(outfp,"\tFirst wdx/v (fwdxov) = %g\n",fwdxov);
	fprintf(outfp,"\tRatio dz/dx (dzodx) = %g\n",dzodx);
	
	/* if requested, write extrapolators */
	if (efile[0]!='\0') {
		efp = fopen(efile,"w");
		fwrite(et->e[0],sizeof(complex),nhmax*nwdxov,efp);
		fclose(efp);
	}
	
	/* if requested, write half-lengths */
	if (nhfile[0]!='\0') {
		nhfp = fopen(nhfile,"w");
		for (iwdxov=0; iwdxov<nwdxov; iwdxov++) {
			fnh = et->nh[iwdxov];
			fwrite(&fnh,sizeof(float),1,nhfp);
		}
		fclose(nhfp);
	}
	
	/* if requested, compute and write amplitude and/or phase errors */
	if (afile[0]!='\0' || pfile[0]!='\0') {
		if (!getparint("nangle",&nangle)) nangle = nwdxov;
		dangle = PI/2/(nangle-1);
		fangle = 0.0;
		nfft = npfa(8*2*nangle);
		nk = nfft/2+1;
		dk = 2.0*PI/nfft;
		fk = 0.0;
		afp = (afile[0]!='\0' ? fopen(afile,"w") : NULL);
		pfp = (pfile[0]!='\0' ? fopen(pfile,"w") : NULL);
		ek = ex = alloc1complex(nfft);
		kk = alloc1float(nk);
		ak = alloc1float(nk);
		pk = alloc1float(nk);
		aerr = alloc1float(nangle);
		perr = alloc1float(nangle);
		for (ik=0,k=fk; ik<nk; ik++,k+=dk)
			kk[ik] = k;
		for (iwdxov=0,wdxov=fwdxov; 
			iwdxov<nwdxov;
			iwdxov++,wdxov+=dwdxov) {
			nhi = et->nh[iwdxov];
			for (i=0; i<nhi; i++)
				ex[i] = et->e[iwdxov][i];
			for (i=1; i<nhi; i++)
				ex[nfft-i] = ex[i];
			for (i=nhi; i<=nfft-nhi; i++)
				ex[i] = cmplx(0.0,0.0);
			pfacc(-1,nfft,ex);
			phase = phlast = phbase = 0.0;
			for (ik=0,k=fk; ik<nk; ik++,k+=dk) {
				ak[ik] = pow(fcabs(ek[ik]),1.0/dzodx)-1.0;
				if (k<=wdxov) {
					phase = atan2(ek[ik].i,ek[ik].r);
					if (phase<phlast-PI)
						phbase += 2*PI;
					else if (phase>phlast+PI)
						phbase -= 2*PI;
					phlast = phase;
					phase += phbase;
					phexa = dzodx*
						(wdxov-sqrt(wdxov*wdxov-k*k));
					pk[ik] = (phase-phexa)/dzodx;
				} else {
					pk[ik] = pk[ik-1];
				}
			}
			for (iangle=0,angle=fangle;
				iangle<nangle;
				iangle++,angle+=dangle) {
				k = wdxov*sin(angle);
				intlin(nk,kk,ak,ak[0],ak[nk-1],
					1,&k,&aerr[iangle]);
				intlin(nk,kk,pk,pk[0],pk[nk-1],
					1,&k,&perr[iangle]);
			}
					
			if (afp!=NULL) fwrite(aerr,sizeof(float),nangle,afp);
			if (pfp!=NULL) fwrite(perr,sizeof(float),nangle,pfp);
		}
		if (afp!=NULL) fclose(afp);
		if (pfp!=NULL) fclose(pfp);
		free1complex(ex);
		free1float(ak);
		free1float(pk);
		free1float(aerr);
		free1float(perr);
	}

	exit(0);
}
