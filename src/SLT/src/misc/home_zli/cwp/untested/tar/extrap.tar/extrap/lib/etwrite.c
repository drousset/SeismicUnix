/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"

void etwrite (eTable *et, FILE *fp)
/*****************************************************************************
write and deallocate an extrapolator table
******************************************************************************
Input:
et		pointer to extrapolator table
fp		file pointer to file to contain extrapolator table
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 11/24/89
******************************************************************************/
{	
	/* write table values */
	fwrite(&et->nhmax,sizeof(int),1,fp);
	fwrite(&et->nwdxov,sizeof(int),1,fp);
	fwrite(&et->dwdxov,sizeof(float),1,fp);
	fwrite(&et->fwdxov,sizeof(float),1,fp);
	fwrite(&et->dzodx,sizeof(float),1,fp);
	fwrite(et->nh,sizeof(int),et->nwdxov,fp);
	fwrite(et->e[0],sizeof(complex),et->nwdxov*et->nhmax,fp);
	
	/* deallocate space */
	free1int(et->nh);
	free2complex(et->e);
	free(et);
}
