/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"

void etextrap (eTable *et, int nx, float wdxov[], complex q[])
/*****************************************************************************
Extrapolation for one frequency via an extrapolator table
******************************************************************************
Input:
et		pointer to extrapolator table
nx		number of samples in wavefield
wdxov		array[nx] of frequency*dx/velocity values
q		array[nx] containing current wavefield

Output:
q		array[nx] containing extrapolated wavefield
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 02/19/90
******************************************************************************/
{
	int ix,je,iwdxov,ne,nxpad,
		nwdxov=et->nwdxov,*nh=et->nh,nhmax=et->nhmax;
	float phase,*pr,*pi,spr,spi,qr,qi,er,ei,wdxovn,
		dwdxov=et->dwdxov,fwdxov=et->fwdxov,dzodx=et->dzodx;
	complex **e=et->e;
	
	/* allocate workspace */
	nxpad = nhmax-1+nx+nhmax-1;
	pr = alloc1float(nxpad);
	pi = alloc1float(nxpad);
	
	/* zero workspace and adjust pointers for zero padding */
	for (ix=0; ix<nxpad; ++ix)
		pr[ix] = pi[ix] = 0.0;
	pr += nhmax-1;
	pi += nhmax-1;
	
	/* copy input to zero-padded workspace */
	for (ix=0; ix<nx; ++ix) {
		pr[ix] = q[ix].r;
		pi[ix] = q[ix].i;
	}
		
	/* loop over output samples */
	for (ix=0; ix<nx; ix++) {
	
		/* compute pointer to extrapolator coefficients */
		wdxovn = (wdxov[ix]-fwdxov)/dwdxov;
		iwdxov = NINT(wdxovn);
		if (iwdxov<0) iwdxov = 0;
		if (iwdxov>=nwdxov) iwdxov = nwdxov-1;
		ne = nh[iwdxov];
		
		/* extrapolate with focusing term */
		spr = pr[ix];  spi = pi[ix];
		er = e[iwdxov][0].r;  ei = e[iwdxov][0].i;
		qr = er*spr-ei*spi;  qi = er*spi+ei*spr;
		for (je=1; je<ne; ++je) {
			spr = pr[ix+je]+pr[ix-je];
			spi = pi[ix+je]+pi[ix-je];
			er = e[iwdxov][je].r;
			ei = e[iwdxov][je].i;
			qr += er*spr-ei*spi;
			qi += er*spi+ei*spr;
		}
		
		/* extrapolate with shifting term */
		phase = -dzodx*wdxov[ix];
		er = cos(phase);  ei = sin(phase);
		q[ix].r = qr*er-qi*ei;
		q[ix].i = qr*ei+qi*er;
	}
	
	/* adjust workspace pointers and free workspace */
	pr -= nhmax-1;
	pi -= nhmax-1;
	free1float(pr);
	free1float(pi);
}
