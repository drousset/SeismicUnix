/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "par.h"

char *sdoc =
"MAKEVEL - MAKE a VELocity function v(x,y,z)"
"\n"
"makevel >outfile nx= nz= [optional parameters]\n"
"\n"
"Required Parameters:\n"
"nx=                    number of x samples (3rd dimension)\n"
"nz=                    number of z samples (1st dimension)\n"
"\n"
"Optional Parameters:\n"
"ny=1                   number of y samples (2nd dimension)\n"
"dx=1.0                 x sampling interval\n"
"fx=0.0                 first x sample\n"
"dy=1.0                 y sampling interval\n"
"fy=0.0                 first y sample\n"
"dz=1.0                 z sampling interval\n"
"fz=0.0                 first z sample\n"
"v000=2.0               velocity at (x=0,y=0,z=0)\n"
"dvdx=0.0               velocity gradient with respect to x\n"
"dvdy=0.0               velocity gradient with respect to y\n"
"dvdz=0.0               velocity gradient with respect to z\n"
"vlens=0.0              velocity perturbation in parabolic lens\n"
"tlens=0.0              thickness of parabolic lens\n"
"dlens=0.0              diameter of parabolic lens\n"
"xlens=                 x coordinate of center of parabolic lens\n"
"ylens=                 y coordinate of center of parabolic lens\n"
"zlens=                 z coordinate of center of parabolic lens\n"
"vran=0.0		standard deviation of random perturbation\n"
"vzfile=                file containing v(z) profile\n"
"\n";

main (int argc, char **argv)
{
	int nx,ny,nz,ix,iy,iz;
	float dx,dy,dz,fx,fy,fz,x,y,z,v000,dvdx,dvdy,dvdz,
		xlens,ylens,zlens,dlens,tlens,vlens,
		abot,bbot,zbot,atop,btop,ztop,vran,
		*v,*vz;
	char *vzfile="";
	FILE *outfp=stdout,*vzfp;

	/* hook up getpar to handle the parameters */
	initargs(argc,argv);
	askdoc(0);
	
	/* get required parameters */
	if (!igetpar("nx",&nx)) err("must specify nx!\n");
	if (!igetpar("nz",&nz)) err("must specify nz!\n");
	
	/* get optional parameters */
	if (!igetpar("ny",&ny)) ny = 1;
	if (!fgetpar("dx",&dx)) dx = 1.0;
	if (!fgetpar("dy",&dy)) dy = 1.0;
	if (!fgetpar("dz",&dz)) dz = 1.0;
	if (!fgetpar("fx",&fx)) fx = 0.0;
	if (!fgetpar("fy",&fy)) fy = 0.0;
	if (!fgetpar("fz",&fz)) fz = 0.0;
	if (!fgetpar("v000",&v000)) v000 = 2.0;
	if (!fgetpar("dvdx",&dvdx)) dvdx = 0.0;
	if (!fgetpar("dvdy",&dvdy)) dvdy = 0.0;
	if (!fgetpar("dvdz",&dvdz)) dvdz = 0.0;
	if (!fgetpar("xlens",&xlens)) xlens = fx;
	if (!fgetpar("ylens",&ylens)) ylens = fy;
	if (!fgetpar("zlens",&zlens)) zlens = fz;
	if (!fgetpar("vlens",&vlens)) vlens = 0.0;
	if (!fgetpar("dlens",&dlens)) dlens = 1.0;
	if (!fgetpar("tlens",&tlens)) tlens = 0.0;
	if (!fgetpar("vran",&vran)) vran = 0.0;
	sgetpar("vzfile",&vzfile);
	
	/* compute lens constant */
	abot = zlens-tlens/2.0;
	bbot = 2.0*tlens/(dlens*dlens);
	atop = zlens+tlens/2;
	btop = -2.0*tlens/(dlens*dlens);
	
	/* allocate space */
	v = alloc1float(nz);
	vz = alloc1float(nz);
	
	/* if specified, read v(z) profile; otherwise, zero v(z) profile */
	if (vzfile[0]!='\0') {
		if ((vzfp=fopen(vzfile,"r"))==NULL)
			err("error opening vzfile=%s",vzfile);
		if (fread(vz,sizeof(float),nz,vzfp)!=nz)
			err("error reading vzfile=%s",vzfile);
		fclose(vzfp);
	} else {
		for (iz=0; iz<nz; ++iz)
			vz[iz] = 0.0;
	}

	/* loop over x */
	for (ix=0,x=fx; ix<nx; ++ix,x+=dx) {
	
		/* loop over y */
		for (iy=0,y=fy; iy<ny; ++iy,y+=dy) {
		
			/* compute top and bottom of lens */
			ztop = atop+btop*(pow(x-xlens,2)+pow(y-ylens,2));
			zbot = abot+bbot*(pow(x-xlens,2)+pow(y-ylens,2));
			
			/* loop over z */
			for (iz=0,z=fz; iz<nz; ++iz,z+=dz) {
				
				/* constant + constant gradient */
				v[iz] = v000+x*dvdx+y*dvdy+z*dvdz;
				
				/* v(z) profile */
				v[iz] += vz[iz];
				
				/* lens */
				if (z>zbot && z<ztop) v[iz] += vlens;

				/* random perturbation */
				v[iz] += vran*frannor();
			}
			
			/* write velocity function */
			fwrite(v,sizeof(float),nz,outfp);
		}
	}
	
	/* free space before returning */
	free1float(v);
	free1float(vz);
	return 0;
}
