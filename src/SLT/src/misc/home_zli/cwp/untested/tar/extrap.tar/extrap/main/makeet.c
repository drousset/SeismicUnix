/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"
#include "par.h"

char *sdoc =
"MAKEET - MAKE Extrapolator Table\n"
"\n"
"makeet >outfile nhmax= ntable= [optional parameters]\n"
"\n"
"Required Parameters:\n"
"nhmax                  maximum extrapolator half-length\n"
"ntable                 number of extrapolators to tabulate\n"
"\n"
"Optional Parameters:\n"
"dz=1.0                 depth sampling interval (extrapolation distance)\n"
"dx=1.0                 spatial sampling interval\n"
"fmin=0.0               minimum frequency (in cycles per unit time)\n"
"fmax=0.5               maximum frequency (in cycles per unit time)\n"
"vmin=2*dz*fmax         minimum velocity (default avoids aliasing)\n"
"vmax=vmin              maximum velocity\n"
"opt=1                  =1 to optimize half-length; =0 to always use nhmax\n"
"\n"
"Note:  use half-velocities for vmin and vmax if table will be used for\n"
"       zero-offset (exploding reflectors) migration\n"
"\n";

/* main program */
main (int argc, char **argv)
{
	int nhmax,ntable,nwdxov,opt;
	float dz,dx,fmin,fmax,vmin,vmax,dwdxov,fwdxov,ewdxov;
	FILE *outfp=stdout;
	eTable *et;
	
	/* hook up getpar to handle parameters */
	initargs(argc,argv);
	
	/* get required parameters */
	if (!getparint("nhmax",&nhmax)) selfdoc();
	if (!getparint("ntable",&ntable)) selfdoc();
	
	/* get optional parameters */
	if (!getparfloat("dz",&dz)) dz = 1.0;
	if (!getparfloat("dx",&dx)) dx = 1.0;
	if (!getparfloat("fmin",&fmin)) fmin = 0.0;
	if (!getparfloat("fmax",&fmax)) fmax = 0.5;
	if (!getparfloat("vmin",&vmin)) vmin = 2.0*dz*fmax;
	if (!getparfloat("vmax",&vmax)) vmax = vmin;
	if (!getparint("opt",&opt)) opt = 1;
	
	/* determine frequency/velocity sampling */
	fwdxov = 2.0*PI*fmin/vmax*dx;
	ewdxov = 2.0*PI*fmax/vmin*dx;
	dwdxov = (ewdxov-fwdxov)/MAX(1,ntable-1);
	nwdxov = ntable;
	
	/* make extrapolator table */
	et = etmake(nwdxov,dwdxov,fwdxov,dz/dx,nhmax,opt);

	/* write extrapolator table */
	etwrite(et,outfp);

	exit(0);
}
