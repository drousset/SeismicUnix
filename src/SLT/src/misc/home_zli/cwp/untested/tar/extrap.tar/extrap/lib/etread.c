/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"

eTable *etread (FILE *fp)
/*****************************************************************************
read and return a pointer to an extrapolator table stored in a file
******************************************************************************
Input:
fp		file pointer to file containing extrapolator table
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 11/24/89
******************************************************************************/
{
	int nhmax,nwdxov,*nh;
	float dwdxov,fwdxov,dzodx;
	complex **e;
	eTable *et;
	
	/* read table values */
	fread(&nhmax,sizeof(int),1,fp);
	fread(&nwdxov,sizeof(int),1,fp);
	fread(&dwdxov,sizeof(float),1,fp);
	fread(&fwdxov,sizeof(float),1,fp);
	fread(&dzodx,sizeof(float),1,fp);
	nh = alloc1int(nwdxov);
	fread(nh,sizeof(int),nwdxov,fp);
	e = alloc2complex(nhmax,nwdxov);
	fread(e[0],sizeof(complex),nhmax*nwdxov,fp);
	
	/* allocate table and set table values */
	et = (eTable*)malloc(sizeof(eTable));
	et->nhmax = nhmax;
	et->nwdxov = nwdxov;
	et->dwdxov = dwdxov;
	et->fwdxov = fwdxov;
	et->dzodx = dzodx;
	et->nh = nh;
	et->e = e;
	
	/* return pointer to table */
	return(et);
}
