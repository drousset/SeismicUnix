/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"
#define NDMAX 21

/* functions defined and used internally */
static void matchk0 (float dzodx, float wdxov, int nh, int nd, complex f[]);
static float basis (int nh, int nd, int j, int l);
static void rhs (float dzodx, float wdxov, int nd, double br[], double bi[]);

eTable *etmake (int nwdxov, float dwdxov, float fwdxov, 
	float dzodx, int nhmax, int optimal)
/*****************************************************************************
Make and return a pointer to a table of stable wavefield extrapolators
******************************************************************************
Input:
nwdxov		number of frequency*dx/velocity values
dwdxov		frequency*dx/velocity sampling interval (in radians)
fwdxov		first frequency*dx/velocity (in radians)
dzodx		ratio dz/dx of z to x sampling intervals
nhmax		maximum half-length of symmetric extrapolators
optimal		=1 to optimize half-length; =0 to always use nhmax
******************************************************************************
Notes:
The extrapolators e(x) will have Fourier transforms E(k) approximating
	E(k) = exp(I*dz*(w/v-sqrt(w/v*w/v-k*k)))  , for |k| <= PI/dx ,
where I denotes sqrt(-1), and w/v denotes frequency divided by velocity.
Stable extrapolators are those for which |E(k)|<1.0001 for all k.
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 11/22/89
******************************************************************************/
{
	int ndmax=NDMAX;
	float phtol=0.001*PI;
	int nfft,nk,nd,nh,ndbest,i,ik,iwdxov,stable,*nhbest,nhmin;
	float wdxov,dk,fk,k,knyq,
		amp,phase,phexa,pherr,ktol,ktolmax;
	complex *ex,*ek,**e,czero=cmplx(0.0,0.0);
	eTable *et;
	
	/* allocate table and set constant values */
	et = (eTable*)malloc(sizeof(eTable));
	et->nhmax = nhmax;
	et->nwdxov = nwdxov;
	et->dwdxov = dwdxov;
	et->fwdxov = fwdxov;
	et->dzodx = dzodx;
	et->nh = nhbest = alloc1int(nwdxov);
	et->e = e = alloc2complex(nhmax,nwdxov);
	
	/* determine Fourier transform sampling */
	nfft = npfa(8*nhmax);
	nk = nfft;
	dk = 2.0*PI/nfft;
	fk = 0;
	knyq = PI;
	
	/* allocate workspace */
	ex = alloc1complex(nfft);
	ek = alloc1complex(nfft);
	
	/* initialize number of derivatives matched for best extrapolator */
	ndbest = 1;
	
	/* loop over frequency*dx/velocity */
	for (iwdxov=0; iwdxov<nwdxov; iwdxov++) {
	
		/* compute frequency*dx/velocity */
		wdxov = fwdxov+iwdxov*dwdxov;
		
		/* avoid division by very small wdxov */
		wdxov = MAX(wdxov,0.1*dk);
			
		/* initialize maximum ktol */
		ktolmax = 0.0;
		
		/* initialize nhbest so we know if it gets set */
		nhbest[iwdxov] = 0;
		
		/* loop over number of derivatives matched */
		for (nd=ndbest; nd<=ndmax && nd<nhmax; nd++) {
		
			/* determine minimim half-length */
			nhmin = (optimal ? nd+1 : nhmax);
			
			/* loop over half-lengths until stable */
		 	for (nh=nhmin; nh<=nhmax; nh++) {
	
				/* match derivatives */
				matchk0(dzodx,wdxov,nd,nh,ex);
				
				/* Fourier transform the extrapolator */
				for (i=0; i<nh; i++)
					ek[i] = ex[i];
				for (i=1; i<nh; i++)
					ek[nfft-i] = ek[i];
				for (i=nh; i<=nfft-nh; i++)
					ek[i] = czero;
				pfacc(-1,nfft,ek);
				
				/* check stability */
				for (ik=0,stable=1; ik<nk && stable; ik++) {
					amp = fcabs(ek[ik]);
					stable = amp<1.0001;
				}
				
				/* if stable, break */
				if (stable) break;
			}
			
			/* if not stable for any half-length, break */
			if (!stable) break;
						
			/* determine k for which phase error < tolerance */
			for (ik=0,k=fk; ik<nk/2; ik++,k+=dk) {
				phase = atan2(ek[ik].i,ek[ik].r);
				phexa = dzodx*(wdxov-sqrt(wdxov*wdxov-k*k));
				pherr = phase-phexa;
				if (ABS(pherr)>phtol) break;
			}
			ktol = k-dk;
			
			/* if ktol has increased, remember values */
			if (ktol>=ktolmax) {
				ktolmax = ktol;
				ndbest = nd;
				nhbest[iwdxov] = nh;
				for (i=0; i<nh; i++)
					e[iwdxov][i] = ex[i];
				for (i=nh; i<nhmax; i++)
					e[iwdxov][i] = czero;
			}
		}
		
		/* should not be necessary, but just to be safe */
		if (nhbest[iwdxov]==0) {
			nhbest[iwdxov] = nh = nhmax;
			ndbest = nhmax-1;
			for (i=0; i<nh; i++)
				e[iwdxov][i] = ex[i];
			warn("amp = %g!",amp);
		}

		/* report progress */
		/*
		fprintf(stderr,"nhbest[%d] = %d  ndbest[%d] = %d\n",
			iwdxov,nhbest[iwdxov],iwdxov,ndbest);
		*/
	}
	
	/* free workspace */
	free1complex(ex);
	free1complex(ek);

	/* return pointer to extrapolator table */
	return(et);
}

/* match even derivatives for a particular half-length at k = 0 */
static void matchk0 (float dzodx, float wdxov, int nd, int nh, complex f[])
{
	int j,l,m,*ipvt;
	double scale,rcond,**a,*br,*bi,*work;
	
	/* if not matching, then return */
	if (nd<=0) return;
	
	/* allocate space */
	a = alloc2double(nd,nd);
	ipvt = alloc1int(nd);
	br = alloc1double(nd);
	bi = alloc1double(nd);
	work = alloc1double(nd);
	
	/* build matrix and right-hand-sides */
	for (m=0; m<nd; m++) {
		for (l=0; l<nd; l++) {
			a[l][m] = (m==0 ? basis(nh,nd,0,l) : 0.0);
			for (j=1; j<nh; j++) {
				a[l][m] += 2.0*pow(j,2*m)*basis(nh,nd,j,l);
			}
		}
	}
	rhs(dzodx,wdxov,nd,br,bi);

	/* scale equations to improve conditioning */
	for (m=0; m<nd; m++) {
		scale = 1.0/pow(2*nh-1,2*m);
		for (l=0; l<nd; l++)
			a[l][m] *= scale;
		br[m] *= scale;
		bi[m] *= scale;
	}
	
	/* solve equations for filter coefficients */
	dgeco(a,nd,ipvt,&rcond,work);
	/* fprintf(stderr,"nh=%d nd=%d rcond = %g\n",nh,nd,rcond); */
	dgesl(a,nd,ipvt,br,0);
	dgesl(a,nd,ipvt,bi,0);
	
	/* compute filter coefficients */
	for (j=0; j<nh; j++) {
		f[j].r = f[j].i = 0.0;
		for (l=0; l<nd; l++) {
			scale = basis(nh,nd,j,l);
			f[j].r += br[l]*scale;
			f[j].i += bi[l]*scale;
		}
	}
	
	/* free space */
	free2double(a);
	free1int(ipvt);
	free1double(br);
	free1double(bi);
	free1double(work);
}

/* basis function for derivative constraints */
static float basis (int nh, int nd, int j, int l)
{
	return cos(2.0*PI*j*l/(2.0*nh-1.0));
}

/* compute right-hand-side column vector containing even derivatives */
static void rhs (float dzodx, float wdxov, int nd, double br[], double bi[])
{
static double tr[NDMAX][NDMAX] =
	#include "ctable.h"	/* derivative coefficients for cos (Re part) */
;
static double ti[NDMAX][NDMAX] =
	#include "stable.h"	/* derivative coefficients for sin (Im part) */
;
	int i,j,ndl;
	double scale,sumr,sumi,wovdz=wdxov*dzodx;
	
	/* limit number of derivatives */
	ndl = MIN(nd,NDMAX);
	
	/* loop over derivatives */
	for (i=0; i<ndl; i++) {
	
		/* compute constant scale factor */
		scale = pow(wdxov,-2.0*i);
		
		/* loop over terms in real and imaginary parts */
		for (j=0,sumr=sumi=0.0; j<=i; j++) {
			if (tr[i][j]!=0.0)
				sumr += tr[i][j]*pow(wovdz,(double)(2*j));
			if (ti[i][j]!=0.0)
				sumi += ti[i][j]*pow(wovdz,(double)(2*j-1));
		}
		
		/* set real and imaginary parts */
		br[i] = (i%2 ? -sumr*scale : sumr*scale);
		bi[i] = (i%2 ? -sumi*scale : sumi*scale);
	}
	for (i=ndl; i<nd; i++) {
		br[i] = 0.0;
		bi[i] = 0.0;
	}
}
