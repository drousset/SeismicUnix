/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "extrap.h"

/* length (same for both x and y) of McClellan cosine filter */
#define LCF 5

/* constant used to improve circular symmetry of McClellan cosine filter */
#define C1 0.0255199

/* functions declared and used internally */
static void mccos (int n1, int n2, complex **f, complex **g); 

void etextrap2 (eTable *et, int nx, int ny, float **wdxov, complex **q)
/*****************************************************************************
2-D extrapolation for one frequency via an extrapolator table
******************************************************************************
Input:
et		pointer to extrapolator table
nx		number of x samples in wavefield
ny		number of y samples in wavefield
wdxov		array[nx][ny] of frequency*dx/velocity values
q		array[nx][ny] containing wavefield

Output:
q		array[nx][ny] containing extrapolated wavefield
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 02/10/90
******************************************************************************/
{
	
	int ix,iy,j,**ie,nxpad,nypad,iwdxov,
		nwdxov=et->nwdxov,nhmax=et->nhmax;
	float er,ei,pr,pi,qr,qi,phase,wdxovn,
		dwdxov=et->dwdxov,fwdxov=et->fwdxov,dzodx=et->dzodx;
	complex **pj,**pjm1,**pjm2,**temp,
		**e=et->e;
	
	/* determine zero-padded dimensions for workspace */
	nxpad = LCF/2+nx+LCF/2;
	nypad = LCF/2+ny+LCF/2;
	
	/* allocate workspace */
	ie = alloc2int(ny,nx);
	pj = alloc2complex(nypad,nxpad);
	pjm1 = alloc2complex(nypad,nxpad);
	pjm2 = alloc2complex(nypad,nxpad);
	
	/* determine indices of extrapolator coefficients */
	for (ix=0; ix<nx; ++ix) {
		for (iy=0; iy<ny; ++iy) {
			wdxovn = (wdxov[ix][iy]-fwdxov)/dwdxov;
			iwdxov = NINT(wdxovn);
			if (iwdxov<0) iwdxov = 0;
			if (iwdxov>=nwdxov) iwdxov = nwdxov-1;
			ie[ix][iy] = iwdxov;
		}
	}
	
	/* zero the workspace and adjust pointers for zero-padding */
	for (ix=0; ix<nxpad; ++ix) {
		for (iy=0; iy<nypad; ++iy) {
			pj[ix][iy].r = pjm1[ix][iy].r = pjm2[ix][iy].r = 0.0;
			pj[ix][iy].i = pjm1[ix][iy].i = pjm2[ix][iy].i = 0.0;
		}
		pj[ix] += LCF/2;
		pjm1[ix] += LCF/2;
		pjm2[ix] += LCF/2;
	}
	pj += LCF/2;
	pjm1 += LCF/2;
	pjm2 += LCF/2;
	
	/* initialize output and Chebyshev recursion */
	for (ix=0; ix<nx; ++ix) {
		for (iy=0; iy<ny; ++iy) {
			er = e[ie[ix][iy]][0].r;
			ei = e[ie[ix][iy]][0].i;
			pr = pj[ix][iy].r = q[ix][iy].r;
			pi = pj[ix][iy].i = q[ix][iy].i;
			q[ix][iy].r = pr*er-pi*ei;
			q[ix][iy].i = pr*ei+pi*er;
		}
	}
	
	/* loop over remaining extrapolator coefficients */
	for (j=1; j<nhmax; ++j) {
	
		/* roll the Chebyshev recursion forward */
		temp = pjm2;
		pjm2 = pjm1;
		pjm1 = pj;
		pj = temp;
		
		/* apply McClellan cosine filter */
		mccos(ny,nx,pjm1,pj);
		
		/* accumulate output while doing Chebyshev recursion */
		if (j==1) {
			for (ix=0; ix<nx; ++ix) {
				for (iy=0; iy<ny; ++iy) {
					er = 2.0*e[ie[ix][iy]][j].r;
					ei = 2.0*e[ie[ix][iy]][j].i;
					pr = pj[ix][iy].r *= 0.5;
					pi = pj[ix][iy].i *= 0.5;
					q[ix][iy].r += pr*er-pi*ei;
					q[ix][iy].i += pr*ei+pi*er;
				}
			}
		} else {
			for (ix=0; ix<nx; ++ix) {
				for (iy=0; iy<ny; ++iy) {
					er = 2.0*e[ie[ix][iy]][j].r;
					ei = 2.0*e[ie[ix][iy]][j].i;
					pr = pj[ix][iy].r -= pjm2[ix][iy].r;
					pi = pj[ix][iy].i -= pjm2[ix][iy].i;
					q[ix][iy].r += pr*er-pi*ei;
					q[ix][iy].i += pr*ei+pi*er;
				}
			}
		}
	}
	
	/* apply phase shift */
	for (ix=0; ix<nx; ++ix) {
		for (iy=0; iy<ny; ++iy) {
			phase = -dzodx*wdxov[ix][iy];
			er = cos(phase);
			ei = sin(phase);
			pr = q[ix][iy].r;
			pi = q[ix][iy].i;
			q[ix][iy].r = pr*er-pi*ei;
			q[ix][iy].i = pr*ei+pi*er;
		}
	}
	
	/* adjust workspace pointers and free workspace */
	pj -= LCF/2;
	pjm1 -= LCF/2;
	pjm2 -= LCF/2;
	pj[0] -= LCF/2;
	pjm1[0] -= LCF/2;
	pjm2[0] -= LCF/2;
	free2complex(pj);
	free2complex(pjm1);
	free2complex(pjm2);
	free2int(ie);
}

static void mccos (int n1, int n2, complex **f, complex **g) 
/*****************************************************************************
Apply McClellan's 2-D cosine filter transformed for circular symmetry
******************************************************************************
Input:
n1		number of samples in 1st (fast) dimension
n2		number of samples in 2nd (slow) dimension
f		array[-1:n2][-1:n1] to be filtered (see notes below)

Output:
g		array[0:n2-1][0:n1-1] filtered
******************************************************************************
Notes:
Because the 2-D filter has a width of 3,
the array f will be indexed with -1 <= i1 <= n1 and -1 <= i2 <= n2.
The pointers implied by **f must be be set accordingly.
The array g will be indexed with 0 <= i1 <= n1-1 and 0 <= i2 <= n2-1.
******************************************************************************
Reference:  
McClellan, J. H., 1973, The design of two-dimensional digital filters by
transformation:  Proc. 7th Annu. Princeton Conf. on Inform. Sci. and
Syst., p. 247-251.
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 02/08/90
******************************************************************************/
{
	int i1,i1m1,i1p1,i1m2,i1p2,i2,i2m1,i2p1,i2m2,i2p2;

	for (i2=0; i2<n2; ++i2) {
		for (i1=0; i1<n1; ++i1) {
			g[i2][i1].r = 
				-C1*0.25*(	f[i2+2][i1+2].r +
						f[i2+2][i1-2].r +
						f[i2-2][i1+2].r +
						f[i2-2][i1-2].r )
				+C1*0.5*(	f[i2][i1+2].r +
						f[i2][i1-2].r +
						f[i2+2][i1].r +
						f[i2-2][i1].r )
				+0.25*(		f[i2+1][i1+1].r +
						f[i2+1][i1-1].r +
						f[i2-1][i1+1].r +
						f[i2-1][i1-1].r )
				+0.5*(		f[i2][i1+1].r +
						f[i2][i1-1].r +
						f[i2+1][i1].r +
						f[i2-1][i1].r )
				-(1.0+C1)*	f[i2][i1].r;
			g[i2][i1].i = 
				-C1*0.25*(	f[i2+2][i1+2].i +
						f[i2+2][i1-2].i +
						f[i2-2][i1+2].i +
						f[i2-2][i1-2].i )
				+C1*0.5*(	f[i2][i1+2].i +
						f[i2][i1-2].i +
						f[i2+2][i1].i +
						f[i2-2][i1].i )
				+0.25*(		f[i2+1][i1+1].i +
						f[i2+1][i1-1].i +
						f[i2-1][i1+1].i +
						f[i2-1][i1-1].i )
				+0.5*(		f[i2][i1+1].i +
						f[i2][i1-1].i +
						f[i2+1][i1].i +
						f[i2-1][i1].i )
				-(1.0+C1)*	f[i2][i1].i;
		}
	}
}
