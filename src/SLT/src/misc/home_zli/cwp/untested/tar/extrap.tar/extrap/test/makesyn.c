/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "par.h"

char *sdoc =
"MAKESYN - MAKE SYNthetic data p(x,y,t)"
"\n"
"makesyn >outfile nx= nt= [optional parameters]\n"
"\n"
"Required Parameters:\n"
"nx=                    number of x samples (3rd dimension)\n"
"nt=                    number of t samples (1st dimension)\n"
"\n"
"Optional Parameters:\n"
"ny=1                   number of y samples (2nd dimension)\n"
"dx=1.0                 x sampling interval\n"
"fx=0.0                 first x sample\n"
"dy=1.0                 y sampling interval\n"
"fy=0.0                 first y sample\n"
"dt=1.0                 t sampling interval\n"
"ft=0.0                 first t sample\n"
"\n";

main (int argc, char **argv)
{
	int nx,ny,nt,ix,iy,it;
	float dx,dy,dt,fx,fy,ft,x,y,t,*p;
	FILE *outfp=stdout;

	/* hook up getpar to handle the parameters */
	initargs(argc,argv);
	askdoc(0);
	
	/* get required parameters */
	if (!igetpar("nx",&nx)) err("must specify nx!\n");
	if (!igetpar("nt",&nt)) err("must specify nt!\n");
	
	/* get optional parameters */
	if (!igetpar("ny",&ny)) ny = 1;
	if (!fgetpar("dx",&dx)) dx = 1.0;
	if (!fgetpar("dy",&dy)) dy = 1.0;
	if (!fgetpar("dt",&dt)) dt = 1.0;
	if (!fgetpar("fx",&fx)) fx = 0.0;
	if (!fgetpar("fy",&fy)) fy = 0.0;
	if (!fgetpar("ft",&ft)) ft = 0.0;
	
	/* allocate space */
	p = alloc1float(nt);
	
	/* compute and write data */
	for (ix=0,x=fx; ix<nx; ++ix,x+=dx) {
		for (iy=0,y=fy; iy<ny; ++iy,y+=dy) {
			for (it=0,t=ft; it<nt; ++it,t+=dt)
				p[it] = 0.0;
			if (ix==nx/3 && iy==ny/3) {
				p[1*nt/4] = 1.0;
				p[2*nt/4] = 1.0;
				p[3*nt/4] = 1.0;
			}
			fwrite(p,sizeof(float),nt,outfp);
		}
	}
	
	/* free space before returning */
	free1float(p);
	return 0;
}
