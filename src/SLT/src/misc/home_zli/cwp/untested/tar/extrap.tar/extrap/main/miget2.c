/* Copyright (c) Colorado School of Mines, 1990.
/* All rights reserved.                       */

#include "par.h"
#include "extrap.h"

char *sdoc =
"MIGET2 - MIGration via an Extrapolator Table of 2-D zero-offset data\n"
"\n"
"miget2 <infile >outfile efile= vfile= nt= nx= nz= [optional parameters]\n"
"\n"
"Required Parameters:\n"
"efile=                 name of file containing extrapolator table\n"
"vfile=                 name of file containing v(x,z)\n"
"nt=                    number of time samples\n"
"nx=                    number of inline samples (traces)\n"
"nz=                    number of depth samples\n"
"\n"
"Optional Parameters:\n"
"dt=1.0                 time sampling interval\n"
"dx=1.0                 inline sampling interval (trace spacing)\n"
"dz=1.0                 depth sampling interval\n"
"freqs=0,0,fNyq,fNyq    corner frequencies of trapezoidal bandpass filter\n"
"ntpad=nt               number of zero samples by which to pad time axis\n"
"verbose=0              =1 for diagnostics on standard error\n"
"\n";

main (int argc, char **argv)
{
	int nt,nx,nz,ntpad,nw,ntfft,it,ix,iz,
		iw,iw0,iw1,iw2,iw3,iwmin,iwmax,nfreqs,verbose;
	float dt,dx,dz,freqs[4],dw,fw,w,scale,fftscl,
		*p,*wdxov,*sx,*qx,**v,**q;
	complex **cp,*cpx;
	char *efile="",*vfile="";
	FILE *infp=stdin,*outfp=stdout,*efp,*vfp;
	eTable *et;

	/* hook up getpar to handle the parameters */
	initargs(argc,argv);
	askdoc(0);
	
	/* get required parameters */
	if (!getparstring("efile",&efile)) err("must specify efile!\n");
	if (!getparstring("vfile",&vfile)) err("must specify vfile!\n");
	if (!getparint("nt",&nt)) err("must specify nt!\n");
	if (!getparint("nx",&nx)) err("must specify nx!\n");
	if (!getparint("nz",&nz)) err("must specify nz!\n");
	
	/* get optional parameters */
	if (!getparfloat("dt",&dt)) dt = 1.0;
	if (!getparfloat("dx",&dx)) dx = 1.0;
	if (!getparfloat("dz",&dz)) dz = 1.0;
	if (!getparint("ntpad",&ntpad)) ntpad=nt;
	if ((nfreqs=getparfloat("freqs",freqs))==0) {
		freqs[0] = 0.0;
		freqs[1] = 0.0;
		freqs[2] = 0.5/dt;
		freqs[3] = 0.5/dt;
	} else if (nfreqs!=4) {
		err("less than 4 freqs specified!\n");
	}
	if (!getparint("verbose",&verbose)) verbose = 0;
	
	/* determine frequency w sampling */
	ntfft = npfar(nt+ntpad);
	nw = ntfft/2+1;
	dw = 2.0*PI/(ntfft*dt);
	
	/* read extrapolator table */
	if ((efp=fopen(efile,"r"))==NULL)
		err("error opening efile=%s\n",efile);
	et = etread(efp);
	
	/* read velocities */
	v = alloc2float(nz,nx);
	if ((vfp=fopen(vfile,"r"))==NULL)
		err("error opening vfile=%s\n",vfile);
	fread(v[0],sizeof(float),nz*nx,vfp);

	/* read and Fourier transform input data */
	p = alloc1float(ntfft);
	cp = alloc2complex(nw,nx);
	for (ix=0; ix<nx; ++ix) {
		if (fread(p,sizeof(float),nt,infp)!=nt)
			err("error reading trace number %d\n",ix+1);
		for (it=nt; it<ntfft; ++it)
			p[it] = 0.0;
		pfarc(1,ntfft,p,cp[ix]);
	}
	free1float(p);
	
	/* determine sample indices for frequency filter */
	iw0 = MAX(0,MIN(nw-1,NINT(2.0*PI*freqs[0]/dw)));
	iw1 = MAX(0,MIN(nw-1,NINT(2.0*PI*freqs[1]/dw)));
	iw2 = MAX(0,MIN(nw-1,NINT(2.0*PI*freqs[2]/dw)));
	iw3 = MAX(0,MIN(nw-1,NINT(2.0*PI*freqs[3]/dw)));
	
	/* apply frequency filter and FFT scaling */
	for (iw=0; iw<nw; ++iw) {
		fftscl = (iw==0 || iw==nw-1 ? 1.0/ntfft : 2.0/ntfft);
		if (iw<iw0)
			scale = 0.0;
		else if (iw0<=iw && iw<iw1)
			scale = (float)(iw-iw0)/(float)(iw1-iw0)*fftscl;
		else if (iw1<=iw && iw<=iw2)
			scale = fftscl;
		else if (iw2<iw && iw<=iw3)
			scale = (float)(iw3-iw)/(float)(iw3-iw2)*fftscl;
		else
			scale = 0.0;
		for (ix=0; ix<nx; ++ix) {
			cp[ix][iw].r *= scale;
			cp[ix][iw].i *= scale;
		}
	}
	iwmin = iw0;
	iwmax = iw3;	
	
	/* allocate workspace */
	q = v;
	qx = alloc1float(nx);
	sx = alloc1float(nx);
	wdxov = alloc1float(nx);
	cpx = alloc1complex(nx);
	
	/* loop over depths z */
	for (iz=0; iz<nz; ++iz) {
	
		/* progress report */
		if (verbose) fprintf(stderr,"%d/%d\n",iz,nz);
	
		/* compute 2.0*dx/v(x) and zero migrated data */
		for (ix=0; ix<nx; ix++) {
			sx[ix] = 2.0*dx/v[ix][iz];
			qx[ix] = 0.0;
		}

		/* loop over frequencies w */
		for (iw=iwmin,w=iwmin*dw; iw<iwmax; ++iw,w+=dw) {
			
			/* make w*dx/v(x) */
			for (ix=0; ix<nx; ++ix)
				wdxov[ix] = w*sx[ix];
			
			/* load wavefield */
			for (ix=0; ix<nx; ++ix)
				cpx[ix] = cp[ix][iw];
				
			/* extrapolate wavefield */
			etextrap(et,nx,wdxov,cpx);
			
			/* store wavefield */
			for (ix=0; ix<nx; ++ix)
				cp[ix][iw] = cpx[ix];
						
			/* accumulate migrated data */
			for (ix=0; ix<nx; ++ix)
				qx[ix] += cpx[ix].r;
		}
		
		/* store migrated data */
		for (ix=0; ix<nx; ++ix)
			q[ix][iz] = qx[ix];
	}
	
	/* write migrated data */
	fwrite(q[0],sizeof(float),nz*nx,outfp);
	
	/* free workspace */
	free1float(sx);
	free1float(qx);
	free1float(wdxov);
	free2float(v);
	free1complex(cpx);
	free2complex(cp);
}
