rm datanmo.01
rm datavel.01
rm Result.PSVtti2
