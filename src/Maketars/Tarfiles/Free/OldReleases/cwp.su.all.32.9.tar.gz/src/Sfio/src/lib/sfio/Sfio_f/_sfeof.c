/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

#include	"sfhdr.h"

#undef sfeof

#if __STD_C
int sfeof(reg Sfio_t* f)
#else
int sfeof(f)
reg Sfio_t*	f;
#endif
{
	return __sf_eof(f);
}
