/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

#include	"sfhdr.h"

#if __STD_C
char *sffcvt(double dval, int n_digit, int* decpt, int* sign)
#else
char *sffcvt(dval,n_digit,decpt,sign)
double	dval;		/* value to convert */
int	n_digit;	/* number of digits wanted */
int*	decpt;		/* to return decimal point */
int*	sign;		/* to return sign */
#endif
{
	return _sfcvt((Sfdouble_t)dval,n_digit,decpt,sign,0);
}
