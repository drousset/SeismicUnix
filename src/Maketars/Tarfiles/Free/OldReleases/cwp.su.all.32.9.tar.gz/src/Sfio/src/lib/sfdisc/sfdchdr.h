/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

#include	"sfdisc.h"

#define reg		register

_BEGIN_EXTERNS_
extern Void_t*	malloc _ARG_((size_t));
extern void	free _ARG_((Void_t*));
_END_EXTERNS_
