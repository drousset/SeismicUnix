/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

#include	"sfstdio.h"

/*	Internal scanf engine to read from a string buffer
**	Written by Kiem-Phong Vo
*/

#if __STD_C
int vsscanf(char* s, const char* form, va_list args)
#else
int vsscanf(s,form,args)
reg char*	s;
reg char*	form;
va_list		args;
#endif
{
	return s ? sfvsscanf(s,form,args) : -1;
}
