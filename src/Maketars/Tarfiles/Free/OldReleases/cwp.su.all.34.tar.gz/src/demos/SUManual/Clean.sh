#! /bin/sh
# Clean.sh created data files

rm -f *.eps vdata tempdata

cd Plotting ; Clean.sh

exit
