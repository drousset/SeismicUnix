#! /bin/sh

rm *lens
