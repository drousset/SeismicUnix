#! /bin/sh

rm AInterface NShoot.eps XInterface XTfile XZInterface
rm ZInterface model.bin model.eps nray.40.eps nray.bin nrayend.bin outpar
