#! /bin/sh

rm *.ps susyn1*  core
