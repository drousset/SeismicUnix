#! /bin/sh

rm */outpar
