#! /bin/sh
# clean up files made by demo

rm -f modeldata
rm -f *.eps

exit
