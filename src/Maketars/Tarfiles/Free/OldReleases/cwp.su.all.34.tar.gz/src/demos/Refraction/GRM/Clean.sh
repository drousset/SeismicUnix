#! /bin/sh

rm OUT*
