#! /bin/sh
# Clean.sh created data files

rm -f *.eps

exit
