#! /bin/sh

cd ./GRM ; Clean.sh
