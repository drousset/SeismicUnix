#! /bin/sh

rm -f  template template2 moviefile data*

exit
