#! /bin/sh
# clean up files made by NMO demo
# deliberately leave stkvel.p in place in case Xvelocity not run

rm -f  modeldata nmodata stackdata panel*
rm -f  unisam*.p
rm -f  *.eps mpicks* stkvel* par.*


exit
