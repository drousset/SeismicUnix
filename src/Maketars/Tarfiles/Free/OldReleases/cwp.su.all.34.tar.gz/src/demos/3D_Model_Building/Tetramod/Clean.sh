#! /bin/sh

rm hzfile* tetrafile* 
