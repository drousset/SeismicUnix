/* Copyright (c) Colorado School of Mines, 2000.*/
/* All rights reserved.                       */

#include	"terror.h"
#include	<vthread.h>
