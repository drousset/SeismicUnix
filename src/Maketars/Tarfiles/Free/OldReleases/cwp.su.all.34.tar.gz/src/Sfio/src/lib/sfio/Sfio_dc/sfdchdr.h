/* Copyright (c) Colorado School of Mines, 2000.*/
/* All rights reserved.                       */

#include	"sfhdr.h"
#include	<sfdisc.h>
