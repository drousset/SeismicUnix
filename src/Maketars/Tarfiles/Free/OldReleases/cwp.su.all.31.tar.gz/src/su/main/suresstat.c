/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SURESSTAT: $Revision: 1.9 $ ; $Date: 1997/05/05 17:37:57 $		*/

#include "su.h"
#include "segy.h"
#include "header.h"

/*********************** self documentation ******************************/
char *sdoc[] = {
" 									",
" SURESSTAT - Surface consistent source and receiver statics calculation",
" 									",
"   suresstat <stdin [optional parameters]				",
" 									",
" Required parameters: 							",
" ssol=		output file source statics				",
" rsol=		output file receiver statics				",
" 									",
" Optional parameters:							",
" ntcc=250 	number of samples in the cross-correlation window	",
" ntpick=50 	number of samples in the picking window			",
" n_o=7 	near-offset position relative to the shot		",
" niter=5 	number of iterations					",
" ns=240 	number of shots						",
" nr=335 	number of receivers					",
" nc=574 	number of cmp's						",
" sfold=96 	shot gather fold					",
" rfold=96 	receiver gather fold					",
" cfold=48 	cmp gather fold						",
" sub=0 	subtract super trace 1 from super trace 2 (=1)		",
" mode=0 	use global maximum in cross-correllation window		",
"		=1 choose the peak perc=percent smaller than the global max.",
" perc=10. 	percent of global max (used only for mode=1)		",
" icmpshift=9 	shift applied to icmp index				",
" 									",
" Notes:								",
" Estimates surface-consistent source and receiver statics, meaning that",
" there is one static correction value estimated for each shot and receiver",
" position.								",
" 									",
" The method employed here is based on the method of Ronen and Claerbout:",
" Geophysics 50, 2759-2767 (1985).					",
"  									",
" The input consists of moveout-corrected SU data sorted in shot gathers.",
" The output files are ascii files containing the source and receiver	",
" statics, as a function of surface position sx and gx, respectively.	",
"  									",
" The code builds a supertrace1 and supertrace2, which are subsequently	",
" cross-correllated. The program then picks the time lag associated with",
" the largest peak in the cross-correllation according to two possible	",
" criteria set by the parameter \"mode\". If mode=0, the maximum of the	",
" cross-correllation window is chosen. If mode=1, the program will pick ",
" a peak which is up to perc=percent smaller than the global maximum, but",
" closer to zero lag than the global maximum.	(Choosing mode=0 is	",
" recommended.)								",
"  									",
NULL};

/* Reference:
 *
 *  Ronen, J. and Claerbout, J., 1985, Surface-consistent residual statics
 *      estimation  by stack-power maximization: Geophysics, vol. 50,
 *      2759-2767.
 *
 * Credits:
 *	CWP: Timo Tjan, 4 October 1994
 *
 * Trace header fields accessed: ns, dt
 */
/**************** end self doc *******************************************/


segy tr, tr2;

/* prototypes for functions defined and used below */
int max (float *trace, int mode, float perc, int nt);
void window (float *trace, int nt, int nnt, float *ntrace);

int
main(int argc, char **argv)
{
	int nt;				/* number of points on input traces*/
	int ns, nc, nr;			/* number of shots, cmps and recs */
	int sfold, cfold, rfold;	/* source, cmp and receiver fold */
	int n_o;			/* near offset */
	int ntcc;		/* nr. of points on c-c in traces */
	int mint, maxt;		/* min. and max time in c-c */
	int ntpick;		/* nr. of points on trace for picking */
	int ntout;		/* nr. of points on c-c out traces */
	int nt_r;		/* nr. of points on resamp. c-c in traces */
	int resamp;			/* resampling rate */
	int ntr;			/* number of trace on input */
	int iter, niter;		/* iteration vars */
	register int ishot, ichan, irec, icmp;	/* gather counters */
	int icmpshift;		/* shift applied to icmp */
	register int it, itr, i, j=0, k;	/* counters */
	int *cmpntr, cmp_max, cmp_min;	/* cmp selector */
	int *recntr;			/* receiver gather fold */
	int **rec_loc, **cmp_loc;	/* position arrays */
	int mode;			/* pick global(=0) or local(=1) max */
	int sub;			/* subtract or not */
	int tlag;			/* time lag of c-c trace */
	int *sstat, *rstat;		/* shot and receiver static */
	int *tsstat, *trstat;		/* total shot and receiver static */
	float perc;			/* local max. witin perc. of global */
	float dt;			/* sampling rate */
	float **data, **model;		/* data arrays */
	float *g_trace;			/* trace arrays */
	float *t;			/* trace arrays */
	float *model_trace, *corr_trace;	/* more trace arrays */
	float *filter, *cc_tr, *pick_tr;	/* more trace arrays */
	float *filter_r, *cc_tr_r;	/* more trace arrays */
	FILE *fps, *fpr;		/* file pointers for output */
	cwp_String ssol, rsol;


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);

	/* Get info from first trace and store first header */
	if (!(ntr = gettra(&tr, 0)))  err("can't get first trace");
	dt = ((double) tr.dt)/1000000.0;
	if (!dt) getparfloat("dt", &dt);
	if (!dt) MUSTGETPARFLOAT("dt", &dt);
	nt = tr.ns;
	if (nt%2 == 0) err("nt must be odd");

	/* Get optional parameters */
	if (!getparint("ntcc",&ntcc)) ntcc=250; 
	if (!getparint("icmpshift",&icmpshift)) icmpshift=9; 
	if (ntcc%2 == 0) ++ntcc;
	if (!getparint("ntpick",&ntpick)) ntpick=50; 
	if (!getparint("resamp",&resamp)) resamp=4; 
	if (!getparint("n_o",&n_o)) n_o=7; 
	if (!getparint("niter",&niter)) niter=5;
	if (!getparint("ns",&ns)) ns=240; 
	if (!getparint("nr",&nr)) nr=335; 
	if (!getparint("nc",&nc)) nc=574; 
	if (!getparint("sfold",&sfold)) sfold=96; 
	if (!getparint("rfold",&rfold)) rfold=96; 
	if (!getparint("cfold",&cfold)) cfold=48; 
	if (!getparint("mode",&mode)) mode=0; 
	if (!getparint("sub",&sub)) sub=0; 
	if (!getparfloat("perc",&perc)) perc=10.; 

	if (!getparstring("ssol",&ssol))
		err("must specify a source statics output file");
	if (!getparstring("rsol",&rsol))
		err("must specify a receiver statics output file");

	/* Compute time windowing parameters */
	nt_r = ntcc*resamp;
	fprintf(stderr,"nt_r=%i\n",nt_r);
	ntout = 2*nt_r - 1;
	mint = (nt - 1)/2 - (ntcc - 1)/2 - ntpick/2;
	maxt = (nt - 1)/2 + (ntcc - 1)/2 + ntpick/2;
	fprintf(stderr,"mint=%i, maxt=%i\n",mint, maxt);

	/* Allocate space */
	cmpntr = alloc1int(nc+1);
	recntr = alloc1int(nr+1);
	g_trace = alloc1float(nt);
	t = alloc1float(nt_r);

	rec_loc = alloc2int(rfold+1,nr+1);
	cmp_loc = alloc2int(cfold+1,nc+1);

	model = alloc2float(nt,nc+1);
	model_trace = alloc1float(nt);

	filter = alloc1float(ntcc+1);
	cc_tr = alloc1float(nt_r+1);
	filter_r = alloc1float(nt_r+1);
	cc_tr_r = alloc1float(ntcc+1);
	corr_trace = alloc1float(ntout);
	pick_tr = alloc1float(ntpick+1);

	data = alloc2float(nt,ntr+1);

	tsstat = alloc1int(ns+1);
	trstat = alloc1int(nr+1);
	sstat = alloc1int(ns+1);
	rstat = alloc1int(nr+1);

	/* Zero out arrays */
	memset((void *) tsstat, (int) '\0' , (ns+1)*FSIZE);
	memset((void *) sstat, (int) '\0' , (ns+1)*FSIZE);
	memset((void *) trstat, (int) '\0' , (nr+1)*FSIZE);
	memset((void *) rstat, (int) '\0' , (nr+1)*FSIZE);
	memset((void *) data[0], (int) '\0' , (nr+1)*FSIZE);
	memset((void *) cmpntr, (int) '\0' , (nc+1)*ISIZE);
	memset((void *) recntr, (int) '\0' , (nc+1)*ISIZE);

	/* Read rest of data */
	for (ishot=1; ishot<=ns; ishot++){
		for (ichan=1; ichan<=sfold; ichan++){
			icmp = 2*ishot + ichan + n_o - icmpshift;
			irec = ishot - 1  + ichan;
			itr = (ishot-1)*sfold + ichan;

			gettra(&tr,itr-1);

			j = ++cmpntr[icmp];
			k = ++recntr[irec];
			cmp_loc[icmp][j] = tr.tracl;
			rec_loc[irec][k] = tr.tracl;

			for (it=0; it<nt; it++)
				data[tr.tracl][it] = tr.data[it];
		}
	}

	/* start iterations */
	for (iter=0; iter<niter; iter++) {

		fprintf(stderr,"iteration #= %i\n", iter);

		/* construct CMP stack */
		for (i=1; i<=nc; i++){

			for (it=0; it<nt; it++) model[i][it] = 0.;

			for (j=1; j<=cmpntr[i]; j++)
				for (it=mint; it<=maxt; it++)
					model[i][it] += data[cmp_loc[i][j]][it];

	    		/* normalize */
			for (it=mint; it<=maxt; it++)
				model[i][it] = model[i][it]/cmpntr[i];
		}

		for (it=0; it<nt_r; ++it) t[it] = it*0.001;

		/* Loop over shots */
		for (ishot=1; ishot<=ns; ishot++){

			/* construct shot super trace 1 */
			for (it=0; it<nt; it++) g_trace[it] = 0.;
			for (ichan=1; ichan<=sfold; ichan++)
				j = (ishot - 1)*sfold + ichan;
					for (it=mint; it<=maxt; it++)
						g_trace[it] += data[j][it];

	  		for (it=mint; it<=maxt; it++)
					g_trace[it] = g_trace[it]/sfold;

			/* determine models involved with this shot and */
	   		/* construct super trace 2 */
			cmp_max = 2*ishot + sfold + n_o - icmpshift;
			cmp_min = 2*ishot + 1 + n_o - icmpshift;
	  		for (it=0; it<nt; it++) model_trace[it] = 0.;

			for (icmp=cmp_min; icmp<=cmp_max; icmp++)
				for (it=mint; it<=maxt; it++)
					model_trace[it]+=model[icmp][it];
	  
	  		for (it=mint; it<=maxt; it++)
		 		model_trace[it] = model_trace[it]/sfold;

			/* subtract super trace 1 from super trace 2 */
	  		if (sub == 1)
				for (it=mint; it<=maxt; it++)
					model_trace[it]-=g_trace[it];

			/* cross-correlate super trace 1 with super trace 2 */
	  		window(g_trace, nt, ntcc, cc_tr);
	  		window(model_trace, nt, ntcc, filter);

			ints8r(ntcc,dt,0.0,cc_tr,0.0,0.0,nt_r,t,cc_tr_r);
			ints8r(ntcc,dt,0.0,filter,0.0,0.0,nt_r,t,filter_r);

			xcor(nt_r, 0, cc_tr_r, nt_r, 0, filter_r,
                     		     ntout , -nt_r + 1, corr_trace);

			/* pick cross-correlation peak */ 
			window(corr_trace, ntout, ntpick, pick_tr);
			tlag = max(pick_tr, mode, perc, ntpick);

			/* remember initial estimation and total correction */
			sstat[ishot] = tlag;
			tsstat[ishot] += tlag;

		}

		/* end shot statics loop */

		/* correct traces for shot statics (use g_trace as temp trace) */ 
		for (ishot=1; ishot<=ns; ishot++){
	  		for (ichan=1; ichan<=sfold; ichan++){
				itr = (ishot-1)*sfold + ichan;
				j = sstat[ishot];

				for (it=0; it<nt; ++it)
					t[it] = it*dt - j*0.001;
				ints8r(nt, dt, 0.0, data[itr], 
					0.0, 0.0, nt, t, g_trace);

				for (it=0; it<nt; it++) data[itr][it] = g_trace[it];
			}
		}

		/* CMP stack of corrected traces */
		for (i=1; i<=nc; i++){
			for (it=0; it<nt; it++) model[i][it] = 0.;

			for (j=1; j<=cmpntr[i]; j++)
				for (it=mint; it<=maxt; it++)
					model[i][it] += data[cmp_loc[i][j]][it];

	    		/* normalize */
	    		for (it=mint; it<=maxt; it++)
					model[i][it] = model[i][it]/cmpntr[i];
		}

		for (it=0; it<nt_r; ++it) t[it] = it*0.001;

		/* Loop over receivers */
		for (irec=1; irec<=nr; irec++){

			/* construct receiver super trace 1 */
	  		for (it=0; it<nt; it++) g_trace[it] = 0.;

			for (ichan=1; ichan<=recntr[irec]; ichan++)
				for (it=mint; it<=maxt; it++)
					g_trace[it] += data[rec_loc[irec][ichan]][it];

	  		for (it=mint; it<=maxt; it++)
				g_trace[it] = g_trace[it]/recntr[irec];

			/* determine part of stack involved with this */
			/* receiver & construct super trace 2 */
			if (irec <= rfold)
				cmp_min = irec ;
	  		else
				cmp_min = 2 * irec - rfold ;

			cmp_max = cmp_min + recntr[irec] - 1;

	  		for (it=0; it<nt; it++)
				model_trace[it] = 0.;

	  		for (icmp=cmp_min; icmp<=cmp_max; icmp++)
				for (it=mint; it<=maxt; it++)
					model_trace[it]+=model[icmp][it];
	  
	  		for (it=mint; it<=maxt; it++)
				model_trace[it] = model_trace[it]/recntr[irec];

			/* subtract super trace 1 from super trace 2 */
	  		if (sub == 1)
				for (it=mint; it<maxt; it++)
					model_trace[it]-=g_trace[it];

			/* cross-correlate super trace 1 with super trace 2 */
			window(g_trace, nt, ntcc, cc_tr);
	  		window(model_trace, nt, ntcc, filter);

	 		ints8r(ntcc,dt,0.0,cc_tr,0.0,0.0,nt_r,t,cc_tr_r);
	  		ints8r(ntcc,dt,0.0,filter,0.0,0.0,nt_r,t,filter_r);

	  		xcor(nt_r, 0, cc_tr_r, nt_r, 0, filter_r,
				ntout, -nt_r + 1, corr_trace);


			/* pick cross-correlation peak */ 
			window(corr_trace, ntout, ntpick, pick_tr);
	  		tlag = max(pick_tr, mode, perc, ntpick);

			/* remember the initial estimation and the total correction */
			rstat[irec] = tlag;
	 		trstat[irec] += tlag;

			}

			/* end shot receivers  loop */


			/* correct traces for receiver statics */ 
			for (ishot=1; ishot<=ns; ishot++){
	 		 for (ichan=1; ichan<=sfold; ichan++){
				itr = (ishot-1)*sfold + ichan;
				irec = ishot - 1  + ichan;
				j = rstat[irec];

				for (it=0; it<nt; ++it) t[it] = it*dt - j*0.001;
				ints8r(nt, dt, 0.0, data[itr], 0.0, 0.0, nt, t, g_trace);
				for (it=0; it<nt; it++) data[itr][it] = g_trace[it];
			}
		}

	}
	/* end iterations */

	/* output final statics */ 
        fps    = efopen(ssol,"w+");
        for (ishot=1; ishot<=ns; ishot++) fprintf(fps,"%i\n",tsstat[ishot]);
        efclose(fps);

        fpr    = efopen(rsol,"w+");
        for (irec=1; irec<=nr; irec++) fprintf(fpr,"%i\n",trstat[irec]);
        efclose(fpr);

	return EXIT_SUCCESS;
}

void window (float *trace, int nt, int nnt, float *ntrace)
{
	int j;	
	int ft;	
	
	if (nnt%2 == 0) ++nnt;
	ft = (nt - 1)/2 - (nnt - 1)/2;
	for (j = 0; j < nnt; j++) {
		ntrace[j] = trace[j+ft];
	}
}

int max (float *trace, int mode, float perc, int nt)
{
	float maxamp = 0.;	/* max. amplitude sample rate */
	int globmax = 0;	/* sample of global max value */
	int locmax = 0;		/* sample of local max value */
	int zero; 		/* zero-lag sample */
	int lag = 0; 		/* lag picked */
	int j;			/* counter */

	/* Set parameters */
	if (nt%2 == 0) ++nt;
	zero = (nt-1)/2;
	perc = 1.0-(perc/100);

	/* determine global max for each trace*/
	for (j = 0; j < nt; j++) {
		if (trace[j] > maxamp) {
			maxamp = trace[j];
			globmax = j;
		}
	}
	if (mode == 1) {
	/* determine max within perc% of global max, but closer to zero lag*/
		for (j = 0; j < nt; j++) {
			if ((trace[j] > perc*maxamp) && 
			  (ABS(j-zero) < ABS(locmax-zero))) 
				locmax = j;
		}
	}

	/* Output the result */
	switch(mode) {
		case 0:
			lag = globmax - zero;
			break;
		case 1:
			lag = locmax - zero;
			break;
	}
	return lag;
}
