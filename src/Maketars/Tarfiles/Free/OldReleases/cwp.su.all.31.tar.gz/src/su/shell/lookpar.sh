#! /bin/sh
# /*********************** self documentation **********************/
# LOOKPAR - show getpar lines in SU code with defines evaluated
#
# Usage: lookpar filename ...
#
# /**************** end self doc ********************************/

# $Source: /NeXTMount_3.2/usr/local/cwp/src/su/shell/RCS/lookpar.sh,v $
# $Revision: 1.9 $ ; $Date: 95/03/23 11:32:35 $

# Note: "cc -E" could be used on many (all?) systems instead of /lib/cpp

# test for CWPROOT
if test "${CWPROOT}" = ""
then
	echo "The environment variable \"CWPROOT\" "
	echo "is not set in the user's working shell environment."
	echo "To set this variable in C-shell, use the command: "
	echo "  setenv  CWPROOT  /your/cwp/root/path"
	echo "To set this variable in Bourne or Korn-shell, use the command:"
	echo "  export  CWPROOT=/your/cwp/root/path" ; exit 1

fi


ROOT=${CWPROOT}
BIN=$ROOT/bin
SU=$ROOT/src/su
I=$ROOT/include

PATH=/bin:/usr/bin:/usr/ucb:$BIN


cmd=`basename $0`

case $# in
0)
	echo "Usage: $cmd file(s)" 1>&2; exit 1
;;
esac

/lib/cpp -I$I $* | grep getpar |
grep -v initgetpar | grep -v "*name" | grep -v "*s"
#grep -v extern | grep -v initgetpar | grep -v "*name" | grep -v "*s"
exit 0
