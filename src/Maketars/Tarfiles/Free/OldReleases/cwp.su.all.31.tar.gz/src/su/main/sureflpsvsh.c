/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

#include "su.h"
#include "segy.h"
#include "header.h"

/*********************** self documentation **********************/
char *sdoc[] = {
"									",
" SUREFLPSV - REFlectivity modeling of either PSV or SH waves for layered",
"		earth model						",
"									",
" surelfpsv  required parameters [optional parameters]	 		",
"									",
" Required Parameters:							",
" m0=			Seismic moment					",
" p2w=			maximum ray parameter value to which the	",
"			synthetics are computed				",
"									",
" Optional Parameters:							",
" Main Flags:								",
" wtype=1		=1 for PSV, =2 for SH				",
" stype=1		=1 if the moemnt tensor components are given	",
"			=2 if they are to be computed from fault	",
"			 plane mechanism parameters			",
" wfield=2		=1 for displacement, =2 for particle velocity,	",
"			=3 for particle acceleration			",
" flt=0			=1 to apply earth flattening correction		",
"			(important for earthquake data)			",
" vsp=0			=0 for surface data, =1 for VSP data		",
" int_type=1		=1 to compute the slowness integration using	",
"			the trapezoidal rule. =2 to use a first order	",
"			Filon scheme (faster but maybe noisier)		",
" verbose=0		=0 no processing information is output (makes	",
"			the program run a litle faster), =1 to output	",
"			processing information to the screen, =2 to	",
"			output processing information to a user		",
"			supplied file, =3 output processing		",
"			information to both, the screen and a file	",
"									",
" Flags for special non-standard options (used only in rare ocasions)	",
" rand=0		=1 to include random velocity and q layers	",
" qopt=0		=1 if a q-correction is desired			",
"									",
" Flags for output data							",
" win=0			=1 to apply a frequency domain Hanning		", 
"			window prior to inverse FFT to time domain	",
" wavelet_type		=1 for a spike, =2 for a Ricker wavelet		",
"			=3 for an akb wavelet				",
"									",
" Main input parameters							",
" tsec=2.048		length of computed traces (in seconds)		",
" dt=0.004		time sampling interval (in seconds)		",
" nt=tsec/dt		number of samples per trace			",
" nx=60			number of traces (ranges) per shot		",
" nw=100		number of frequencies to process		",
" nor=1			number of depths at which receivers are		",
"			located (different from one for VSP's)		",
" nlayers=10		number of horizontal layers in the model	",
" fref=1.0		reference frequency (Hz)			",
" bx=0.0 		first range (first trace offset) (km)		",
" dx=0.05		range increment (trace to trace distance) km	",
" pw1=0.0 pw2=0.0	apply Hanning window tapering to lower end	",
"			of ray parameter computations (if set to zero	",
"			good default values are used)			",
" pw3=0.0 pw4=0.0	apply Hanning window tapering to higher end	",
"			of ray parameter computations (if set to zero	",
"			good default values are used)			",
" fs=0.07		Filon sampling parameter, usually between	",
"			0.07 and 0.12. Sampling is finer as fs		",
"			increases. For short range synthetics		",
"			(<100km) use 0.07, for medium range (<1000km)	",
"			use 0.09 and for large	ranges (>1000km) use	",
"			0.12 (this parameter is ignored if int_type=1)	",
" np=1300		number of ray parameters used to compute the	",
"			seismograms. Automatically set if int_type=2	",
" bp=0.0		slowest ray parameter used to compute the	",
"			seismograms. Set to zero if int_type=2		",
" decay=50.0		decay factor use to avoid time series		",
"			wraparound. A value 'n' for decay means that	",
"			the wrapped around signals are diminished by	",
"			a factor of 'n'. The default of 50 is the	",
"			recomended value				",
" lobs=			array[nor] of layers on top of which the	",
"			receivers are located. If any receiver is	",
"			within a layer, introduce a ficticious layer	",
" cl=			array[nlayers] of compressional velocities	",
"			for each layer in km/s				",
" ct=			array[nlayers] of shear velocities for each	",
"			layer in km/s. A value of -1 assumes		",
"			ct=cl/sqrt(3.					", 
" ql=			array[nlayers] of compressional q values	",
"			for each layer					",
" qt=			array[nlayers] of shear q values for each	",
"			layer. A value of -1 assumes qt=ql/2.		",
" rho=			array[nlayers] of densities for each layer	",
"			in gr/cc					",
" t=			absolute thickness of the layer in kms		",
"									",
" Note: any of these arrays can also be input in a file as lobsfile=,clfile=,",
" ctfile=, etc.								",
"									",
" Source parameters:							", 
" lsource=1		layer on top of which the source is located	",
" h1=1.0 h2=0.0		vertical and horizontal linear part of the	",
"			source. For unit point source set h1=0, h2=0	",
"  			and all other source parameters to zero. For	",
"			earthquake source both h1 and h2 are usually	",
"			zero					 	",
" m1,m2,m3		[1][1],[1][2] and [2][2] components of the	",
"			moment tensor ([1][2]=[2][1] component)		",	
" delta=0.0		dip in degrees (necessary only if stype=1)	",
" lambda=0.0		rake in degrees (necessary only if stype=1)	",
" phis=0.0		fault plane azimuth in degrees (necessary	",
"			only if stype=1)				",
" phi=0.0		azimuth of the receiver location in degrees	",
"			(necessary only if stype=1)		  	",
" Parameters for output data:						",
" tlag=0.0		time lag to appy to the  seismograms (sec)	",
" nf=nw			number of frequencies in output data		",
" fpeak=25.0		peak frequency for Ricker or akb wavelet (hz)	",
" red_vel=0.0		reducing velocity (km/s). If set to zero, the	",
"			maximum compressional velocity is used		",
"			(this parameter is garanteed not to be <1.5)	",
" w1=0.0		A Hanning window will be applied to freqs	",
"			less than w1.If set to zero, the default of	",
"			0.15 of maximum frequency is used (provided	",
"			that win=1)					",
" w2=0.0		A Hanning window will be applied to freqs	",
"			greater than w2. If set to zero, the default	",
" 			0.85 of maximum frequency is used (provided	",
"			that win=1)					",
" nfilters=0		number of filters to apply to the synthetics	",
" filters_phase=	array[nfilters] of: 0 for zero phase filters	", 
" 			or 1 for minimum phase filters(can also be	",
"			input in a file via fphfile=			",
" filters_type=		array[nfilters] of: 1 for high cut filters,	",
"			input in a file via filphasefile=		",
" 			2 for low cut filters, 3 for notch filters	",
"			(can also be input in a file via filtypefile=)	",
" dbpo=			array[nfilters] of: filter slopes in db/oct	",
"			(can also be input in a file via dbpofile=)	",
" f1=			array[nfilters] of: frequency to start filter	",
"			action (Hz)(can also be input in a file via	",
"			f1file=)					",
" f2=			array[nfilters] of: frequency to end filter	",
"			action (Hz). Only for notch filters		",
"			(can also be input in a file via f2file=)	",
" wfp=pressure		name of output pressure seismogram file		",
"			(only if wtype=1)				",
" wfr=radial		name of output radial comp seismogram file	",
"			(only if wtype=1)				",
" wfz=verical		name of output vertical comp seismogram file	",
"			(only if wtype=1)				",
" wft=tangential	name of output tangential comp seismogram file	",
"			(only if wtype=1)			  	",
" outf=info		name of output processing information file	",
"			(only if verbos=2 or 3)				",
"									",
" Interpolation parameters (required only if layers with gradients desired)",
" nlint=0		number of times layer interp is required	",
" nintlayers=		array[nlint] of number of layers to interpol	",
"			each time (can be input as file nintlayfile=)	", 
" intlayers=		array[nlint] of layers on top of which to	",
"			start each interpolation			",
"			(can be input as file intlayfile=)		",
" intlayth=		array[nlint] of layer thicknesses to interp	",
"			(can be input as file intlaythfile=)		",
"									",
" Other parameters (required only under very special circumstances)	",
" nrand_layers=0	maximum number of random layers allowed		",
"			(only if rand=1)				",
" layer=0		layer on top of which the random velocity	",
"			layers are inserted (only if rand=1)		",
" zlayer=0.0		thickness of random layers (only if rand=1)	",
"   			(if zlayer<t[il], then zlayer=t[il])		",
" sdcl=0.0		standard deviation for compressional vels	",
"			(only if rand=1)				",
" sdct=0.0		standard deviation for shear velocities		",
"			(only if rand=1)				",
" layern=0		layer on top of which the q-option is invoked	",
"			(only if qopt=1)				",
" wrefp=1.0		reference frequency for compressional vels	",
"			(only if qopt=1)				",
" wrefs=1.0		reference frequency for shear velocities	",
"			(only if qopt=1)				",
" epsp=0.001		reference amplitude for comporessional vels	",
"			(only if qopt=1)				",
" epss=0.001		reference amplitude for shear velocities	",
"			(only if qopt=1)				",
" sigp=0.1		xxxxxx for comporessional vels			",
"			(only if qopt=1)				",
" sigs=0.1		xxxxxx for shear velocities		  	",
"			(only if qopt=1)				",
" Notes:								",
" Gradient zones between two layers can be handled with the use of the	",
" layer interpolation option. The program will automatically compute and",
" insert the required number of layers with the appropriate thicknesses	",
" between the layers above and below. There is no restriction as to how	",
" many layers the program can handle, provided enough computer power is	",
" available.								",
"									",
" The number of frequencies to be processed is the most critical parameter",
" to determine how long the program will take to run. The maximum frequency",
" that can be present in the seismogram is nw/tsec Hz, however, a lower	",
" frequency can be selected for the output via the nf param.		",
"									",
" The number of computed time samples is tsec/dt, however, the user may	",
" choose a smaller number of samples for the output traces by setting	",
" nt this can be useful when a short seismogram is required with a	",
" broadband frequency range (directly computing a small seismogram can	",
" be hazardous)								",
"									",
" The decay parameter should be chosen with care. A value of 50 seems	",
" to give good results, but depending on the data this parameter can	",
" boost up late wrapped around noncausal energy.			", 
"									",
" The integration flag is important for short range data, in particular ",
" for oil exploration, for which the first order Filon scheme, though	",
" faster, can produce noisier seismograms, specialy in the late parts of",
" the record. A standard trapezoidal rule seems to work better but is	",
" slower by about 25% in a normal situation.				",
"									",
" When arrays are required as input, they can also be input as files,	",
" however, the program will only check that the number of parameters is ",
" the same if the arrays are used or if the number of elements in the	",
" files are set. A combination of arrays and files is also permited.	",
"									",
" Examples of Source Parameters:					",
" For a vertical point force, set stype=1, h1=1, h2=0 and all moment	",
" tensor components to zero. Ignore all other source parameters.	",
" For an explosion, set stype=1, h1=h2=0, m1=m3=A, m2=0 where A is some	",
" constant (normally one). If A is negative, an implosion is generated	",
" instead.  Ignore all other source parameters.				",
" For a fault slip, set stype=2, set phis,phi,lambda,alpha and m0 to their",
" corresponding values and ignore the moment tensor components		",
"									",
NULL};

/*
 * Credits:
 *
 * Original Fortran 77 PSV version written by Subshashis Mallick (1988)
 * Original Fortran 77 SH version written by Mrinal Sen (1988) based on the 
 * PSV version by Subshashis Mallick 
 * Translated to C, expanded and reformatted for SU by Gabriel Alvarez (1995)
 *
 * References:
 * The reflectivity method: a tutorial. G Muller. J. Geophysics(1985)
 *	v. 58.  153-174
 * Practical aspects of reflectivity modeling. Mallick and Frazer. Geophysics
 *	v. 52 No. 10. October 1987. 1355-1364
 *
 */
/************************** end self doc *************************************/

/* Prototypes for subroutines used internally */
void compute_reflectivities (int int_type, int verbose, int wtype, int wfield,
	int vsp, int flt, int win, int nx, int nt, int ntc, int nor, int nf,
	int nlayers, int lsource, int layern, int nfilters, int *filters_phase,
 	int nw, int np, float bp, float tlag, float red_vel, float w1,float w2,
 	float fx, float dx, float bx, float fs, float decay, float p2w,
	float tsec, float fw, float wrefp, float wrefs, float epsp, float epss,
	float sigp, float sigs, float pw1, float pw2, float pw3, float pw4,
	float h1, float h2, float m1, float m2, float m3, float fref, int *lobs,
	int *filters_type, float *dbpo, float *f1, float *f2, float *cl,
	float *ct, float *ql, float *qt, float *rho, float *t,
	float **wavefield1, float **wavefield2, float **wavefield3,
	FILE *outfp);

void convolve_wavelet (int wavelet_type, int nx, int nt, float dt, float fpeak, 
	float **wfieldx);

void compute_synthetics (int verbose, int nt, int ntc, int nx, int nor, int nw,
    int nlayers, int lsource, int nf, int flt, int vsp, int win, int wtype,
    float tlag, float red_vel, float decay, float tsec, float bx, float dx,
    float w1, float w2, int *fil_phase, int nfilters, int *fil_type,
    float *dbpo, float *f1, float *f2, int *lobs, float *cl, float *t, 
    complex ***response, float **reflectivity, FILE *outfp);

void red_vel_factor (float x, float red_vel, float tlag, complex wpie,
    complex wsq, complex *rvfac);

void construct_tx_trace (int nw, int nt, int ntc, int ntfft, int nfilters,
    int *min_phase, float tsec, float unexp, float sphrd, complex *refw,
    int *fil_type, float *f1, float *f2, float *dbpo, float *reft);

void compute_Hanning_window (int iwin, int iw, int if1, int if2, int nw,
    complex *win);

void apply_filters (int *min_phase, int nfilters, int nw, float tsec, float *f1,
    float *f2, float *dbpo, int *filtype, complex *refw);

void compute_w_aux_arrays (int wtype, int layern, int nlayers, int nor,
    int lsource, int *np, int *block_size, int *nblock, int *left, float fw,
    float wrefp, float wrefs, int *lobs, float tsec, float p2w, float fs,
    float xmax, float w, float decay, float epsp, float epss, float sigp,
    float sigs, float *pw1, float *pw2, float *pw3, float *pw4, float *dp,
    float *fp, complex wpie, complex *cdp, float *cl, float *ct, float*ql,
    float *qt, float *rho, float *t, complex *al, complex *at, complex *prs);

void compute_p_aux_arrays (int wtype, int nlayers, int lsource, int block_size,
    float bp, float dp, float w, float decay, float pw1, float pw2,
    float pw3, float pw4, complex *pwin, float m1, float m2, float m3, float h1,
    float h2, complex wpie, complex *divfac, complex *p, complex *pp,
    complex *al, complex *at, float *rho, complex *gl, complex *gt,
    complex *gam, complex *alpha, complex *betha, complex *sigmad1,
    complex *sigmad2, complex *sigmau1, complex *sigmau2) ;

void source_receiver_type (int nor, int nlayers, int lsource, int  *lobs,
    float *cl, float *ct, int *acoust, int *flag);

void compute_slowness (int wtype, int lsource, float w, float p2w, int *np,
    float *fp, float fs, float e4, float dk, float decay, float xmax, float *dp,
    float *pw1, float *pw2, float *pw3, float *pw4, complex *cdp, float *cl,
    float *ct, float *t);
   
void compute_al_at (int wtype, int nlayers, int layern, float eps, float epsp,
    float epss, float sigma, float sigp, float sigs, float *wrefp, float *wrefs,
    float fw, float *cl, float *ct, float *ql, float *qt, float *rho,
    complex wpie, complex *al, complex *at);

void compute_prs (int nor, int *lobs, complex *al, complex *at, float *rho,
    complex *prs);

void compute_block_size (int np, int *block_size, int *nblock, int *left);

void compute_pwin (int wtype, int block_size, float bp, float dp, float w,
    float decay, float pw1, float pw2, float pw3, float pw4, complex *pwin,
    complex *p, complex *pp);

void compute_gl_gt_gam (int wtype, int nlayers, int block_size, complex *al,
    complex *at, float *rho, complex *pp, complex *gl, complex *gt,
    complex *gam);

void compute_alpha_betha (int lsource, int block_size, complex ats, float rhos,
    complex *gl, complex *gt, complex *alpha, complex *betha);

void compute_sigmas (int wtype, int block_size, int lsource, float m1,
    float m2, complex meu, complex *alpha, complex *betha, complex *p,
    complex *gl, complex *gt, complex *gam, complex a2, complex a3,
    complex *pwin, complex s1, complex s2, complex s4, complex *sigmau1,
    complex *sigmau2, complex *sigmad1, complex *sigmad2);

void compute_moment_tensor (int wtype, float phi, float lambda, float delta,
    float phis, float m0, float *m1, float *m2, float *m3);

void parameter_interpolation (int nlayers, int *intlayers, int *nintlayers,
    float *intlayth, float *cl, float *ql, float *ct, float *qt, float *rho,
    float *t) ;

void random_velocity_layers (int *nlayers, int *lsource, int nrand_layers,
    float sdcl, float sdct, float layer, float zlayer, float *cl, float *ql,
    float *ct, float *qt, float *rho, float *t);

void apply_earth_flattening (int nlayers, float z0, float *cl, float *ct,
    float *rho, float *t);

void psv_reflectivities (int int_type, int verbose, int wtype, int nw,
    int nlayers, int nx, int layern, int nor, int np, float bp1, float m1,
    float m2, float m3, float h1, float h2, int lsource, float bx, float dx,
    float xmax, float decay, float fref, float wrefp, float wrefs, float tsec,
    float p2w, float fs, float epsp, float epss, float sigp, float sigs,
    float pw1, float pw2, float pw3, float pw4, int *acoustic, int *flag,
    int *lobs, float *rho, float *t, float *cl, float *ct, float *ql, float *qt,
    complex ***response1, complex ***response2, complex ***response3,
    FILE *outfp);

void sh_reflectivities (int int_type, int verbose, int wtype, int nw,
    int layers, int nx, int layern, int nor, int np, float bp1, float m1,
    float m2, float m3, float h1, float h2, int lsource, float bx, float dx,
    float xmax, float decay, float fref, float wrefp, float wrefs, float tsec,
    float p2w, float fs, float epsp, float epss, float sigp, float sigs,
    float pw1, float pw2, float pw3, float pw4, int *flag, int *lobs,
    float *rho, float *t, float *cl, float *ct, float *ql, float *qt,
    complex ***response1, FILE *outfp);

/*
#define CONE (complex) cmplx(1.0,0.0)
#define CIMAG (complex) cmplx(0.0,1.0)
#define CZERO (complex) cmplx(0.0,0.0)
*/

#define RSO 6371.0

segy tr1,tr2,tr3;


int main(int argc, char **argv)
{
	int i,ix,it;		/* loop counters */
	int wtype;		/* =1 psv. =2 sh wavefields */
	int wfield;		/* =1 displcement =2 velocity =3 acceleration */
	int stype;		/* source type */
	int int_type;		/* =1 for trapezoidal rule. =2 for Filon */
	int flt;		/* =1 apply earth flattening correction */
	int rand;		/* =1 for random velocity layers */
	int qopt;		/* some flag ???? */
	int vsp;		/* =1 for vsp, =0 otherwise */
	int win;		/* =1 if frequency windowing required */
	int verbose;		/* flag to output processing information */
	int nt;			/* samples per trace in output traces */
	int ntc;		/* samples per trace in computed traces */
	int nx;			/* number of output traces */
	int np;			/* number of ray parameters */
	int nlint;		/* number of times layer interp is required */
	int lsource;		/* layer on top of which the source is located*/
	int nw;			/* number of frequencies */
	int nor;		/* number of receivers */
	int nlayers;		/* number of reflecting layers */
	int layern;
	int nrand_layers;	/* maximum number of random layers permitted */
	int nf;			/* number of frequencies in output traces */
	int *filters_phase;	/* =0 for zero phase, =1 for minimum phase fil*/
	int nfilters;		/* number of required filters */
	int wavelet_type;	/* =1 spike =2 ricker1 =3 ricker2 =4 akb */

	float dt;		/* time sampling interval */
	float tsec;		/* trace length in seconds */
	float fpeak;		/* peak frequency for output wavelet */
	float fref;		/* first frequency */
	float p2w;		/* maximum ray parameter value */
	float bp;		/* smallest ray parameter (s/km) */
	float bx;		/* beginning of range in Kms. */
	float fx;		/* final range in Kms. */
	float dx;		/* range increment in Kms. */
	float pw1,pw2,pw3,pw4;	/* window ray parameters (to apply taper) */
	float h1;		/* horizontal linear part of the source */ 
	float h2;		/* vertical linear part of the source */ 
	float m0;		/* seismic moment */
	float m1,m2,m3;		/* components of the moment tensor */

	float delta;		/* dip */
	float lambda;		/* rake */
	float phis;		/* azimuth of the fault plane */
	float phi;		/* azimuth of the receiver location */

	float sdcl,sdct;	/* standar deviation for p and s-wave vels */
	float z0=0.0;		/* reference depth */
	float zlayer;		/* thickness of random layers */
	int layer;		/* layer over on top of which to compute rand*/
	float tlag;		/* time lag in output traces */
	float red_vel;		/* erducing velocity */

	float w1;		/* low end frequency cutoff for taper */
	float w2;		/* high end frequency cutoff for taper */
	float wrefp;		/* reference frequency for p-wave velocities */
	float wrefs;		/* reference frequency for s-wave velocities */

	float epsp;		/* .... for p-wave velocities */
	float epss;		/* .... for p-wave velocities */
	float sigp;		/* .... for p-wave velocities */
	float sigs;		/* .... for s-wave velocities */
	float fs;		/* sampling parameter, usually 0.07<fs<0.12 */
	float decay;		/* decay factor to avoid wraparound */

	int *lobs;		/* layers on top of which lay the receivers */
	int *nintlayers;	/* array of number of layers to interpolate */
	int *filters_type;	/* array of 1 lo cut, 2 hi cut, 3 notch */

	float *dbpo;		/* array of filter slopes in db/octave */
	float *f1;		/* array of lo frequencies for filters */
	float *f2;		/* array of high frequencies for filters */
	float *cl;		/* array of compressional wave velocities */
	float *ql;		/* array of compressional Q values */
	float *ct;		/* array of shear wave velocities */
	float *qt;		/* array of shear Q values */
	float *rho;		/* array of densities */
	float *t;		/* array of absolute layer thickness */

	int *intlayers;		/* array of layers to interpolate */

	float *intlayth;	/* array of thicknesses over which to interp */
	float **wavefield1;	/* array for pressure wavefield component */
	float **wavefield2;	/* array for radial wavefield component */
	float **wavefield3;	/* array for vertical wavefield component */

	char *lobsfile="";	/* input file receiver layers */
	char *clfile="";	/* input file of p-wave velocities */
	char *qlfile="";	/* input file of compressional Q-values */
	char *ctfile="";	/* input file of s-wave velocities */
	char *qtfile="";	/* input file of shear Q-values */
	char *rhofile="";	/* input file of density values */
	char *tfile="";		/* input file of absolute layer thicknesses */
	char *intlayfile="";	/* input file of layers to interpolate */
	char *nintlayfile="";	/* input file of number of layers to interp */
	char *intlaythfile="";	/*input file of layer thickness where to inter*/
	char *filtypefile="";	/* input file of filter types to apply */
	char *fphfile="";	/* input file of filters phases */
	char *dbpofile="";	/* input file of filter slopes in db/octave */
	char *f1file="";	/* input file of lo-end frequency */
	char *f2file="";	/* input file of hi-end frequency */

	char *wfp="";		/* output file of pressure */
	char *wfr="";		/* output file of radial wavefield */
	char *wfz="";		/* output file of vertical wavefield */
	char *wft="";		/* output file of tangential wavefield */
	char *outf="";		/* output file for processing information */

	FILE *wfp_file;		/* file pointer to output pressure */
	FILE *wfr_file;		/* file pointer to output radial wavefield */
	FILE *wfz_file;		/* file pointer to output vertical wavefield */
	FILE *wft_file;		/* file pointer to output tangential wavefield*/
	FILE *outfp;		/* file pointer to processing information */
	FILE *infp;		/* file pointer to input information */

	
	/* hook up getpar to handle the parameters */
	initargs(argc,argv);
	requestdoc(0);			/* no input data */

	/* get required parameter, seismic moment */
	if (!getparfloat("m0",&m0))	
		err("error: the seismic moment, m0, is a required parameter\n");

	/*********************************************************************/
	/* get general flags and set their defaults */
	if (!getparint("rand",&rand))			rand	= 0;
	if (!getparint("qopt",&qopt))			qopt	= 0;
	if (!getparint("stype",&stype))			stype	= 1;
	if (!getparint("wtype",&wtype))			wtype	= 1;
	if (!getparint("wfield",&wfield))		wfield	= 1;
	if (!getparint("int_type",&int_type))		int_type= 1;
	if (!getparint("flt",&flt))			flt	= 0;
	if (!getparint("vsp",&vsp))			vsp	= 0;
	if (!getparint("win",&win))			win	= 0;
	if (!getparint("wavelet_type",&wavelet_type))	wavelet_type = 1;
	if (!getparint("verbose",&verbose))		verbose	= 0;

	/* get model parameters and set their defaults */
	if (!getparint("lsource",&lsource))		lsource = 0;
	if (!getparfloat("fs",&fs)) 			fs	= 0.07;
	if (!getparfloat("decay",&decay))		decay	= 50.0;
	if (!getparfloat("tsec",&tsec))			tsec	= 2.048;

	/* get response parameters and set their defaults */
	if (!getparfloat("fref",&fref))			fref	= 1.0;
	if (!getparint("nw",&nw))			nw	= 100;
	if (!getparint("nor",&nor))			nor	= 100;
	if (!getparint("np",&np))			np	= 1300;
	if (!getparfloat("p2w",&p2w))			p2w	= 5.0;
	if (!getparfloat("bx",&bx))			bx	= 0.005;
	if (!getparfloat("bp",&bp))			bp	= 0.0;
	if (!getparfloat("fx",&fx))			fx	= 0.1;
	if (!getparfloat("dx",&dx))			dx	= 0.001;
	if (!getparfloat("pw1",&pw1))			pw1	= 0.0;
	if (!getparfloat("pw2",&pw2))			pw2	= 0.1;
	if (!getparfloat("pw3",&pw3))			pw3	= 6.7;
	if (!getparfloat("pw4",&pw4))			pw4	= 7.0;
	if (!getparfloat("h1",&h1))			h1	= 1.0;
	if (!getparfloat("h2",&h2))			h2	= 0.0;

	/* get output parameters and set their defaults */
	if (!getparint("nx",&nx))			nx	= 100;
	if (!getparfloat("dt",&dt))			dt	= 0.004;
	if (!getparint("nt",&nt))			nt	= tsec/dt;
	if (!getparint("nf",&nf))			nf	= 50;
	if (!getparfloat("red_vel",&red_vel))		red_vel	= 5;
	if (!getparfloat("fpeak",&fpeak))		fpeak	= 25.;
	if (!getparfloat("tlag",&tlag))			tlag	= 0.;

	/* get names of output files */
	if (wtype==1) {
		getparstring ("wfp",&wfp);
		getparstring ("wfr",&wfr);
		getparstring ("wfz",&wfz);
	} else if (wtype==2) {
		getparstring ("wft",&wft);
	} else err ("wtype has to be zero or one");

	/*********************************************************************/
	/* get or compute moment tensor components */
	if (stype==1) {

		/* get source parameters */
		if (!getparfloat("delta",&delta))	
			err("if stype==1, delta is a required parameter\n");
		if (!getparfloat("lambda",&lambda))	
			err("if stype==1, lambda is a required parameter\n");
		if (!getparfloat("phis",&phis))	
			err("if stype==1, phis is a required parameter\n");
		if (!getparfloat("phi",&phi))	
			err("if stype==1, phi is a required parameter\n");

		/* compute moment tensor components */
		compute_moment_tensor (wtype, phi, lambda, delta, phis, m0, 
			&m1, &m2, &m3);

	} else if (stype==2) {

		/* get moment tensor components from input */	
		if (!getparfloat("m1",&m1))	
			err("if stype==2, m1 is a required parameter\n");
		if (!getparfloat("m2",&m2))	
			err("if stype==2, m2 is a required parameter\n");
		if (!getparfloat("m3",&m3))	
			err("if stype==2, m3 is a required parameter\n");

	} else err("error, stype flag has to be one or two\n");

	/*********************************************************************/
	/* if q-option is not requesed, set corresponding parameters to zero */
	if (!getparint("layern",&layern))		layern	=0;	
	if (!getparfloat("wrefp",&wrefp))		wrefp	=0.0;
	if (!getparfloat("wrefs",&wrefs))		wrefs	=0.0;
	if (!getparfloat("epsp",&epsp))			epsp	=0.0;
	if (!getparfloat("epss",&epss))			epss	=0.0;
	if (!getparfloat("sigp",&sigp))			sigp	=0.0;
	if (!getparfloat("sigs",&sigs))			sigs	=0.0;

	/*********************************************************************/
	/* get number of layers and check input parameters */
	if (*clfile=='\0') {	/* p-wave vels input from the comand line */
		nlayers=countparval("cl");
	} else  {		/* p-wave vels input from a file */
		getparint("nlayers",&nlayers);
	}
	if (*ctfile=='\0') {	/* s-wave vels input from the comand line */
		if (nlayers !=countparval("cl")) 
			err("number of p-wave and s-wave velocities"
				"has to be the same");
	}
	if (*qlfile=='\0') { 	/* compressional q-values from comand line */
		if (nlayers !=countparval("ql")) 
			err("number of p-wave velocities and q-values"
				"has to be the same");
	}
	if (*qtfile=='\0') { 	/* shear q-values input from comand line */
		if (nlayers !=countparval("qt")) 
			err("number of p-wave velocities and shear q-values"
				"has to be the same");
	}
	if (*rhofile=='\0') { 	/* densities input from comand line */
		if (nlayers !=countparval("rho")) 
			err("number of p-wave velocities and densities"
				"has to be the same");
	}
	if (*tfile=='\0') { 	/* layer thicknesses input from comand line */
		if (nlayers !=countparval("t")) 
			err("number of p-wave velocities and thicknesses"
				"has to be the same");
	}
	if (int_type!=1 && int_type!=2) err("int_type flag has to be one or two");

	/*********************************************************************/
	/* if layer interpolation is requested, get parameters */
	if (*intlayfile !='\0') {
		getparint("nlint",&nlint);
		if ((infp=fopen(intlayfile,"r"))==NULL)
			err("cannot open file of layer interp=%s\n",intlayfile);
		intlayers=alloc1int(nlint);
		fread (intlayers,sizeof(int),nlint,infp);
		fclose(infp);
	} else if (countparval("intlayers") !=0) {
		nlint=countparval("intlayers");
		intlayers=alloc1int(nlint);
		getparint("intlayers",intlayers);
	}
	if (*nintlayfile !='\0') {
		if ((infp=fopen(nintlayfile,"r"))==NULL)
			err("cannot open file of layer inter=%s\n",nintlayfile);
		nintlayers=alloc1int(nlint);
		fread (nintlayers,sizeof(int),nlint,infp);
		fclose(infp);
	} else if (countparval("nintlayers") !=0) {
		if (nlint !=countparval("nintlayers")) 
			err("number of values in intlay and nintlay not equal");
		nintlayers=alloc1int(nlint);
		getparint("nintlayers",nintlayers);
	}
	if (*intlaythfile !='\0') {
		if ((infp=fopen(intlaythfile,"r"))==NULL)
			err("cannot open file=%s\n",intlaythfile);
		intlayth=alloc1float(nlint);
		fread (intlayth,sizeof(int),nlint,infp);
		fclose(infp);
	} else if (countparval("intlayth") !=0) {
		if (nlint !=countparval("intlayth")) 
			err("# of values in intlay and intlayth not equal");
		intlayth=alloc1float(nlint);
		getparfloat("intlayth",intlayth);
	}
	/* update total number of layers */
	if (nlint!=0) {
		for (i=0; i<nlint; i++) nlayers +=intlayers[i]-1;
	}
		
	/*********************************************************************/
	/* if random velocity layers requested, get parameters */
	if (rand==1) {
		getparint("layer",&layer);
		getparint("nrand_layers",&nrand_layers);
		getparfloat("zlayer",&zlayer);
		getparfloat("sdcl",&sdcl);
		getparfloat("sdct",&sdct);
	} else nrand_layers=0;	

	/*********************************************************************/
	/* allocate space */
	cl = alloc1float(nlayers+nrand_layers);
	ct = alloc1float(nlayers+nrand_layers);
	ql = alloc1float(nlayers+nrand_layers);
	qt = alloc1float(nlayers+nrand_layers);
	rho = alloc1float(nlayers+nrand_layers);
	t = alloc1float(nlayers+nrand_layers);
	lobs = alloc1int(nor+1);
	lobs[nor]=0;

	/*********************************************************************/
	/* read  input parameters from files or command line */
	if (*clfile !='\0') {			/* read from a file */	
		if ((infp=fopen(clfile,"r"))==NULL)
			err("cannot open file of pwave velocities=%s\n",clfile);
		fread(cl,sizeof(float),nlayers,infp);
		fclose(infp);
	} else getparfloat("cl",cl);		/* get from command line */
	if (*qlfile !='\0') {
		if ((infp=fopen(qlfile,"r"))==NULL)
			err("cannot open file of compressional Q=%s\n",qlfile);
		fread(ql,sizeof(float),nlayers,infp);
		fclose(infp);
	} else getparfloat("ql",ql);
	if (*ctfile !='\0') {
		if ((infp=fopen(ctfile,"r"))==NULL)
			err("cannot open file of swave velocities=%s\n",ctfile);
		fread(ct,sizeof(float),nlayers,infp);
		fclose(infp);
	} else getparfloat("ct",ct);
	if (*qtfile !='\0') {
		if ((infp=fopen(qtfile,"r"))==NULL)
			err("cannot open file of shear Q=%s\n",qtfile);
		fread(qt,sizeof(float),nlayers,infp);
		fclose(infp);
	} else getparfloat("qt",qt);
	if (*rhofile !='\0') {
		if ((infp=fopen(rhofile,"r"))==NULL)
			err("cannot open file of densities=%s\n",rhofile);
		fread(rho,sizeof(float),nlayers,infp);
		fclose(infp);
	} else getparfloat("rho",rho);
	if (*tfile !='\0') {
		if ((infp=fopen(tfile,"r"))==NULL)
			err("cannot open file of thicknesses=%s\n",tfile);
		fread(t,sizeof(float),nlayers,infp);
		fclose(infp);
	} else getparfloat("t",t);
	if (*lobsfile !='\0') {
		if ((infp=fopen(lobsfile,"r"))==NULL)
			err("can't open file of receiver layers=%s\n",lobsfile);
		fread(lobs,sizeof(int),nor,infp);
		fclose(infp);
	} else getparint("lobs",lobs);

	/*********************************************************************/
	/* if requested, do interpolation and/or parameter adjustment */
	parameter_interpolation (nlayers, intlayers, nintlayers, 
		intlayth, cl, ql, ct, qt, rho, t);	

	/* if requested, compute random velocity layers */
	if (rand==1) {
		random_velocity_layers (&nlayers, &lsource, nrand_layers, sdcl,
			sdct, layer, zlayer, cl, ql, ct, qt, rho, t);
	}

	/* if requested, apply earth flattening approximation */
	if (flt==1) {
		apply_earth_flattening (nlayers, z0, cl, ct, rho, t);
	}


	/*********************************************************************/
	/* get filter parameters */
	if (*filtypefile !='\0') {
		if ((infp=fopen(filtypefile,"r"))==NULL)
			err("cannot open file=%s\n",filtypefile);
		getparint("nfilters",&nfilters);
		filters_type=alloc1int(nfilters);
		fread (filters_type,sizeof(int),nfilters,infp);
		fclose(infp);
	} else {
		nfilters=countparval("filters_type");
		filters_type=alloc1int(nfilters);
		getparint("filters_type",filters_type);
	}
	if (*fphfile !='\0') {
		if ((infp=fopen(fphfile,"r"))==NULL)
			err("cannot open file=%s\n",fphfile);
		filters_phase=alloc1int(nfilters);
		fread (filters_phase,sizeof(float),nfilters,infp);
		fclose(infp);
	} else if (nfilters == countparval("filters_phase")) {
		filters_phase=alloc1int(nfilters);
		getparint("filters_phase",filters_phase);
	} else err("number of elements infilterstype and phase must be equal");
	if (*dbpofile !='\0') {
		if ((infp=fopen(dbpofile,"r"))==NULL)
			err("cannot open file=%s\n",dbpofile);
		dbpo=alloc1float(nfilters);
		fread (dbpo,sizeof(float),nfilters,infp);
		fclose(infp);
	} else if (nfilters == countparval("dbpo")) {
		dbpo=alloc1float(nfilters);
		getparfloat("dbpo",dbpo);
	} else err("number of elements in filters_type and dbpo must be equal");
	if (*f1file !='\0') {
		if ((infp=fopen(f1file,"r"))==NULL)
			err("cannot open file=%s\n",f1file);
		f1=alloc1float(nfilters);
		fread (f1,sizeof(float),nfilters,infp);
		fclose(infp);
	} else if (nfilters == countparval("f1")) {
		f1=alloc1float(nfilters);
		getparfloat("f1",f1);
	} else err("number of elements in filters_type and f1 must be equal");
	if (*f2file !='\0') {
		if ((infp=fopen(f2file,"r"))==NULL)
			err("cannot open file=%s\n",f2file);
		f2=alloc1float(nfilters);
		fread (f2,sizeof(float),nfilters,infp);
		fclose(infp);
	} else if (nfilters == countparval("f2")) {
		f2=alloc1float(nfilters);
		getparfloat("f2",f2);
	} else err("number of elements in filters_type and f2 must be equal");
		

	/*********************************************************************/
	/* allocate space for wavefield computations */
	wavefield1=alloc2float(nt,nx);
	if (wtype==1) {
		wavefield2=alloc2float(nt,nx);
		wavefield3=alloc2float(nt,nx);
	}
	/* get name of output file for processing information */
	if (verbose==2||verbose==3) {
		if (!getparstring("outf",&outf))	outf="info";
		if ((outfp=fopen(outf,"w"))==NULL) {
			warn("cannot open processing file =%s, no processing\n"
			"information file will be generated\n",outf);
			verbose=1;
		}
	}

	/* initialize wavefields */
	if (wtype==1) {
		for (ix=0;ix<nx;ix++) {
			for (it=0;it<nt;it++) {
				wavefield1[ix][it]=0.0;
				wavefield2[ix][it]=0.0;
				wavefield3[ix][it]=0.0;
			}
		}
	} else if (wtype==2) {
		for (ix=0;ix<nx;ix++) {
			for (it=0;it<nt;it++) {
				wavefield1[ix][it]=0.0;
			}
		}
	}

	/* number of time samples in computed traces */
	ntc=tsec/dt;
	if (int_type==2) bp=0.0;

	/*********************************************************************/
	/* Now, compute the actual reflectivities */
	compute_reflectivities (int_type, verbose, wtype, wfield, vsp, flt,
		win, nx, nt, ntc, nor, nf, nlayers, lsource, layern, nfilters,
		filters_phase, nw, np, bp, tlag, red_vel, w1, w2, fx, dx, bx,
		fs, decay, p2w, tsec, fref, wrefp, wrefs, epsp, epss, sigp,
		sigs, pw1, pw2, pw3, pw4, h1, h2, m1, m2, m3, fref, lobs,
		filters_type, dbpo, f1, f2, cl, ct, ql, qt, rho, t, wavefield1,
		wavefield2, wavefield3, outfp);
	/*********************************************************************/

	/* if open, close processing information file */
	if (verbose==2||verbose==3) fclose(outfp);

	/* convolve with a wavelet and write the results out */
	if (wtype==1) {			/* PSV */
		
		/* convolve with a wavelet to produce the seismograms */
		convolve_wavelet (wavelet_type, nx, nt, dt, fpeak, wavefield1); 
		convolve_wavelet (wavelet_type, nx, nt, dt, fpeak, wavefield2); 
		convolve_wavelet (wavelet_type, nx, nt, dt, fpeak, wavefield3); 

		/* output results in SU format */
		if (*wfp !='\0') {
			if ((wfp_file=fopen(wfp,"w"))==NULL)
				err("cannot open pressure file=%s\n",wfp);
			{	register int ix;
				for (ix=0; ix<nx; ix++) {
					for (it=0; it<nt; it++)
						tr1.data[it]=wavefield1[ix][it];

					/* headers*/
					tr1.ns=nt;
					tr1.dt=1000*(int)(1000*dt);
					tr1.offset=(bx+ix*dx)*1000;
	
					/* output trace */
					fputtr(wfp_file, &tr1);
				}
				fclose (wfp_file);
			}
		}
		if (*wfr !='\0') {
			if ((wfr_file=fopen(wfr,"w"))==NULL)
					err("cannot open radial wfield file=%s\n",wfr);
			{	register int ix;
				for (ix=0; ix<nx; ix++) {
					for (it=0; it<nt; it++)
						tr2.data[it]=wavefield2[ix][it];
					tr2.ns=nt;
					tr2.dt=1000*(int)(1000*dt);
					tr2.offset=(bx+ix*dx)*1000;
					fputtr(wfr_file, &tr2);
				}
				fclose (wfr_file);
			}
		}
		if (*wfz !='\0') {
			if ((wfz_file=fopen(wfz,"w"))==NULL)
				err("canno open vertical field file=%s\n",wfz);
			{	register int ix;
				for (ix=0; ix<nx; ix++) {
					for (it=0; it<nt; it++)
							tr3.data[it]=wavefield3[ix][it];
					tr3.ns=nt;
					tr3.dt=1000*(int)(1000*dt);
					tr3.offset=(bx+ix*dx)*1000;
					fputtr(wfz_file, &tr3);
				}
				fclose (wfz_file);
			}
		}
		
		/* free allocated space */
		free2float(wavefield1);
		free2float(wavefield2);
		free2float(wavefield3);

	} else if (wtype==2) {			/* SH */

		/* convolve with a wavelet to produce the seismogram */
		convolve_wavelet (wavelet_type, nx, nt, dt, fpeak, wavefield1); 

		/* output the result in SU format */
		if (*wft !='\0') {
			if ((wft_file=fopen(wft,"w"))==NULL)
				err("cannot open tangential file=%s\n",wft);
			{	register int ix;
				for (ix=0; ix<nx; ix++) {
					for (it=0; it<nt; it++)
							tr1.data[it]=wavefield1[ix][it];
					tr1.ns=nt;
					tr1.dt=1000*(int)(1000*dt);
					tr1.offset=(bx+ix*dx)*1000;
					fputtr(wft_file, &tr1);
				}
				fclose (wft_file);
			}
		}

		/* free allocated space */
		free2float(wavefield1);
	}

	/* free workspace */
	free1float(cl);
	free1float(ct);
	free1float(ql);
	free1float(qt);
	free1float(rho);
	free1float(t);
	free1int(lobs);
	free1int(filters_type);
	free1int(filters_phase);
	free1float(dbpo);
	free1float(f1);
	free1float(f2);
	return EXIT_SUCCESS;
}


/******************************************************************************	

		Subroutine to compute psv or sh reflectivities

******************************************************************************/
void compute_reflectivities (int int_type, int verbose, int wtype, int wfield,
	int vsp, int flt, int win, int nx, int nt, int ntc, int nor, int nf,
	int nlayers, int lsource, int layern, int nfilters, int *filters_phase,
 	int nw, int np, float bp, float tlag, float red_vel, float w1,float w2,
 	float fx, float dx, float bx, float fs, float decay, float p2w,
	float tsec, float fw, float wrefp, float wrefs, float epsp, float epss,
	float sigp, float sigs, float pw1, float pw2, float pw3, float pw4,
	float h1, float h2, float m1, float m2, float m3, float fref, int *lobs,
	int *filters_type, float *dbpo, float *f1, float *f2, float *cl,
	float *ct, float *ql, float *qt, float *rho, float *t,
	float **wavefield1, float **wavefield2, float **wavefield3,
	FILE *outfp)
/******************************************************************************
Input:
int_type	=1 to compute the slowness integration by the trapezoidal rule
		=2 to use a first order Filon scheme
wtype		=1 for psv synthetics. =2 for sh synthetics
wfield		=1 for displacement, =2 for velocity, =3 for acceleration
vsp		=0 for surface synthetic
		=1 for vsp (vertical seismic profiling) synthetic
flt		=1 if earth flattening approximation required
win		=1 if frequency windowing required
nx		number of ranges (traces) in the synthetic seismogram
nt		number of samples per trace in the synthetics
nor		number of receivers
nf		number of frequencies in the synthetics
nlayers		pointer to number of reflecting layers
lsource		layer of top of which the source is located
layern
nfilters	number of filters to apply to the seismograms
filters_phase	=0 for zero phase filters. =1 for minimum phase filters
tlag		time lag to introduce in the seismograms
red_vel		reducing velocity, set to maximum compressional velocity if zero
w1		frequency to start lo-cut taper. =0.15*nw if zero 
w2		frequency to start hi-cut taper. =0.85*nw if zero 
dx		range increment in kms
bx		beginning range in kms
fs		sampling parameter, usually between 0.07 and 0.12.
		sampling is finer as fs increases
decay		decay factor, used to avoid time series wraparoundp
p2w		maximum ray parameter to which the synthetics are
		computed
tsec		length of computed trace in seconds
epsp
epss
sigp
sigs
lobs		array[nor] of layers on top of which the receivers are located
filters_type	array[nfilters] of requested filter types.
		=1 for lo-cut filter
		=2 for hi-cut filter
		=2 for notch filter
dbpo		array[nfilters] of filter slopes in db/octave
f1		array[nfilters] of frequency to start filtering action
f2		array[nfilters] of frequency to end filtering action
cl		array[nlayers] of compressional wave velocities
ql		array[nlayers] of compressional wave Q-values
ct		array[nlayers] of shear wave velocities
qt		array[nlayers] of shear wave Q-values
rho		array[nlayers] of densities
t		array[nlayers] of layer thicknesses

Output:
wavefield1	array[nx][nt] of pressure reflecivities if wtype=1 (PSV)
		or tangential wavefield reflectivities if wtype=2 (SH)
wavefield2	array[nx][nt] of radial wavefield component if wtype=1
		not used if wtype=2
wavefield3	array[nx][nt] of vertical wavefield component if wtype=1
		not used if wtype=2
*******************************************************************************
Notes:
This subroutine uses the reflectivity technique to compute the synthetic
seismic response for a stratified visco-elastic earth and may be used to
model the exploration seismic and earthquake data.  This is specially
suitable for modelling the Po/So as it is capable of handling the frequencies
and the distances involved in such computations.  
For small frequencies (w), 1/Q is proportional to w/eps
For large frequencies (w), 1/Q is proportional to w**(-sigma)
The reference frequency is one hertz
******************************************************************************/
{
	int il;				/* loop counters */
	float xmax;			/* maximum range */
	int *acoustic;			/* flags for receiver type */
	int *flag;			/* ??? */
	complex ***response1;		/* scratch array for pressure */
	complex ***response2;		/* scratch array for x-wavefield */
	complex ***response3;		/* scratch array for z-wavefield */

	/* initialize variables */
	fprintf (stderr,"original decay factor: %g nx=%d\n",decay,nx);
	fx=bx+dx*(nx-1);
	xmax=6*fx;
	if (decay<=0.0) decay=50.0;
	decay=log(decay)/tsec;

	/* allocate working space */
	acoustic=alloc1int(nor);
	flag=alloc1int(nor);
	response1=alloc3complex(nor,nx,nw);
	if (wtype==1) {
		response2=alloc3complex(nor,nx,nw);
		response3=alloc3complex(nor,nx,nw);
	}

	/* determine type of sources and receivers */
	source_receiver_type (nor, nlayers, lsource, lobs, cl, ct, acoustic, 
		flag);

	if (verbose==1||verbose==3) {
		fprintf(stderr,"Number of traces %d\n",nx);
		fprintf(stderr,"Offset of first trace %g\n",bx);
		fprintf(stderr,"Offset of last trace %g\n",fx);
		fprintf(stderr,"Trace to trace offset %g\n",dx);
		fprintf(stderr,"Number of samples in output traces %d\n",nt);
		fprintf(stderr,"Time sampling interval %g\n",tsec/nt);
		fprintf(stderr,"Trace length in seconds %g\n",tsec);
		fprintf(stderr,"Time lag applied to each trace (sec)%g\n",tlag);
		fprintf(stderr,"Total number of layers processed %d\n",nlayers);
		fprintf(stderr,"Total number of frequencies processed %d\n",nw);
		fprintf(stderr,"Decay factor applied=%g\n",decay);
		fprintf(stderr,"Number of frequencies in out traces %d\n",nf);
		fprintf(stderr,"First frequency in out traces %g\n",fref/tsec);
		fprintf(stderr,"Last frequency in output traces %g\n",nw/tsec);
		fprintf(stderr,"\nPROCESSING INFORMATION FOR EACH FREQUENCY\n");
		fprintf(stderr,"  iw   w	bp    fp    np    dp    "
			"pw1	pw2	pw3	pw4   \n");
	} if (verbose==2||verbose==3) {
		fprintf(outfp,"Number of traces %d\n",nx);
		fprintf(outfp,"Offset of first trace %g\n",bx);
		fprintf(outfp,"Offset of last trace %g\n",fx);
		fprintf(outfp,"Trace to trace offset %g\n",dx);
		fprintf(outfp,"Number of samples in output traces %d\n",nt);
		fprintf(outfp,"Time sampling interval %g\n",tsec/nt);
		fprintf(outfp,"Trace length in seconds %g\n",tsec);
		fprintf(outfp,"Time lag applied to each trace in sec%g\n",tlag);
		fprintf(outfp,"Total number of layers processed %d\n",nlayers);
		fprintf(outfp,"Total number of frequencies processed %d\n",nw);
		fprintf(outfp,"Decay factor applied=%g\n",decay);
		fprintf(outfp,"Number of frequencies in out traces %d\n",nf);
		fprintf(outfp,"First frequency in out traces %g\n",fref/tsec);
		fprintf(outfp,"Last frequency in output traces %g\n",nw/tsec);
		fprintf(outfp,"\nPROCESSING INFORMATION FOR EACH FREQUENCY\n");
		fprintf(outfp,"  iw   w	bp    fp   np    dp    "
			"pw1	pw2    pw3	pw4\n");
	}


	/* compute reflectivities */
	if (wtype==1) { 		/* PSV */
		psv_reflectivities (int_type, verbose, wtype, nw, nlayers, nx,
			layern, nor, np, bp, m1, m2, m3, h1, h2, lsource, bx,
			dx, xmax, decay, fref, wrefp, wrefs, tsec, p2w, fs,
			epsp, epss, sigp, sigs, pw1, pw2, pw3, pw4, acoustic,
			flag, lobs, rho, t, cl, ct, ql, qt, response1,
			response2, response3, outfp);

	} else if (wtype==2) {
		sh_reflectivities (int_type, verbose, wtype, nw, nlayers, nx,
			layern, nor, np, bp, m1, m2, m3, h1, h2, lsource, bx,
			dx, xmax, decay, fref, wrefp, wrefs, tsec, p2w, fs,
			epsp, epss, sigp, sigs, pw1, pw2, pw3, pw4, flag, lobs,
			rho, t, cl, ct, ql, qt, response1, outfp);
	}


	/* if requested, output processing information */
	if (verbose==1||verbose==3) {
		fprintf(stderr,"\nMODIFIED INPUT PARAMETERS\n");
		fprintf(stderr,"il   cl    ct	ql	qt	rho	t\n");
		for (il=0; il<nlayers; il++) {
			fprintf (stderr,"%3d%7.3f%7.3f%7.3f%7.3f%7.3f%7.3f\n",
				il,cl[il],ct[il],ql[il],qt[il],rho[il],t[il]);
		}
		fprintf(stderr,"\n");
	} if (verbose==2||verbose==3) {
		fprintf(outfp,"\nMODIFIED INPUT PARAMETERS\n");
		fprintf(outfp,"il    cl	ct	ql	qt	rho    t  \n");
		for (il=0; il<nlayers; il++) {
			fprintf (outfp,"%3d%7.3f%7.3f%7.3f%7.3f%7.3f%7.3f\n",
				il,cl[il],ct[il],ql[il],qt[il],rho[il],t[il]);
		}
		fprintf(outfp,"\n");
	}

	/* compute actual synthetic in t-x domain */
	if (wtype==1) {	

		/* pressure */
		compute_synthetics (verbose, nt, ntc, nx, nor, nw, nlayers, 
			lsource, nf, flt, vsp, win, wfield, tlag, red_vel, 
			decay, tsec, bx, dx, w1, w2, filters_phase, nfilters, 
			filters_type, dbpo, f1, f2, lobs, cl, t, response1, 
			wavefield1,outfp);

		/* radial component */
		compute_synthetics (verbose, nt, ntc, nx, nor, nw, nlayers, 
			lsource, nf, flt, vsp, win, wfield, tlag, red_vel, 
			decay, tsec, bx, dx, w1, w2, filters_phase, nfilters, 
			filters_type, dbpo, f1, f2, lobs, cl, t, response2, 
			wavefield2,outfp);

		/* vertical component */	
		compute_synthetics (verbose, nt, ntc, nx, nor, nw, nlayers, 
			lsource, nf, flt, vsp, win, wfield, tlag, red_vel, 
			decay, tsec, bx, dx, w1, w2, filters_phase, nfilters, 
			filters_type, dbpo, f1, f2, lobs, cl, t, response3, 
			wavefield3,outfp);

		/* free allocated space */
		free3complex(response1);
		free3complex(response2);
		free3complex(response3);

	} else if (wtype==2) {

		/* tangential component */
		compute_synthetics (verbose, nt, nx, ntc, nor, nw, nlayers, 
			lsource, nf, flt, vsp, win, wfield, tlag, red_vel, 
			decay, tsec, bx, dx, w1, w2, filters_phase, nfilters, 
			filters_type, dbpo, f1, f2, lobs, cl, t, response1, 
			wavefield1,outfp);

		/* free allocated space */
		free3complex(response1);
	} else err ("wtype flag has to be one ro two");

	/* free allocated space */
	free1int(acoustic);
	free1int(flag);
}

/******************************************************************************

	Subroutine to convolve reflectivity array with a wavelet to 
			produce a seismogram

******************************************************************************/
void convolve_wavelet (int wavelet_type, int nx, int nt, float dt, float fpeak, 
	float **wfield) 
/******************************************************************************
Input:
wavelet_type	=1 for a spike
		=2 for Tong Fei's Ricker wavelet
		=3 for Larner's Ricker wavelet
		=4 for Akima wavelet
nx		number of horizontal samples (traces)
nt		number of vertical samples (samples/trace)
dt		time sampling interval
fpeak		frequency peak for Ricker or Akima wavelets
wfield		array[nx][nt] of reflectivities

Output
wfield		array[nx][nt] of seismic traces 
******************************************************************************/
{
	int ix,it;			/* loop counters */
	float *wavelet;			/* wavelet array */	
	float *temp;			/* scratch array */

	/* allocate working space */
	wavelet=alloc1float(nt);
	temp=alloc1float(nt);

	/* compute wavelet */
	if (wavelet_type==1) {
		spike_wavelet (nt, 1, wavelet);
	} else if (wavelet_type==2) {
		ricker1_wavelet (nt, dt, fpeak, wavelet);
	} else if (wavelet_type==3) {
		ricker2_wavelet (nt/2, dt, 1./fpeak, 1., 0., wavelet);
	} else if (wavelet_type==4) {
		akb_wavelet (nt, dt, fpeak, wavelet);
	} else err ("wavelet_type has to be 1,2,3 or 4");
		
	/* loop over traces to convolve with wavelet */
	for (ix=0; ix<nx; ix++) {

		/* save input reflectivity trace */
		for (it=0; it<nt; it++) temp[it]=wfield[ix][it];
	
		/* convolve with wavelet */
		conv (nt, 0, temp, nt, 0, wavelet, nt, 0, wfield[ix]);
	}

	/* free allocated space */
	free1float(temp);
	free1float(wavelet);
}

#define BLK 100

/*****************************Self-Documentation******************************/
/******************************************************************************
AUX_REFLEXTIVITY		Set of subroutines to compute auxiliary stuff to be
						used by the reflectivity modeling code in producing
						synthetic seismograms
*******************************************************************************
Function prototypes:
void compute_w_aux_arrays (int wtype, int layern, int nlayers, int nor, 
	int lsource, int *np, int *block_size, int *nblock, int *left, float fw,
	float wrefp, float wrefs, int *lobs, float tsec, float p2w, float fs, 
	float xmax, float w, float decay, float epsp, float epss, float sigp, 
	float sigs, float *pw1, float *pw2, float *pw3, float *pw4, float *dp, 
	float *fp, complex wpie, complex *cdp, float *cl, float *ct, float*ql, 
	float *qt, float *rho, float *t, complex *al, complex *at, complex *prs);

void compute_p_aux_arrays (int wtype, int nlayers, int lsource, int block_size,
	float bp, float dp, float w, float decay, float pw1, float pw2,
	float pw3, float pw4, complex *pwin, float m1, float m2, float m3, float h1,
	float h2, complex wpie, complex *divfac, complex *p, complex *pp,
	complex *al, complex *at, float *rho, complex *gl, complex *gt,
	complex *gam, complex *alpha, complex *betha, complex *sigmad1,
	complex *sigmad2, complex *sigmau1, complex *sigmau2) ;

void source_receiver_type (int nor, int nlayers, int lsource, int  *lobs, 
	float *cl, float *ct, int *acoust, int *flag);

void compute_slowness (int wtype, int lsource, float w, float p2w, int *np, 
	float *fp, float fs, float e4, float dk, float decay, float xmax, float *dp,
	float *pw1, float *pw2, float *pw3, float *pw4, complex *cdp, float *cl, 
	float *ct, float *t);
		
void compute_al_at (int wtype, int nlayers, int layern, float eps, float epsp, 
	float epss, float sigma, float sigp, float sigs, float *wrefp, float *wrefs,
	float fw, float *cl, float *ct, float *ql, float *qt, float *rho, 
	complex wpie, complex *al, complex *at);

void compute_prs (int nor, int *lobs, complex *al, complex *at, float *rho,
	complex *prs);

void compute_block_size (int np, int *block_size, int *nblock, int *left);

void compute_pwin (int wtype, int block_size, float bp, float dp, float w, 
	float decay, float pw1, float pw2, float pw3, float pw4, complex *pwin, 
	complex *p, complex *pp);

void compute_gl_gt_gam (int wtype, int nlayers, int block_size, complex *al, 
	complex *at, float *rho, complex *pp, complex *gl, complex *gt, 
	complex *gam);

void compute_alpha_betha (int lsource, int block_size, complex ats, float rhos, 
	complex *gl, complex *gt, complex *alpha, complex *betha);

void compute_sigmas (int wtype, int block_size, int lsource, float m1, 
	float m2, complex meu, complex *alpha, complex *betha, complex *p, 
	complex *gl, complex *gt, complex *gam, complex a2, complex a3, 
	complex *pwin, complex s1, complex s2, complex s4, complex *sigmau1, 
	complex *sigmau2, complex *sigmad1, complex *sigmad2);

void compute_moment_tensor (int wtype, float phi, float lambda, float delta, 
	float phis, float m0, float *m1, float *m2, float *m3);

void parameter_interpolation (int nlayers, int *intlayers, int *nintlayers,
	float *intlayth, float *cl, float *ql, float *ct, float *qt, float *rho, 
	float *t) ;

void random_velocity_layers (int *nlayers, int *lsource, int nrand_layers,
	float sdcl, float sdct, float layer, float zlayer, float *cl, float *ql, 
	float *ct, float *qt, float *rho, float *t);

void apply_earth_flattening (int nlayers, float z0, float *cl, float *ct, 
	float *rho, float *t);
*******************************************************************************
Notes:

******************************************************************************/
/********************************End Self-Documentation***********************/


/******************************************************************************

				Subroutine to compute auxiliary arrays

******************************************************************************/
void compute_w_aux_arrays (int wtype, int layern, int nlayers, int nor, 
	int lsource, int *np, int *block_size, int *nblock, int *left, float fref,
	float wrefp, float wrefs, int *lobs, float tsec, float p2w, float fs, 
	float xmax, float w, float decay, float epsp, float epss, float sigp, 
	float sigs, float *pw1, float *pw2, float *pw3, float *pw4, float *dp, 
	float *fp, complex wpie, complex *cdp, float *cl, float *ct, float*ql, 
	float *qt, float *rho, float *t, complex *al, complex *at, complex *prs)
/******************************************************************************
Input:
layern			
nlayers		number of reflecting layers
tsec		time series length in seconds (the maximum frequency
			of the seismogram will be (nw/tsec) Hz
w			frequency in rad/sec
decay		decay factor, used to avoid time series wraparound
epsp
epss
sigp
sigs 
pw1			left lower side window ray paramter for tapering
pw2			right lower side window ray paramter for tapering
pw3			left upper side window ray paramter for tapering
pw4			right upper side window ray paramter for tapering
cl			array[nlayers] of compressional wave velocities km/s
ct			array[nlayers] of shear wave velocities km/s
ql			array[nlayers] of compressional Q-values
qt			array[nlayers] of shear Q-values
rho			array[nlayers] of densities g/cc
t			array[nlayers] of layer thicknesses km

Output:
******************************************************************************/
{
	float wref;			/* reference frequency in rads/sec */
	float eps,sigma,e4,dk;		/* auxiliary variables */

	/* initialize varaibles */ 
	eps=0.001;
	sigma=0.1;
	dk=0.8;
	e4=0.8;
	wref=2*PI*fref;

	/* compute al and at */
	compute_al_at (wtype, nlayers, layern, eps, epsp, epss, sigma, sigp, 
		sigs, &wrefp, &wrefs, fref, cl, ct, ql, qt, rho, wpie, al, at);

	/* compute prs for every receiver */
	compute_prs (nor, lobs, al, at, rho, prs);

	/* compute number of slowness, slowness increment and maximum slowness */
	compute_slowness (wtype, lsource, w, p2w, np, fp, fs, e4, dk, decay, 
		xmax, dp, pw1, pw2, pw3, pw4, cdp, cl, ct, t);

	/* compute number of blocks and block size for matrix computations */
	compute_block_size (*np, block_size, nblock, left);
}

/******************************************************************************

		Subroutine to compute auxiliary arrays

******************************************************************************/
void compute_p_aux_arrays (int wtype, int nlayers, int lsource, int block_size,
	float bp, float dp, float w, float decay, float pw1, float pw2,
	float pw3, float pw4, complex *pwin, float m1, float m2, float m3, float h1,
	float h2, complex wpie, complex *divfac, complex *p, complex *pp,
	complex *al, complex *at, float *rho, complex *gl, complex *gt,
	complex *gam, complex *alpha, complex *betha, complex *sigmad1,
	complex *sigmad2, complex *sigmau1, complex *sigmau2) 
/******************************************************************************
Input:







Output:


******************************************************************************/
{
	float rhos;
	complex als,ats;
	complex alphasq,bethasq;
	complex meu,lambda;
	complex s1,s2,s4,a1,a2,a3;
	
	/* save al, at and rho values for the source layer */
	als=al[lsource-1];
	ats=at[lsource-1];
	rhos=rho[lsource-1];

	/* compute complex auxiliary variables */
	alphasq=cdiv(cmplx(1.0,0.0),cmul(als,als));
	if ((ats.r==0.)&&(ats.i==0.)) bethasq=cmplx(0.0,0.0);
	else bethasq=cdiv(cmplx(1.0,0.0),cmul(ats,ats));
	meu=crmul(bethasq,rhos);
	if ((meu.r != 0.)||(meu.i !=0.)) a1=cdiv(cmplx(1.0,0.0),meu);
	else a1=cmplx(0.0,0.0);
	lambda=crmul(cmul(csub(alphasq,cmplx(2,0)),bethasq),rhos);
	*divfac=cmul(cmplx(0.0,1.0),wpie);
	s1=crmul(a1,m2);
	s2=crmul(crmul(cmul(als,als),1./rhos),m3);
	s4=cdiv(cmplx(h2,0.),*divfac);
	a2=cdiv(cmplx(h1,0.),*divfac);
	a3=csub(cmul(lambda,s2),cmplx(m1,0.));

	/* compute pwin */
	compute_pwin (wtype, block_size, bp, dp, w, decay, pw1, pw2, pw3, pw4, 
		pwin, p, pp);

	/* compute gl and gt and gam */
	compute_gl_gt_gam (wtype, nlayers, block_size, al, at, rho, pp, gl, gt, 
		gam);

	/* compute alpha and betha */
	compute_alpha_betha (lsource, block_size, ats, rhos, gl, gt, alpha, betha);

	/* compute sigmau1,sigmau2,sigmad1,sigmad2 */
	compute_sigmas (wtype, block_size, lsource, m1, m2, meu, alpha, betha, p, 
		gl, gt, gam, a2, a3, pwin, s1, s2, s4, sigmau1, sigmau2, sigmad1,
		sigmad2); 
}
	
/******************************************************************************

	Subroutine to determine the type (acoustic or elastic) of sources
				and receivers 

******************************************************************************/
void source_receiver_type (int nor, int nlayers, int lsource, int  *lobs, 
	float *cl, float *ct, int *acoustic, int *flag)
/******************************************************************************
Input:
nor	    	number of recievers
nlayers		number of reflecting layers
cl 	    	array[nlayers] of compressional velocities km/s
ct 	    	array[nlayers] of shear velocities km/s
acoust  	array[nor] of receiver-type flags
		=1 for receiver acoustic
		=2 for first receiver elastic below source
		=3 for receiver elastic below source
		=4 for non-physical conditions ??
flag    	array[nor] of flags ??
		=1 if the compressional and shear velocities in the
		receiver layer are the same as their corresponding
		values for the last layer

Output:
acoust   	array[nor] of updated flags according to reciver type
flag
******************************************************************************/
{
	int k=0,iz;			/* loop counters */
	int jkl,lmn;			/* auxiliary indices */

	/* loop over the receivers */
	for (iz=0; iz<nor; iz++) {
		jkl=lsource-1;
		lmn=lobs[iz]-1;
		acoustic[iz]=0;
		flag[iz]=0;

		/* test condition for flag */
		if ((cl[nlayers-1]==cl[lmn])&&(ct[nlayers-1]==ct[lmn]))
			flag[iz]=1;

		/* test condition for source and receiver type */
		if (ct[jkl]==0.0) {		/* source acoustic */

			if (ct[lmn]==0.0) {	/* receiver acoustic */
				acoustic[iz]=1;	
			} else {
				if (lmn>lsource-1) k++;

				if (k==1) { 	/* 1st elastic rec below sorce*/
					acoustic[iz]=2;	
				} else {    	/* elastic receiver below surface */
					acoustic[iz]=3;	
				}
			}

		} else {    			/* source elastic */

			if (ct[lmn]==0.0) { /* receiver acoustic */

				acoustic[iz]=1;

			}
		}
	}
	
	/* only for Po/So */
	if ((nor<=1)&&(lsource>lobs[0])&&(ct[0]==0.0)) acoustic[0]=4;
}

/******************************************************************************

		Subroutine to compute the number of slowness values, final 
				slownesses, slownes increment and np3

******************************************************************************/
void compute_slowness (int wtype, int lsource, float w, float p2w, int *np, 
	float *fp, float fs, float e4, float dk, float decay, float xmax, float *dp,
	float *pw1, float *pw2, float *pw3, float *pw4, complex *cdp, float *cl, 
	float *ct, float *t)
/*****************************************************************************
Input:
lsource 		layer on top of which the source is located 
w			frequency in rad/sec
p2w			maximum ray parameter value to which the synthetics
			are computed
fs			sampling parameter, usually between 0.07 and 0.12
e4
dk
decay   		decay factor to avoid time series wraparound
xmax    		maximum range
dp			pointer to ray parameter increment
np			pointer to number of ray parameters
pw1			pointer to left lower side window ray parameter
pw2			pointer to right lower side window ray parameter
pw3			pointer to left higher side window ray prameter		
pw4			pointer to right higher side window ray parameter
cdp			pointer to complex ray parameter increment
cl			array of compressional velocities
t			array of layer thicknesses

Output:
			calculated values for np,bp,fp,dp,pw1,pw2,pw3 and pw4
******************************************************************************/
{
	int numw;		/* number of frequencies */
	int index;
	float fq;		/* frequency in hertz */
	float fp1,fp2,dkt;   	/* auxiliary variables */
	float bp;		/* beginning and final ray parameters */

	/* initialize variables */
	fq=w/(PI*2.0);
	bp=0.0;
	if (wtype==1) index=lsource-1;
	else if (wtype==2) index=0;

	/* compute fp1 and fp2 */
	if (ct[index]<=0.0005) {
		fp1=sqrt(pow(1.0/cl[lsource-1],2)+pow(50.0/(w*(t[lsource-1]+
				0.00001)),2));
		fp2=sqrt(pow(1.0/cl[lsource-2],2)+pow(50.0/(w*(t[lsource-2]+
				0.00001)),2));
	} else {
		fp1=sqrt(pow(1.0/ct[lsource-1],2)+pow(50.0/(w*(t[lsource-1]+
				0.00001)),2));
		fp2=sqrt(pow(1.0/ct[lsource-2],2)+pow(50.0/(w*(t[lsource-2]+
				0.00001)),2));
	}

	/* compute the slowness parameters */
	*fp=MAX(fp1,fp2);
	dkt=dk*PI/xmax;
	*dp=(dkt/w)*pow((1.0+fq/fs),e4/2.);
	*dp=MIN(0.002,*dp);
	if ((p2w>0.0)&&(*fp>=p2w)) *fp=p2w;
	*np=*fp/ *dp;
	*fp=*np* *dp; 
	*cdp=cmplx(*dp,-(*dp)*(decay/w));

	/* if required, use default values for window slowness parameters */
	if ((*pw2<=0.) && (*pw3<=0.)) {
		numw=*np*0.15-1;
		*pw1=bp;
		*pw2=bp+*dp*numw;
		*pw3=*fp-*dp*numw;
		*pw4=*fp;
	}
}

/******************************************************************************

			Subroutine to compute the al and at arrays 

******************************************************************************/
void compute_al_at (int wtype, int nlayers, int layern, float eps, float epsp, 
	float epss, float sigma, float sigp, float sigs, float *wrefp, float *wrefs,
	float fw, float *cl, float *ct, float *ql, float *qt, float *rho, 
	complex wpie, complex *al, complex *at)
/******************************************************************************
Input:
nlayers 		number of reflecting layers
nlayern	
eps
epsp
spss
wpie    		complex frequency
sigma
sigp
sigs
cl			array of compressional wave velocities
ct			array of shear wave velocities
ql			array of compressional Q-values
qt			array of shear Q-values
rho			array of densities

Output:
al			array of ??
at			array of ??
******************************************************************************/
{
	int i;  					/* loop counter */
	float qwif,qwifs,qwifp;		/* auxilairy variables */
	float wref;    				/* reference frequency in rad/sec */	
	float wrefpp,wrefss;		/* reference p ands frequencies in rad/sec */	
	complex eiw,eiwp,eiws;		/* auxiliary variables */

	/* compute reference frequencies for p and s waves in rad/s */
	wrefpp=*wrefp;
	wrefss=*wrefs;
	wref=2.0*PI*fw;
	wrefpp *=2.0*PI;
	wrefss *=2.0*PI;

	/* compute the new p and s q values */
	qwif=(pow((eps*eps+wref*wref),sigma/2.)/(sin(sigma*PI/2.)*2.));
	qwifp=(pow((epsp*epsp+wrefpp*wrefpp),sigp/2.)/(sin(sigp*PI/2.)*2.));
	qwifs=(pow((epss*epss+wrefss*wrefss),sigs/2.)/(sin(sigs*PI/2.)*2.));

	/* compute wie */
	eiw=crpow(csub(cmplx(eps,0.0),cmul(cmplx(0.0,1.0),wpie)),sigma);

	/* check to see if layern was provided as an input */
	if (layern != 0) {
		eiwp=crpow(csub(cmplx(epsp,0.0),cmul(cmplx(0.0,1.0),wpie)),sigp);
		eiws=crpow(csub(cmplx(epss,0.0),cmul(cmplx(0.0,1.0),wpie)),sigs);

		/* compute al and at until just before layern */
		for (i=0; i<layern-1; i++) {
			al[i]=cmul(cmplx(1./cl[i],0.),cadd(cdiv(cmplx(qwif/ql[i],0.),
				eiw),cmplx(1.0,0.0)));
			if (ct[i]==0.0) {
				at[i]=cmplx(0.0,0.0);
			} else {
				at[i]=cmul(cmplx(1./ct[i],0.),cadd(cdiv(cmplx(qwif/qt[i],0.),
				eiw),cmplx(1.0,0.0)));
			}
		}

		/* compute al and at for the remaining layers */
		for (i=layern-1; i<nlayers; i++) {
			al[i]=cmul(cmplx(1./cl[i],0.),cadd(cdiv(cmplx(qwifp/ql[i],0.),
				eiwp),cmplx(1.0,0.0)));
			if (ct[i]==0.0) {
				at[i]=cmplx(0.0,0.0);
			} else {
				at[i]=cmul(cmplx(1./ct[i],0.),cadd(cdiv(cmplx(qwifs/qt[i],0.),
				eiws),cmplx(1.0,0.0)));
			}
		}

	} else {

		/* compute al and at for all layers */
		for (i=0; i<nlayers; i++) {
			al[i]=cmul(cmplx(1./cl[i],0.),cadd(cdiv(cmplx(qwif/ql[i],0.),
				eiw),cmplx(1.0,0.0)));
			if (ct[i]==0.0) {
				at[i]=cmplx(0.0,0.0);
			} else {
				at[i]=cmul(cmplx(1./ct[i],0.),cadd(cdiv(cmplx(qwif/qt[i],0.),
				eiw),cmplx(1.0,0.0)));
			}
		}
	}
	
	/* update pointers */
	*wrefp=wrefpp;
	*wrefs=wrefss;
}

/******************************************************************************

		Subroutine to compute the prs array

******************************************************************************/
void compute_prs (int nor, int *lobs, complex *al, complex *at, float *rho,
	complex *prs)
/******************************************************************************
Input:
nor			number of receivers
lobs		array[nor] layers on top of which the receivers are locate
al			arrar....
at			arrar....
rho			array of densities

Output
prs			array  ....
******************************************************************************/
{
	int ijk;
	int ijk1;
	complex ctemp;
	float rp;

	/* loop over the receivers */
	for (ijk=0; ijk<nor; ijk++) {
		ijk1=lobs[ijk]-1;
		rp=at[ijk1].r;
		if (rp==0.0) {
			prs[ijk]=crmul(cdiv(cmplx(1.0,0.0),cmul(al[ijk1],al[ijk1])),rho[ijk1]);
		} else {
			ctemp=cmul(cdiv(al[ijk1],at[ijk1]),cdiv(al[ijk1],
				at[ijk1]));
			prs[ijk]=crmul(csub(cmplx(1.0,0.0),crmul(ctemp,4./3.)),rho[ijk1]);
		}
	}
}

/******************************************************************************

	Subroutine to compute the number of blocks and block size for
			matrix computations 

******************************************************************************/
void compute_block_size (int np, int *block_size, int *nblock, int *left)
/******************************************************************************
Input:
np				Number of ray parameters
block_size		pointer to block size
nblock			pointer to number of blocks
left			pointer to remainder blocks

Output
				computed values for block_size, nblock and left
******************************************************************************/
{
	if (np<=BLK) {		 

		/* one block is enough and nothing is left */
		*block_size=np;
		*nblock=1;
		*left=0;

	} else {
		
		/* define block size and compute number of required blocks */
		*block_size=BLK;
		*left=np%BLK;
		*nblock=np/BLK+1;
	}
}

/******************************************************************************

		Subroutine to compute the pwin array 

******************************************************************************/
void compute_pwin (int wtype, int block_size, float bp, float dp, float w, 
	float decay, float pw1, float pw2, float pw3, float pw4, complex *pwin, 
	complex *p, complex *pp)
/******************************************************************************
Input:
block_size	block size for matrix computations
bp			begin ray parameter
dp			ray parameter increment
pw1			left lower window ray parameter for tapering
pw2			right lower window ray parameter for tapering
pw3			left upper window ray parameter for tapering
pw4			right upper window ray parameter for tapering

Output:
p			array[block_size] of complex ray parameters
pp			array[block_size] of complex squared ray parameters
pwin		array[block_size] of windowed complex ray parameters
******************************************************************************/
{
	int ip;						/* loop counter */
	float rp;					/* current ray parameter */
	float win,win1,win2;		/* auxiliary variables */

	/* loop over blocks */
	for (ip=0; ip<block_size; ip++) {

		/* compute array of complex slownesses */
		rp=bp+ip*dp;
		if (wtype==1) {
			p[ip]=cmplx(rp,0.0);
		} else if (wtype==2) {
			p[ip]=cmplx(rp, -decay*rp/w);
		}
		pp[ip]=cmul(p[ip],p[ip]);

		/* compute Hanning tapered window */
		if ((rp>=pw1)&&(rp<pw2)) {
			win1=0.5*(1.+cos(PI*((rp-pw1)/(pw2-pw1)-1.)));
			win=win1;
		}
		if ((rp>=pw2)&&(rp<=pw3)) win=1.0;
		if ((rp>pw3)&&(rp<pw4)) {
			win2=0.5*(1.+cos(PI*((rp-pw3)/(pw4-pw3))));
			win=win2;
		}
		if ((rp<pw1)||(rp>=pw4)) win=0.0;

		/* multiply complex ray parameter by window to compute pwin */
		pwin[ip]=crmul(csqrt(p[ip]),win);
	}
}

/******************************************************************************

	Subroutine to compute arrays gl, gt and gam

******************************************************************************/
void compute_gl_gt_gam (int wtype, int nlayers, int block_size, complex *al, 
	complex *at, float *rho, complex *pp, complex *gl, complex *gt, 
	complex *gam)
/******************************************************************************
Input:
nlayers 		number of reflecting layers
block_size	block size for matrix computations
al			array[nlayers] of ...
at			array[nlayers] of ...
rho			array[nlayers] of densities
pp			array[nlayers] of complex squared ray parameters

Output:
gl			array[block_size] of ...
gt			array[block_size] of ...
gam			array[block_size] of ...
*****************************************************************************/
{
	int il,ip,ijk;			/* loop counters */
	int ik1,ijk1;			/* auxiliary indices */
	float rho1;				/* current density */
	complex p1,p2;

	/* loop over layers */
	for (il=0; il<nlayers; il++) {
		p1=cmul(al[il],al[il]);
		p2=cmul(at[il],at[il]);
		rho1=rho[il];
		ik1=il*block_size;

		/* if p2 is not complex number zero */
		if ((p2.r !=0.0)||(p2.i !=0.0)) {
			for (ip=0; ip<block_size; ip++) {
				ijk1=ik1+ip;

				/* compute gl and gt */
				gl[ijk1]=csqrt(csub(p1,pp[ip]));
				gt[ijk1]=csqrt(csub(p2,pp[ip]));

				/* make imaginary parts of gl and gt positive */
				if (gl[ijk1].i<0.0) gl[ijk1].i *=-1.0;
				if (gt[ijk1].i<0.0) gt[ijk1].i *=-1.0;
				if (wtype==2) {
					/* make imaginary parts of gl and gt positive */
					if (gl[ijk1].i<0.0) gl[ijk1].r *=-1.0;
					if (gt[ijk1].i<0.0) gt[ijk1].r *=-1.0;
				}
	
				/* compute gam */
				gam[ijk1]=crmul(csub(cmplx(1.0,0.0),crmul(cdiv(pp[ip],p2),2.)),rho1);
			}

		} else {		/* p2 is complex number zero */

			for (ip=0; ip<block_size; ip++) {
				ijk1=ik1+ip;

				/* compute gl and set gt to zero */
				gl[ijk1]=csqrt(csub(p1,pp[ip]));
				gt[ijk1]=cmplx(0.0,0.0);

				/* if necessary, make imaginary part of gl positive */
				if (gl[ijk].i<0.0) gl[ijk1]=cneg(gl[ijk1]);
				gam[ijk1]=cmplx(rho1,0.0);
			}
		}
	}
}

/******************************************************************************

		Subroutine to compute alpha and betha

******************************************************************************/
void compute_alpha_betha (int lsource, int block_size, complex ats, float rhos, 
	complex *gl, complex *gt, complex *alpha, complex *betha)
/******************************************************************************
Input:
lsource		layer on top of which the source is located
block_size	block size for matrix computaions
ats			al[lsource-1]
rhos		rho[lsource-1] (density at the source layer)
gl			complex array[nlayers] of ...
gt			complex array[nlayers] of ...

Output
alpha		complex array[block_size] of ...
betha		complex array[block_size] of ...
******************************************************************************/
{
	int ip;				/* loop counter */
	int ik1,ijk1;		/* auxiliary indices */

	ik1=(lsource-1)*block_size;

	if ((ats.r==0.0)&&(ats.i=0.0)) {
		for (ip=0; ip<block_size; ip++) {
			ijk1=ik1+ip;
			alpha[ip]=cdiv(cmplx(1.0,0.0),crmul(crmul(gl[ijk1],rhos),2.0));
			betha[ip]=cmplx(0.0,0.0);
		}
	} else {
		for (ip=0; ip<block_size; ip++) {
			ijk1=ik1+ip;
			alpha[ip]=cdiv(cmplx(1.0,0.0),crmul(crmul(gl[ijk1],rhos),2.0));
			betha[ip]=cdiv(cmplx(1.0,0.0),crmul(crmul(gt[ijk1],rhos),2.0));
		}
	}
}	

/******************************************************************************

	Subroutine to compute arrays for sigmau1, sigmau2, sigmad1
						and sigmad2

******************************************************************************/
void compute_sigmas (int wtype, int block_size, int lsource, float m1, 
	float m2, complex meu, complex *alpha, complex *betha, complex *p, 
	complex *gl, complex *gt, complex *gam, complex a2, complex a3, 
	complex *pwin, complex s1, complex s2, complex s4, complex *sigmau1, 
	complex *sigmau2, complex *sigmad1, complex *sigmad2) 
/******************************************************************************
Input:
block_size	block size for matrix computations
meu
alpha
betha
p			array of complex ray parameters
gl
gt
gam
a2			
a3
pwin
s1
s2
s4
sigmau1		pointer to sigmau1
sigmau2		pointer to sigmau2
sigmad1		pointer to sigmad1
sigmad2		pointer to sigmad2

Output:
			Computed values for sigmau1, sigmau2, sigmad1, sigmad2
******************************************************************************/
{
	int ip;								/* loop counter */
	int ijk1,ik1;						/* auxiliary indices */
	complex d1,d2,d3,d4,d5,d6,d7,d8,s3;	/* auxiliary variables */	

	/* compute auxiliary index */
	ik1=(lsource-1)*block_size;

	/* loop over layers in a block */	
	for (ip=0; ip<block_size; ip++) {
		ijk1=ik1+ip;

		if (wtype==1) {
			/* compute auxiliary variables */
			d1=crmul(cmul(cmul(meu,gl[ijk1]),cmul(alpha[ip],p[ip])),2.0);
			d2=cneg(cmul(gam[ijk1],alpha[ip]));
			d3=cmul(p[ip],alpha[ip]);
			d4=cneg(cmul(gl[ijk1],alpha[ip]));
			d5=cmul(gam[ijk1],betha[ip]);
			d6=crmul(cmul(cmul(meu,gt[ijk1]),cmul(betha[ip],p[ip])),2.0);
			d7=cmul(gt[ijk1],betha[ip]);
			d8=cmul(p[ip],betha[ip]);
			s3=cadd(a2,cmul(p[ip],a3));

			/* compute sigmas */
			sigmau1[ip]=cneg(cmul(cadd(cadd(cmul(d1,s1),cmul(d2,s2)),
				cadd(cmul(d3,s3),cmul(d4,s4))),pwin[ip]));
			sigmau2[ip]=cneg(cmul(cadd(cadd(cmul(d5,s1),cmul(d6,s2)),
				cadd(cmul(d7,s3),cmul(d8,s4))),pwin[ip]));
			sigmad1[ip]=cmul(cadd(csub(cmul(d1,s1),cmul(d2,s2)),
				csub(cmul(d4,s4),cmul(d3,s3))),pwin[ip]);
			sigmad2[ip]=cmul(cadd(csub(cmul(d6,s2),cmul(d5,s1)),
				csub(cmul(d7,s3),cmul(d8,s4))),pwin[ip]);

		} else if (wtype==2) {
		
			/* avoid p and gt being zero */
			if ((p[ip].r==0.)&&(p[ip].i==0.)) p[ip]=cmplx(0.0001,0.0);
			if ((gt[ijk1].r==0.)&&(gt[ijk1].i==0.)) gt[ijk1]=cmplx(0.0001,0.0);

			/* compute sigmas */
			sigmau2[ip]=cmplx(0.0,0.0);
			sigmad2[ip]=cmplx(0.0,0.0);
			sigmau1[ip]=cneg(cmul(cadd(crmul(cinv(cmul(meu,p[ip])),m2/2.),
				crmul(cinv(cmul(meu,gt[ijk1])),m1/2.)),pwin[ip]));
			sigmad1[ip]=sigmau1[ip];
		}
	}
}

/******************************************************************************

			Subroutine to compute moment tensor components 

******************************************************************************/
void compute_moment_tensor (int wtype, float phi, float lambda, float delta, 
	float phis, float m0, float *m1, float *m2, float *m3)
/******************************************************************************
Input:
phi			azimuth of the receiver location (degrees)
lambda		rake (degrees)
delta		dip (degrees)
phis		azimuth of the fault plane (degrees)

Output
m1			[1][1] component of moment tensor
m2			[1][2] and [2][1] components of moment tensor
m3			[2][2] component of moment tensor
******************************************************************************/ 
{
	float a,b,c,d,e,f;			/* auxiliary variables */

	/* update fault plane azimuth */
	phis -=phi;

	/* convert angles to radians */
	delta *=PI/180.;
	lambda *=PI/180.;
	phis *=PI/180.;

	if (wtype==1) {
		/* compute auxiliary variables */
		a=sin(phis);
		b=a*a;
		c=sin(delta)*cos(lambda)*sin(2.*phis);
		d=sin(2.*delta)*sin(lambda);
		e=cos(delta)*cos(lambda)*cos(phis);
		f=cos(2.*delta)*sin(lambda)*a;

		/* compute the moment tensor components */
		*m1=-m0*(c+d*b);
		*m2=-m0*(e+f);
		*m3=m0*d;
	} else if (wtype==2) {
		*m1=m0*(sin(delta)*cos(lambda)*cos(2.*phis)+0.5*sin(2.*delta)*
			sin(lambda)*sin(2.*phis));
		*m2=-m0*(cos(delta)*cos(lambda)*sin(phis)-cos(2.*delta)*
			sin(lambda)*cos(phis));
		*m3=0.0;
	}
}

/******************************************************************************

		Subroutine to expand interpolated layers and update
				input parameters

******************************************************************************/
void parameter_interpolation (int nlayers, int *intlayers, int *nintlayers,
	float *intlayth, float *cl, float *ql, float *ct, float *qt, float *rho, 
	float *t) 
/******************************************************************************
Input:
nlayers		number of total reflecting layers
nlint		number of times layer interpolation is required
intlayers	array[nlint] of layers on top of which interpolation is required
nintlayers	array[nlint] of number of layers to interpolate each time
intlayth	array[nlint] of layer thicknesses to interpolate each time
cl			array[nlayers] of compressional velocities (Km/s)
ql			array[nlayers] of compressional q values
ct			array[nlayers] of shear velocities (Km/s)
qt			array[nlayers] of shear q values
rho			array[nlayers] of densities
t			array[nlayers] of absolute depths (Km)

Output:
			same arrays with interpolated layers
*******************************************************************************
Note:
******************************************************************************/
{
	int i=0,ii=0,j;			/* loop counters */
	int nintlay;			/* number of layer to interpolate */
	float tintlay;			/* thickness at which to interpolate */
	float incrcl;			/* interpolation step for cl */
	float incrql;			/* interpolation step for ql */
	float incrct;			/* interpolation step for ct */
	float incrqt;			/* interpolation step for qt */
	float incrrho;			/* interpolation step for rho */
	float crust=0.0;		/* auxiliary variable */

	while (i<nlayers) {
	
		if (intlayers[ii] == i) { /* interpolation requested for this layer */

			/* get number of layers to interpolate */
			nintlay=nintlayers[ii];
			tintlay=intlayth[ii];

			/* check if thickness is negative */
			if (tintlay<0.0) {
				tintlay=-tintlay-crust;
			}
			crust +=tintlay;

			/* if required, adjust input parameters */
			if (ct[i+nintlay]==-1.0) 
				ct[i+nintlay]=cl[i+nintlay]/sqrt(3.0);
			if (qt[i+nintlay]==-1.0) 
				qt[i+nintlay]=ql[i+nintlay]/2.;
			if (rho[i+nintlay-1]==-1.0) 
				rho[i+nintlay]=(cl[i+nintlay]+1.5)/3.;

			/* compute the interpolation steps */
			incrcl=(cl[i+nintlay]-cl[i-1])/(nintlay+1);
			incrql=(ql[i+nintlay]-ql[i-1])/(nintlay+1);
			incrct=(ct[i+nintlay]-ct[i-1])/(nintlay+1);
			incrqt=(qt[i+nintlay]-qt[i-1])/(nintlay+1);
			incrrho=(rho[i+nintlay]-rho[i-1])/(nintlay+1);

			/* do the actual interpolation */
			for (j=0; j<nintlay; j++) {
				cl[j+i-1]=cl[i-1]+(j+1)*incrcl;
				ql[j+i-1]=ql[i-1]+(j+1)*incrql;
				ct[j+i-1]=ct[i-1]+(j+1)*incrct;
				qt[j+i-1]=qt[i-1]+(j+1)*incrqt;
				rho[j+i-1]=rho[i-1]+(j+1)*incrrho;
				t[j+i-1]=tintlay/nintlay;
			}

			/* update counter by number of interopolated layers */
			i +=nintlay;
			ii++;

		} else {		/* no layer interpolation requested */

			/* if required, adjust input parameters */	
			if (ct[i]==-1.0) 
				ct[i]=cl[i]/sqrt(3.0);
			if (qt[i]==-1.0)
				qt[i]=ql[i]/2.;
			if (rho[i]==-1.0)
				rho[i]=(cl[i]+1.5)/3.;
			if (t[i]<0.0)
				t[i]=-t[i]-crust;
			if (i<nlayers-1)
				crust +=t[i];
			else 
				t[i]=10000.0;	/* make last layer a subspace */
			i++;
		}
	}
}

/******************************************************************************

					Compute random velocity layers

******************************************************************************/
void random_velocity_layers (int *nlayers, int *lsource, int nrand_layers,
	float sdcl, float sdct, float layer, float zlayer, float *cl, float *ql, 
	float *ct, float *qt, float *rho, float *t)
/******************************************************************************
Input:
nlayers		pointer to number of reflecting layers
lsource		pointer to layer on top of which the source is located
sdcl		compressional wave velocity standar deviation
sdct		shear wave velocity standar deviation
layer		layer number to star computing random velocity layers
zlayer		layer thickness above which to insert the random layers
cl			array[nlayers] of compressional wave velocities
ql			array[nlayers] of compressional wave Q-values
ct			array[nlayers] of shear wave velocities
qt			array[nlayers] of shear wave Q-values
rho			array[nlayers] of densities
t			array[nlayers] of layer thicknesses

Output:	
			same arrays with the random velocity layers information
			included and nlayers and lsource updated to reflect the
			insertion of the random velocity layers
*******************************************************************************
Note:
This subroutine computes a "layer" number of layers with random velocities
with means cl(compressional) and ct(shear) and standard deviations sdcl and 
sdct. The layers are inserted after the layer thickness zlayer and numbered
"layer" and onwards
******************************************************************************/
{
	int i=0,il,j=0;					/* loop counters */
	int icnt;						/* count number of layers to insert */
	int ijk;
	int ksource;					/* index to update source layer number*/
	int nl=*nlayers;				/* current number of layers */
	int nlmax;
	float d1,d2,tlast,x,zl;			/* auxiliary varibles */
	float cls,cts,qls,qts,rhos;		/* auxiliary variables */
	float *cll,*ctt,*qll;			/* scratch arrays */
	float *qtt,*rhoo,*tt;			/* more scratch arrays */

	fprintf (stderr, "before rand: nlayers=%d ",nl);

	/* allocate working space */
	cll=alloc1float(nl);
	ctt=alloc1float(nl);
	qll=alloc1float(nl);
	qtt=alloc1float(nl);
	rhoo=alloc1float(nl);
	tt=alloc1float(nl);
	
	/* initialize variables */
	d1=2.0*sqrt(3.0)*(sdcl/100.0);
	d2=2.0*sqrt(3.0)*(sdct/100.0);

	/* save information from last layer */
	cls=cl[nl-1];
	cts=ct[nl-1];
	qls=ql[nl-1];
	qts=qt[nl-1];
	rhos=rho[nl-1];
	nlmax=nrand_layers+nl-layer+1;

	/* main loop to compute the random layers */
	for (il=layer-1; il<nl-1; il++) {

		if (t[il]<=zlayer) {
			icnt=1;		/* compute just one layer */
			zl=t[il];	/* with thickness t[il] */
		} else {
			tlast=fmod(t[il],zlayer);
			icnt=t[il]/zlayer;				/* make icnt layers with */
			zl=zlayer+tlast/(float)icnt;	/* thickness t[il]/zlayer */
		}

		if (il==*lsource-1) ksource=j;
		for (ijk=0; ijk<icnt; ijk++) {
			tt[i]=zl;					/* all layers, same thickness */
			x=franuni()-0.5;
			cll[i]=cl[il]*(1.0+d1*x);	/* random velocities */
			ctt[i]=ct[il]*(1.0+d2*x);
			qll[i]=ql[il];				/* same q's and rho */
			qtt[i]=qt[il];
			rhoo[i]=rho[il];
			
			/* if maximum number of layers reached, exit inner loop */
			if (i==nlmax) break; 

			/* update counters */
			i++;
			if (il<*lsource-1) j++;
		}

		/* if maximum number of layers reached, exit outer loop */
		if (i==nlmax) break; 	
	}

	/* update number of layers and source layer index */ 
	nl=i+layer-1;
	*lsource +=ksource-1;

	/* restore information for last layer */
	cl[nl-1]=cls;
	ql[nl-1]=qls;
	ct[nl-1]=cts;
	qt[nl-1]=qts;
	rho[nl-1]=rhos;

	/* main loop to insert the computed information for the random layers */
	for (il=layer-1, i=0; il<nl-1; il++, i++) {
		cl[il]=cll[i];
		ct[il]=ctt[i];
		rho[il]=rhoo[i];
		ql[il]=qll[i];
		qt[il]=qtt[i];
		t[il]=tt[i];
		if (il==*lsource-1) {
			cl[il]=cl[il-1];
			ct[il]=ct[il-1];
			ql[il]=ql[il-1];
			qt[il]=qt[il-1];
			rho[il]=rho[il-1];
		}
	}
	t[nl-1]=10000.0;	/* make last layer a subspace */

	/* update pointer for number of layers */
	*nlayers=nl;
	fprintf (stderr, "after rand: nlayers=%d\n",nl);

	/* free allocated space */
	free1float(cll);
	free1float(ctt);
	free1float(qll);
	free1float(qtt);
	free1float(rhoo);
	free1float(tt);
}


/******************************************************************************

		Subroutine to apply flattening earth approximation

******************************************************************************/
void apply_earth_flattening (int nlayers, float z0, float *cl, float *ct, 
	float *rho, float *t)
/******************************************************************************
Input:
nlayer		number of reflecting layers
z0			first layer depth
cl			array[nlayers] of compressional wave velocities
ct			array[nlayers] of shear wave velocities
rho			array[nlayers] of densities
t			array[nlayers] of layer thicknesses

Output:	
			same arrays with the correction applied
			(the thicksnesses array, t, is not modified)
*******************************************************************************
Note:
This subroutine applies the earth flattening correction after Chapman, 1973
******************************************************************************/
{
	int il;				/* loop counter */
	float y0,w0;		/* auxiliary variables */
	float z=z0;			/* layer depth */
	float *zz;			/* scratch array */

	/* allocate working space */
	zz=alloc1float(nlayers);

	/* create and array of absolute depths from the thicknesses */
	zz[0]=z;
	for (il=0; il<nlayers-1; il++) {
		zz[il+1]=z+t[il];
		z=zz[il+1];
	}

	/* apply the earth flattening correction */
	for (il=0; il<nlayers; il++) {

		/* compute the correction */
		y0=RSO/(RSO-zz[il]);
		zz[il]=RSO*log(y0);
		w0=RSO/(RSO-zz[il]);

		/* apply the correction */
		cl[il] *=w0;
		ct[il] *=w0;
		rho[il] /=w0;
	}

	/* update the thicknesses */
	for (il=1; il<nlayers; il++) t[il-1]=zz[il]-zz[il-1];

 	/* make last layer a half space*/
	t[nlayers-1]=10000.0;

	/* free allocated space */
	free1float(zz);
}

#define BLK 100
#define IMAX 300
#define SZERO 0.000000000001

/********************************Self-Documentation***************************/
/******************************************************************************
REFLECTIVITIES -	Subroutines to do matrix propagation as the hard core of 
						a reflectivity modeling code for PSV and SH wavefields
psv_reflectivities		applies matrix propagation to compute the PSV 
							reflectivity response of a horizontally stratified 
							earth model
*******************************************************************************
Function Prototypes:
void psv_reflectivities (int int_type, int verbose, int wtype, int nw,
	int nlayers, int nx, int layern, int nor, int np, float bp1, float m1,
	float m2, float m3, float h1, float h2, int lsource, float bx, float dx,
	float xmax, float decay, float fref, float wrefp, float wrefs, float tsec,
	float p2w, float fs, float epsp, float epss, float sigp, float sigs,
	float pw1, float pw2, float pw3, float pw4, int *acoustic, int *flag,
	int *lobs, float *rho, float *t, float *cl, float *ct, float *ql, float *qt,
	complex ***response1, complex ***response2, complex ***response3,
	FILE *outfp);
*******************************************************************************
psv_reflectivities
Input:
nw  			number of frequencies
nlayers 		number of reflecting layers
nx  			number of ranges
nor 			number of receivers
lsource 		layer on top of which the source is located
bx  			beginning range
fx  			final range
dx  			range increment
acoustic		array[nor] of flags for receiver type
flag			array[nor] of flags for source type
rho 			array[nlayers] of densities
t   			array[nlayers] of layer thicknesses

Output
response1   	array[nw][nx][nor] of computed pressure wavefield
response2   	array[nw][nx][nor] of computed radial wavefield
response3   	array[nw][nx][nor] of computed vertical wavefield
*******************************************************************************
Credits:


******************************************************************************/
/*****************************End Self-Documentation**************************/





/******************************************************************************

		Subroutine to compute the propagation matrices for a single
							frequency step

******************************************************************************/
void psv_reflectivities (int int_type, int verbose, int wtype, int nw,
	int nlayers, int nx, int layern, int nor, int np, float bp1, float m1,
	float m2, float m3, float h1, float h2, int lsource, float bx, float dx,
	float xmax, float decay, float fref, float wrefp, float wrefs, float tsec,
	float p2w, float fs, float epsp, float epss, float sigp, float sigs,
	float pw1, float pw2, float pw3, float pw4, int *acoustic, int *flag,
	int *lobs, float *rho, float *t, float *cl, float *ct, float *ql, float *qt,
	complex ***response1, complex ***response2, complex ***response3,
	FILE *outfp)
/******************************************************************************
Iunput:
nw  			number of frequencies
nlayers 		number of reflecting layers
nx  			number of ranges
nor 			number of receivers
lsource 		layer on top of which the source is located
bx  			beginning range
fx  			final range
dx  			range increment
acoustic		array[nor] of flags for receiver type
flag			array[nor] of flags for source type
rho 			array[nlayers] of densities
t   			array[nlayers] of layer thicknesses

Output
response1   	array[nw][nx][nor] of computed pressure wavefield
response2   	array[nw][nx][nor] of computed radial wavefield
response3   	array[nw][nx][nor] of computed vertical wavefield
******************************************************************************/
{
	int iw,iz,ip,ix;				/* loop counters */
	int ijk1=0,ik1,ik2,il,jl;		/* auxiliary indices */
	int ijk=0,ijk2,jj;				/* more auxiliary indices */
	int flg1,lrec;				
	float bp;						/* smallest ray parameter */
	float fp;						/* final ray parameter */
	float dp;						/* ray parameter increment */
	int nblock;						/* number of blocks to process */
	int block_size;					/* size of current block */
	int left;						/* remainder */
	int *prv,*ibl;					/* scratch arrays */
	float x1,w;
	float wbeg,wfin;				/* aux variables for output */
	complex cdp,wpie;				/* complex cdp and frequency */

	/* complex auxiliary variables */
	complex divfac,g,h,e,f,mu,x,y,z,a,b,c,d,t1,tem,temr,sig,sigh,rho1,rho2;
	complex det,psq,gl1,gt1,gl2,gt2,gam1,gam2,at1,at2,al1,al2;
	complex rvrb111,rvrb112,rvrb121,rvrb122,rvrb211,rvrb212,rvrb221;
	complex ewigh11,ewigh22,rvrb222;
	complex wrn011,wrn012,wrn021,wrn022,ewrd11,ewrd12,ewrd21,ewrd22;
	complex ewd0211,ewd0212,ewd0221,ewd0222,ewtu211,ewtu212;
	complex ewtu221,ewtu222,rtb111,rtb112,rtb121,rtb122,rtb211;
	complex rtb212,rtb221,rtb222,rtb311,rtb312,rtb321,rtb322;
	complex func1,func2,func3,func4,func5,func6;
	complex tun0p11,tun0p12,tun0p21,tun0p22,rd0np11,rd0np12,rd0np21;
	complex rd0np22,td0np11,td0np12,td0np21,td0np22;
	complex rd11,rd12,rd21,rd22,td11,td12,td21,td22,tu11,tu12,tu21,tu22;
	complex ru11,ru12,ru21,ru22,ruf11,ruf12,ruf21,ruf22;
	complex fact11,fact12,vuzs1,vuzs2,vdzs1,vdzs2;

	/* complex scratch arrays */
	complex *rd0n11,*rd0n12,*rd0n21,*rd0n22,*td0n11,*td0n12;
	complex *td0n21,*td0n22,*tun011,*tun012,*tun021,*tun022;
	complex *run011,*run012,*run021,*run022,*tusf11,*tusf12;
	complex *tusf21,*tusf22,*rdfs11,*rdfs12,*rdfs21,*rdfs22;
	complex *tdfs11,*tdfs12,*tdfs21,*tdfs22,*rurf11,*rurf12;
	complex *rurf21,*rurf22,*turf11,*turf12,*turf21,*turf22;
	complex *rdfr11,*rdfr12,*rdfr21,*rdfr22,*tdfr11,*tdfr12;
	complex *tdfr21,*tdfr22,*rnr11,*rnr12,*rnr21,*rnr22;
	complex *rdsr11,*rdsr12,*rdsr21,*rdsr22;
	complex *r11,*r12,*r21,*r22;
	complex *texp,*vos1,*vos2,*vos3,*ux,*uz,*up;
	complex *alpha,*betha,*sigmad1,*sigmad2,*sigmau1,*sigmau2;
	complex *al,*at,*gl,*gt,*gam,*p,*pp,*prs,*pwin;

	/* complex pointers */	
	complex *rusf11,*rusf12,*rusf21,*rusf22;
	complex *tusr11,*tusr12,*tusr21,*tusr22;
	complex *rusr11,*rusr12,*rusr21,*rusr22;
	complex *tdsr11,*tdsr12,*tdsr21,*tdsr22;
	complex *rdnr11,*rdnr12,*rdnr21,*rdnr22;

	/* allocate working space */
	ux=alloc1complex(BLK);uz=alloc1complex(BLK);
	up=alloc1complex(BLK);rd0n11=alloc1complex(BLK);
	rd0n12=alloc1complex(BLK);rd0n21=alloc1complex(BLK);
	rd0n22=alloc1complex(BLK);td0n11=alloc1complex(BLK);
	td0n12=alloc1complex(BLK);td0n21=alloc1complex(BLK);
	td0n22=alloc1complex(BLK);tun011=alloc1complex(BLK);
	tun012=alloc1complex(BLK);tun021=alloc1complex(BLK);
	tun022=alloc1complex(BLK);run011=alloc1complex(BLK);
	run012=alloc1complex(BLK);run021=alloc1complex(BLK);
	run022=alloc1complex(BLK);tusf11=alloc1complex(BLK);
	tusf12=alloc1complex(BLK);tusf21=alloc1complex(BLK);
	tusf22=alloc1complex(BLK);rdfs11=alloc1complex(BLK);
	rdfs12=alloc1complex(BLK);rdfs21=alloc1complex(BLK);
	rdfs22=alloc1complex(BLK);tdfs11=alloc1complex(BLK);
	tdfs12=alloc1complex(BLK);tdfs21=alloc1complex(BLK);
	tdfs22=alloc1complex(BLK);rurf11=alloc1complex(IMAX);
	rurf12=alloc1complex(IMAX);rurf21=alloc1complex(IMAX);
	rurf22=alloc1complex(IMAX);turf11=alloc1complex(IMAX);
	turf12=alloc1complex(IMAX);turf21=alloc1complex(IMAX);
	turf22=alloc1complex(IMAX);rdfr11=alloc1complex(IMAX);
	rdfr12=alloc1complex(IMAX);rdfr21=alloc1complex(IMAX);
	rdfr22=alloc1complex(IMAX);tdfr11=alloc1complex(IMAX);
	tdfr12=alloc1complex(IMAX);tdfr21=alloc1complex(IMAX);
	tdfr22=alloc1complex(IMAX);rnr11=alloc1complex(BLK);
	rnr12=alloc1complex(BLK);rnr21=alloc1complex(BLK);
	rnr22=alloc1complex(BLK); rdsr11=alloc1complex(BLK);
	rdsr12=alloc1complex(BLK);rdsr21=alloc1complex(BLK);
	rdsr22=alloc1complex(BLK);vos1=alloc1complex(BLK);
	rusf21=alloc1complex(BLK);rusf22=alloc1complex(BLK);
	vos2=alloc1complex(BLK);vos3=alloc1complex(BLK);
	r11=alloc1complex(BLK);r12=alloc1complex(BLK);
	r21=alloc1complex(BLK);r22=alloc1complex(BLK);
	texp=alloc1complex(BLK);

	/* allocate other working space */
	prv=alloc1int(nor);
	prs=alloc1complex(nor);
	ibl=alloc1int(BLK);
	p=alloc1complex(BLK);
	pp=alloc1complex(BLK);
	pwin=alloc1complex(BLK);
	al=alloc1complex(nlayers);
	at=alloc1complex(nlayers);
	gl=alloc1complex(BLK*nlayers);
	gt=alloc1complex(BLK*nlayers);
	gam=alloc1complex(BLK*nlayers);
	alpha=alloc1complex(BLK);
	betha=alloc1complex(BLK);
	sigmau1=alloc1complex(BLK);
	sigmau2=alloc1complex(BLK);
	sigmad1=alloc1complex(BLK);
	sigmad2=alloc1complex(BLK);

	/* set pointers */
	rusf11=alpha;
	rusf12=betha;
	tusr11=tun011;
	tusr12=tun012;
	tusr21=tun021;
	tusr22=tun022;
	rusr11=run011;
	rusr12=run012;
	rusr21=run021;
	rusr22=run022;
	tdsr11=td0n11;
	tdsr12=td0n12;
	tdsr21=td0n21;
	tdsr22=td0n22;
	rdnr11=r11;
	rdnr12=r12;
	rdnr21=r21;
	rdnr22=r22;

	/* assign initial value to working variables */
    tem=cdiv(cmplx(1.0,0.0),cexp(crmul(cmplx(0.0,1.0),PI/4)));
    ewigh11=cmplx(0.0,0.0);
    ewigh22=cmplx(0.0,0.0);

	/* initialize complex output arrays */
	for (iw=0; iw<nw; iw++) 
		for (ix=0; ix<nx; ix++)
			for (iz=0; iz<nor; iz++) {
				response1[iw][ix][iz]=cmplx(0.0,0.0);
				response2[iw][ix][iz]=cmplx(0.0,0.0);
				response3[iw][ix][iz]=cmplx(0.0,0.0);
			}

	/**************************************************************************
	*						Main loop over frequencies			*	
	**************************************************************************/
	for (iw=0; iw<nw; iw++) {
		w=(iw+1)*PI*2/tsec;			/* w in radians/sec */
		if (iw==0) wbeg=w;
		if (iw==nw-1) wfin=w;
		wpie=cmplx(w,decay);		/* complex w */

		/* compute frequency-dependent auxiliary variables for reflectivity */
		compute_w_aux_arrays (wtype, layern, nlayers, nor, lsource, &np,
			&block_size, &nblock, &left, fref, wrefp, wrefs, lobs, tsec, p2w,
			fs, xmax, w, decay, epsp, epss, sigp, sigs, &pw1, &pw2, &pw3, &pw4,
			&dp, &fp, wpie, &cdp, cl, ct, ql, qt, rho, t, al, at, prs);

		/* if requested, output processing information */
		if (verbose==1||verbose==3) {
			fprintf(stderr,"%3d%6.1f%7.3f%7.3f%6d%7.3f%7.3f%7.3f"
			"%7.3f%7.3f\n",iw,w,bp,fp,np,dp,pw1,pw2,pw3,pw4);
		} 
		if (verbose==2||verbose==3) {
			fprintf(outfp,"%3d%6.1f%7.3f%7.3f%6d%7.3f%7.3f%7.3f"
			"%7.3f%7.3f\n",iw,w,bp,fp,np,dp,pw1,pw2,pw3,pw4);
		}


		/**********************************************************************
		* 		loop over slopes to compute the reflectivities (by blocks)    *
	    **********************************************************************/
		while (1) {

			if ((nblock==1) && (left !=0)) block_size=left;

			/* compute p_aux_arrays */
			compute_p_aux_arrays (wtype, nlayers, lsource, block_size, bp, dp,
				w, decay, pw1, pw2, pw3, pw4, pwin, m1, m2, m3, h1, h2,
				wpie, &divfac, p, pp, al, at, rho, gl, gt, gam, alpha, betha,
				sigmad1, sigmad2, sigmau1, sigmau2);


			/******************************************************************
			*			start computation of reflectivity series			  *
			******************************************************************/
			/* loop over reflecting layers */
			ijk=0;
			for (il=0; il<nlayers-1; il++) {
				jl=il+1;
				ik1=il*block_size;
				ik2=(il+1)*block_size;
				al1=al[il];
				al2=al[jl];
				at1=at[il];
				at2=at[jl];
				rho1=cmplx(rho[il],0.0);
				rho2=cmplx(rho[jl],0.0);
				t1=cmplx(t[il],0.0);
				if (il==0) {				/* initialize, first layer only */
					if ((at1.r==0.0)&&(at1.i==0.0)) {
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							gl1=gl[ijk1];
							ewigh11=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gl1,t1))));
							rd0n11[ip]=cmplx(0.0,0.0);
							rd0n12[ip]=cmplx(0.0,0.0);
							rd0n21[ip]=cmplx(0.0,0.0);
							rd0n22[ip]=cmplx(0.0,0.0);
							td0n11[ip]=ewigh11;
							td0n12[ip]=cmplx(0.0,0.0);
							td0n21[ip]=cmplx(0.0,0.0);
							td0n22[ip]=cmplx(0.0,0.0);
							tun011[ip]=ewigh11;
							tun012[ip]=cmplx(0.0,0.0);
							tun021[ip]=cmplx(0.0,0.0);
							tun022[ip]=cmplx(0.0,0.0);
							run011[ip]=cneg(cmul(ewigh11,ewigh11));
							run012[ip]=cmplx(0.0,0.0);
							run021[ip]=cmplx(0.0,0.0);
							run022[ip]=cmplx(0.0,0.0);
						}	
					} else {
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							psq=pp[ip];
							gl1=gl[ijk1];
							gt1=gt[ijk1];
							gam1=gam[ijk1];
							mu=cmul(cdiv(cmplx(1.0,0.0),cmul(at1,at1)),rho1);
							rtb211=crmul(cmul(p[ip],cmul(mu,gl1)),2.);
							rtb212=gam1;
							rtb221=cneg(gam1);
							rtb222=crmul(cmul(p[ip],cmul(mu,gt1)),2.);
							det=csub(cmul(rtb211,rtb222),cmul(rtb212,rtb221));
							rtb111=cdiv(rtb222,det);
							rtb112=cdiv(rtb212,det);
							rtb121=cneg(cdiv(rtb221,det));
							rtb122=cdiv(rtb211,det);
							ruf11=cadd(cmul(rtb211,rtb222),cmul(rtb212,rtb221));
							ruf12=cmul(rtb222,crmul(rtb212,2.));
							ruf21=cmul(rtb211,crmul(rtb221,2.));
							ruf22=ruf11;
							ruf11=cdiv(ruf11,det);
							ruf12=cdiv(ruf12,det);
							ruf21=cdiv(ruf21,det);
							ruf22=cdiv(ruf22,det);
							ewigh11=cexp(cmul(gl1,cmul(wpie,cmul(cmplx(0.0,1.0),t1))));
							ewigh22=cexp(cmul(gt1,cmul(wpie,cmul(cmplx(0.0,1.0),t1))));
							rd0n11[ip]=cmplx(0.0,0.0);
							rd0n12[ip]=cmplx(0.0,0.0);
							rd0n21[ip]=cmplx(0.0,0.0);
							rd0n22[ip]=cmplx(0.0,0.0);
							td0n11[ip]=ewigh11;
							td0n12[ip]=cmplx(0.0,0.0);
							td0n21[ip]=cmplx(0.0,0.0);
							td0n22[ip]=ewigh22;
							tun011[ip]=ewigh11;
							tun012[ip]=cmplx(0.0,0.0);
							tun021[ip]=cmplx(0.0,0.0);
							tun022[ip]=ewigh22;
							rtb111=cmul(ewigh11,ruf11);	
							rtb112=cmul(ewigh11,ruf12);	
							rtb121=cmul(ewigh22,ruf21);	
							rtb122=cmul(ewigh22,ruf22);	
							run011[ip]=cmul(ewigh11,rtb111);	
							run012[ip]=cmul(ewigh22,rtb112);	
							run021[ip]=cmul(ewigh11,rtb121);	
							run022[ip]=cmul(ewigh22,rtb122);	
						}
					}
				} else {				/* layers after the first one */

					/* case 1: liquid-liquid */
					if ((at1.r==0.)&&(at1.i==0.)&&(at2.r==0.)&&(at2.i==0.)) {
						if ((al1.r==al2.r)&&(al1.i==al2.i)) {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								gl1=gl[ijk1];
								ewigh11=cexp(cmul(wpie,cmul(cmplx(0.0,1.0),cmul(t1,gl1))));
								tun0p11=cmul(ewigh11,tun011[ip]);
								tun0p21=cmul(ewigh11,tun021[ip]);
								rtb111=cmul(ewigh11,run011[ip]);
								run011[ip]=cmul(ewigh11,rtb111);
								run012[ip]=cmplx(0.0,0.0);
								run021[ip]=cmplx(0.0,0.0);
								run022[ip]=cmplx(0.0,0.0);
								td0np11=cmul(ewigh11,td0n11[ip]);
								td0np12=cmul(ewigh11,td0n12[ip]);
								tun011[ip]=tun0p11;
								tun012[ip]=cmplx(0.0,0.0);
								tun021[ip]=tun0p21;
								tun022[ip]=cmplx(0.0,0.0);
								td0n11[ip]=td0np11;
								td0n12[ip]=td0np12;
								td0n21[ip]=cmplx(0.0,0.0);
								td0n22[ip]=cmplx(0.0,0.0);
							}
						} else {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								ijk2=ik2+ip;
								psq=pp[ip];
								gl1=gl[ijk1];
								gt1=gt[ijk1];
								gam1=gam[ijk1];
								gam2=gam[ijk2];
								gl2=gl[ijk2];
								gt2=gt[ijk2];
								ewigh11=cexp(cmul(wpie,cmul(cmplx(0.0,1.0),cmul(t1,gl1))));
								a=csub(gam2,gam1);
								b=cadd(rho1,a);
								c=csub(rho2,a);
								e=cadd(cmul(b,gl1),cmul(c,gl2));
								y=cadd(cmul(gl2,rho1),cmul(gl1,rho2));
								td11=cmul(cdiv(gl1,y),crmul(rho1,2.));
								rd11=cdiv(csub(cmul(gl1,rho2),
									cmul(gl2,rho1)),y);
								tu11=cmul(cdiv(gl2,y),crmul(rho2,2.));
								ru11=cneg(rd11);
								ewrd11=cmul(ewigh11,rd11);
								wrn011=cmul(ewigh11,run011[ip]);
								rvrb111=cdiv(cmplx(1.0,0.0),csub(cmplx(1.0,0.0),cmul(wrn011,ewrd11)));
								rvrb211=cadd(cmplx(1.0,0.0),cmul(rvrb111,
									cmul(ewrd11,wrn011)));
								ewd0211=cmul(td0n11[ip],cmul(rvrb111,ewigh11));
								ewd0212=cmul(td0n12[ip],cmul(rvrb111,ewigh11));
								td0n11[ip]=cmul(td11,ewd0211);
								td0n12[ip]=cmul(td11,ewd0212);
								td0n21[ip]=cmplx(0.0,0.0);
								td0n22[ip]=cmplx(0.0,0.0);
								ewtu211=cmul(rvrb211,cmul(ewigh11,tu11));
								tun0p11=cmul(ewtu211,tun011[ip]);
								tun0p21=cmul(ewtu211,tun021[ip]);
								rtb111=cmul(ewrd11,ewd0211);
								rtb112=cmul(ewrd11,ewd0212);
								rd0np11=cadd(rd0n11[ip],cmul(tun011[ip],
									rtb111));
								rd0np12=cadd(rd0n12[ip],cmul(tun011[ip],
									rtb112));
								rd0np21=cadd(rd0n21[ip],cmul(tun021[ip],
									rtb111));
								rd0np22=cadd(rd0n22[ip],cmul(tun022[ip],
									rtb112));
								run011[ip]=cadd(ru11,cmul(ewtu211,
									cmul(wrn011,td11)));
								run012[ip]=cmplx(0.0,0.0);
								run021[ip]=cmplx(0.0,0.0);
								run022[ip]=cmplx(0.0,0.0);
								tun011[ip]=tun0p11;
								tun012[ip]=cmplx(0.0,0.0);
								tun021[ip]=tun0p21;
								tun022[ip]=cmplx(0.0,0.0);
								rd0n11[ip]=rd0np11;
								rd0n12[ip]=rd0np12;
								rd0n21[ip]=rd0np21;
								rd0n22[ip]=rd0np22;
							}
						}
					} else if (((at1.r==0.)&&(at1.i==0.))&&((at2.r!=0.)||
								(at2.i!=0.))) {

						/* case 2: liquid-solid */
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							ijk2=ik2+ip;
							psq=pp[ip];
							gl1=gl[ijk1];
							gt1=gt[ijk1];
							gam1=gam[ijk1];
							gl2=gl[ijk2];
							gt2=gt[ijk2];
							gam2=gam[ijk2];
							ewigh11=cexp(cmul(wpie,cmul(cmplx(0.0,1.0),cmul(t1,gl1))));
							ewigh22=cmplx(0.0,0.0);
							a=csub(gam2,gam1);
							b=cadd(rho1,a);
							c=csub(rho2,a);
							e=cadd(cmul(gl1,b),cmul(gl2,c));
							d=cdiv(crmul(rho2,2.),cmul(at2,at2));
							f=b;
							g=csub(a,cmul(d,cmul(gl1,gt2)));
							h=cneg(cmul(d,gl2));
							z=cdiv(cmplx(1.0,0.0),cadd(cmul(e,f),cmul(g,cmul(h,psq))));
							y=cmul(cmul(z,gl1),crmul(rho1,2.0));
							td11=cmul(y,f);
							td12=cmplx(0.0,0.0);
							td21=cneg(cmul(y,cmul(h,p[ip])));
							td22=cmplx(0.0,0.0);
							rd11=cmul(z,csub(cmul(f,csub(cmul(gl1,b),
								cmul(gl2,c))),
							cmul(cmul(psq,h),cadd(a,cmul(gl1,cmul(gt2,d))))));
							rd12=cmplx(0.0,0.0);
							rd21=cmplx(0.0,0.0);
							rd22=cmplx(0.0,0.0);
							y=cmul(z,crmul(rho2,2.0));
							tu11=cmul(y,cmul(f,gl2));
							tu12=cmul(p[ip],cmul(y,cmul(gt2,h)));
							tu21=cmplx(0.0,0.0);
							tu22=cmplx(0.0,0.0);
							y=crmul(cmul(p[ip],cmul(gl1,cmul(b,
								cmul(d,z)))),2.0);
							ru11=cmul(z,csub(cmul(f,csub(cmul(gl2,c),
								cmul(gl1,b))),cmul(cmul(gl2,d),cmul(g,psq))));
							ru12=cmul(gt2,y);
							ru21=cneg(cmul(gl2,y));
							ru22=cneg(cmul(z,cadd(cmul(b,e),cmul(cmul(psq,h),
								cadd(a,cmul(gl1,cmul(gt2,d)))))));
							ewrd11=cmul(ewigh11,rd11);
							ewrd12=cmul(ewigh11,rd12);
							ewrd21=cmul(ewigh22,rd21);
							ewrd22=cmul(ewigh22,rd22);
							wrn011=cmul(ewigh11,run011[ip]);
							wrn012=cmul(ewigh11,run012[ip]);
							wrn021=cmul(ewigh22,run021[ip]);
							wrn022=cmul(ewigh22,run022[ip]);
							rtb111=cadd(cmul(wrn011,ewrd11),
								cmul(wrn012,ewrd21));
							rtb112=cadd(cmul(wrn011,ewrd12),
								cmul(wrn012,ewrd22));
							rtb121=cadd(cmul(wrn021,ewrd11),
								cmul(wrn022,ewrd21));
							rtb122=cadd(cmul(wrn021,ewrd12),
								cmul(wrn022,ewrd22));
							x=csub(cmplx(1.0,0.0),rtb111);
							y=csub(cmplx(1.0,0.0),rtb122);
							det=csub(cmul(x,y),cmul(rtb112,rtb121));
							rvrb111=cdiv(y,det);
							rvrb112=cdiv(rtb112,det);
							rvrb121=cdiv(rtb121,det);
							rvrb122=cdiv(x,det);
							rtb111=cadd(cmul(rvrb111,wrn011),
								cmul(rvrb112,wrn021));
							rtb112=cadd(cmul(rvrb111,wrn012),
								cmul(rvrb112,wrn022));
							rtb121=cadd(cmul(rvrb121,wrn011),
								cmul(rvrb122,wrn021));
							rtb122=cadd(cmul(rvrb121,wrn012),
								cmul(rvrb122,wrn022));
							rtb211=cadd(cmul(ewrd11,rtb111),
								cmul(ewrd12,rtb121));
							rtb212=cadd(cmul(ewrd11,rtb112),
								cmul(ewrd12,rtb122));
							rtb221=cadd(cmul(ewrd21,rtb111),
								cmul(ewrd22,rtb121));
							rtb222=cadd(cmul(ewrd21,rtb112),
								cmul(ewrd22,rtb122));
							rvrb211=cadd(rtb211,cmplx(1.0,0.0));
							rvrb212=rtb212;
							rvrb221=rtb221;
							rvrb222=cadd(rtb222,cmplx(1.0,0.0));
							rtb111=cmul(ewigh11,td0n11[ip]);
							rtb112=cmul(ewigh11,td0n12[ip]);
							rtb121=cmul(ewigh22,td0n21[ip]);
							rtb122=cmul(ewigh22,td0n22[ip]);
							ewd0211=cadd(cmul(rtb111,rvrb111),
								cmul(rvrb112,rtb121));
							ewd0212=cadd(cmul(rtb112,rvrb111),
								cmul(rvrb112,rtb122));
							ewd0221=cadd(cmul(rtb111,rvrb121),
								cmul(rvrb122,rtb121));
							ewd0222=cadd(cmul(rtb112,rvrb121),
								cmul(rvrb122,rtb122));
							td0n11[ip]=cadd(cmul(td11,ewd0211),
								cmul(td12,ewd0221));
							td0n12[ip]=cadd(cmul(td11,ewd0212),
								cmul(td12,ewd0222));
							td0n21[ip]=cadd(cmul(td21,ewd0211),
								cmul(td22,ewd0221));
							td0n22[ip]=cadd(cmul(td21,ewd0212),
								cmul(td22,ewd0222));
							rtb111=cadd(ewigh11,tu11);
							rtb112=cadd(ewigh11,tu12);
							rtb121=cadd(ewigh22,tu21);
							rtb122=cadd(ewigh22,tu22);
							ewtu211=cadd(cmul(rvrb211,rtb111),
								cmul(rvrb212,rtb121));
							ewtu212=cadd(cmul(rvrb211,rtb112),
								cmul(rvrb212,rtb122));
							ewtu221=cadd(cmul(rvrb221,rtb111),
								cmul(rvrb222,rtb121));
							ewtu222=cadd(cmul(rvrb221,rtb112),
								cmul(rvrb222,rtb122));
							tun0p11=cadd(cmul(tun011[ip],ewtu211),
								cmul(tun012[ip],ewtu221));
							tun0p12=cadd(cmul(tun011[ip],ewtu212),
								cmul(tun012[ip],ewtu222));
							tun0p21=cadd(cmul(tun021[ip],ewtu211),
								cmul(tun022[ip],ewtu221));
							tun0p22=cadd(cmul(tun021[ip],ewtu212),
								cmul(tun022[ip],ewtu222));
							rtb111=cadd(cmul(ewrd11,ewd0211),
								cmul(ewrd12,ewd0221));
							rtb112=cadd(cmul(ewrd11,ewd0212),
								cmul(ewrd12,ewd0222));
							rtb121=cadd(cmul(ewrd21,ewd0211),
								cmul(ewrd22,ewd0221)); 
							rtb122=cadd(cmul(ewrd21,ewd0212),
								cmul(ewrd22,ewd0222));
							rtb211=cadd(cmul(rtb111,tun011[ip]),cmul(rtb121,
								tun012[ip]));
							rtb212=cadd(cmul(rtb112,tun011[ip]),cmul(rtb122,
								tun012[ip]));
							rtb221=cadd(cmul(rtb111,tun021[ip]),cmul(rtb121,
								tun022[ip]));
							rtb222=cadd(cmul(rtb112,tun021[ip]),cmul(rtb122,
								tun022[ip]));
							rd0np11=cadd(rtb211,rd0n11[ip]);
							rd0np12=cadd(rtb212,rd0n12[ip]);
							rd0np21=cadd(rtb221,rd0n21[ip]);
							rd0np22=cadd(rtb222,rd0n22[ip]);
							rtb111=cadd(cmul(wrn011,ewtu211),
								cmul(ewtu221,wrn012));
							rtb112=cadd(cmul(wrn011,ewtu212),
								cmul(ewtu222,wrn012));
							rtb121=cadd(cmul(wrn021,ewtu211),
								cmul(ewtu221,wrn022));
							rtb122=cadd(cmul(wrn021,ewtu212),
								cmul(ewtu222,wrn022));
							rtb211=cadd(cmul(td11,rtb111),cmul(td12,rtb121));
							rtb212=cadd(cmul(td11,rtb112),cmul(td12,rtb122));
							rtb221=cadd(cmul(td21,rtb111),cmul(td22,rtb121));
							rtb222=cadd(cmul(td21,rtb112),cmul(td22,rtb122));
							run011[ip]=cadd(ru11,rtb211);
							run012[ip]=cadd(ru12,rtb212);
							run021[ip]=cadd(ru21,rtb221);
							run022[ip]=cadd(ru22,rtb222);
							rd0n11[ip]=rd0np11;
							rd0n12[ip]=rd0np12;
							rd0n21[ip]=rd0np21;
							rd0n22[ip]=rd0np22;
							tun011[ip]=tun0p11;
							tun012[ip]=tun0p12;
							tun021[ip]=tun0p21;
							tun022[ip]=tun0p22;
						}
					} else if ((at1.r !=0.)&&(at1.i !=0.)&&(at2.r==0.)&&
						(at2.i==0.)) {

						/* case 3: solid-liquid */
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							ijk2=ik2+ip;
							psq=pp[ip];
							gl1=gl[ijk1];
							gt1=gt[ijk1];
							gam1=gam[ijk1];
							gl2=gl[ik2];
							gt2=gt[ik2];
							gam2=gam[ijk2];
							ewigh11=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gl1,t1))));
							ewigh22=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gt1,t1))));
							a=csub(gam2,gam1);
							b=cadd(rho1,a);
							c=csub(rho2,a);
							e=cadd(cmul(b,gl1),cmul(c,gl2));
							d=cdiv(crmul(rho1,-2.0),cmul(at1,at1));
							f=c;
							g=cneg(cmul(gl1,d));
							h=csub(a,cmul(gl2,cmul(d,gt1)));
							z=cdiv(cmplx(1.0,0.0),cadd(cmul(e,f),cmul(g,cmul(h,psq))));
							y=cmul(z,crmul(rho1,2));
							td11=cmul(y,cmul(gl1,f));
							td12=cmul(y,cmul(p[ip],cmul(gt1,g)));
							td21=cmplx(0.0,0.0);
							td22=cmplx(0.0,0.0);
							y=crmul(cmul(z,cmul(c,cmul(d,
								cmul(p[ip],gl2)))),2.0);
							rd11=cmul(z,csub(cmul(f,csub(cmul(gl1,b),
								cmul(gl2,c))),cmul(cmul(psq,h),cmul(gl1,d))));
							rd12=cmul(y,gt1);	
							rd21=cneg(cmul(gl1,y));
							rd22=cneg(cmul(z,cadd(cmul(c,e),cmul(cadd(a,
								cmul(gt1,cmul(gl2,d))),cmul(psq,g)))));
							y=cmul(cmul(z,gl2),crmul(rho2,2.));
							tu11=cmul(y,f);
							tu12=cmplx(0.0,0.0);
							tu21=cneg(cmul(y,cmul(p[ip],y)));
							tu22=cmplx(0.0,0.0);
							ru11=cmul(z,csub(cmul(f,csub(cmul(gl2,c),
								cmul(gl1,b))),cmul(cadd(a,cmul(gl2,
								cmul(d,gt1))),cmul(psq,g))));
							ru12=cmplx(0.0,0.0);
							ru21=cmplx(0.0,0.0);
							ru22=cmplx(0.0,0.0);
							ewrd11=cmul(ewigh11,rd11);
							ewrd12=cmul(ewigh11,rd12);
							ewrd21=cmul(ewigh22,rd21);
							ewrd22=cmul(ewigh22,rd22);
							wrn011=cmul(ewigh11,run011[ip]);
							wrn012=cmul(ewigh11,run012[ip]);
							wrn021=cmul(ewigh22,run021[ip]);
							wrn022=cmul(ewigh22,run022[ip]);
							rtb111=cadd(cmul(wrn011,ewrd11),
								cmul(ewrd21,wrn012));
							rtb112=cadd(cmul(wrn011,ewrd12),
								cmul(ewrd22,wrn012));
							rtb121=cadd(cmul(wrn021,ewrd11),
								cmul(ewrd21,wrn022));
							rtb122=cadd(cmul(wrn021,ewrd12),
								cmul(ewrd22,wrn022));
							x=csub(cmplx(1.0,0.0),rtb111);
							y=csub(cmplx(1.0,0.0),rtb122);
							det=csub(cmul(x,y),cmul(rtb112,rtb121));
							rvrb111=cdiv(y,det);
							rvrb112=cdiv(rtb112,det);
							rvrb121=cdiv(rtb121,det);
							rvrb122=cdiv(x,det);
							rtb111=cadd(cmul(rvrb111,wrn011),
								cmul(rvrb112,wrn021));
							rtb112=cadd(cmul(rvrb111,wrn012),
								cmul(rvrb112,wrn022));
							rtb121=cadd(cmul(rvrb121,wrn011),
								cmul(rvrb122,wrn021));
							rtb122=cadd(cmul(rvrb121,wrn012),
								cmul(rvrb122,wrn022));
							rtb211=cadd(cmul(ewrd11,rtb111),
								cmul(ewrd12,rtb121));
							rtb212=cadd(cmul(ewrd11,rtb112),
								cmul(ewrd12,rtb122));
							rtb221=cadd(cmul(ewrd21,rtb111),
								cmul(ewrd22,rtb121));
							rtb222=cadd(cmul(ewrd21,rtb112),
								cmul(ewrd22,rtb122));
							rvrb211=cadd(cmplx(1.0,0.0),rtb211);
							rvrb212=rtb212;
							rvrb221=rtb221;
							rvrb222=cadd(cmplx(1.0,0.0),rtb222);
							rtb111=cadd(ewigh11,td0n11[ip]);
							rtb112=cadd(ewigh11,td0n12[ip]);
							rtb121=cadd(ewigh22,td0n21[ip]);
							rtb122=cadd(ewigh22,td0n22[ip]);
							ewd0211=cadd(cmul(rvrb111,rtb111),
								cmul(rvrb112,rtb121));
							ewd0212=cadd(cmul(rvrb111,rtb112),
								cmul(rvrb112,rtb122));
							ewd0221=cadd(cmul(rvrb121,rtb111),
								cmul(rvrb122,rtb121));
							ewd0222=cadd(cmul(rvrb121,rtb112),
								cmul(rvrb122,rtb122));
							td0n11[ip]=cadd(cmul(ewd0211,td11),
								cmul(ewd0221,td12));
							td0n12[ip]=cadd(cmul(ewd0212,td11),
								cmul(ewd0222,td12));
							td0n21[ip]=cadd(cmul(ewd0211,td21),
								cmul(ewd0221,td22));
							td0n22[ip]=cadd(cmul(ewd0212,td21),
								cmul(ewd0222,td22));
							rtb111=cmul(ewigh11,tu11);
							rtb112=cmul(ewigh11,tu12);
							rtb121=cmul(ewigh22,tu21);
							rtb122=cmul(ewigh22,tu22);
							ewtu211=cadd(cmul(rvrb211,rtb111),
								cmul(rvrb212,rtb121));
							ewtu212=cadd(cmul(rvrb211,rtb112),
								cmul(rvrb212,rtb122));
							ewtu221=cadd(cmul(rvrb221,rtb111),
								cmul(rvrb222,rtb121));
							ewtu222=cadd(cmul(rvrb221,rtb112),
								cmul(rvrb222,rtb122));
							tun0p11=cadd(cmul(tun011[ip],ewtu211),
								cmul(tun012[ip],ewtu221));
							tun0p12=cadd(cmul(tun011[ip],ewtu212),
								cmul(tun012[ip],ewtu222));
							tun0p21=cadd(cmul(tun021[ip],ewtu211),
								cmul(tun022[ip],ewtu221));
							tun0p22=cadd(cmul(tun021[ip],ewtu212),
								cmul(tun022[ip],ewtu222));
							rtb111=cadd(cmul(ewrd11,ewd0211),
								cmul(ewd0221,ewrd12));
							rtb112=cadd(cmul(ewrd11,ewd0212),
								cmul(ewd0222,ewrd12));
							rtb121=cadd(cmul(ewrd21,ewd0211),
								cmul(ewd0221,ewrd22));
							rtb122=cadd(cmul(ewrd21,ewd0212),
								cmul(ewd0222,ewrd22));
							rtb211=cadd(cmul(rtb111,tun011[ip]),cmul(rtb121,
								tun012[ip]));
							rtb212=cadd(cmul(rtb112,tun011[ip]),cmul(rtb122,
								tun012[ip]));
							rtb221=cadd(cmul(rtb111,tun021[ip]),cmul(rtb121,
								tun022[ip]));
							rtb222=cadd(cmul(rtb112,tun021[ip]),cmul(rtb122,
								tun022[ip]));
							rd0np11=cadd(rd0n11[ip],rtb211);
							rd0np12=cadd(rd0n12[ip],rtb212);
							rd0np21=cadd(rd0n21[ip],rtb221);
							rd0np22=cadd(rd0n22[ip],rtb222);
							rtb111=cadd(cmul(wrn011,ewtu211),
								cmul(wrn012,ewtu221));
							rtb112=cadd(cmul(wrn011,ewtu212),
								cmul(wrn012,ewtu222));
							rtb121=cadd(cmul(wrn021,ewtu211),
								cmul(wrn022,ewtu221));
							rtb122=cadd(cmul(wrn021,ewtu212),
								cmul(wrn022,ewtu222));
							rtb211=cadd(cmul(td11,rtb111),cmul(td12,rtb121));
							rtb212=cadd(cmul(td11,rtb112),cmul(td12,rtb122));
							rtb221=cadd(cmul(td21,rtb111),cmul(td22,rtb121));
							rtb222=cadd(cmul(td21,rtb112),cmul(td22,rtb122));
							run011[ip]=cadd(ru11,rtb211);
							run012[ip]=cadd(ru12,rtb212);
							run021[ip]=cadd(ru21,rtb221);
							run022[ip]=cadd(ru22,rtb222);
							rd0n11[ip]=rd0np11;
							rd0n12[ip]=rd0np12;
							rd0n21[ip]=rd0np21;
							rd0n22[ip]=rd0np22;
							tun011[ip]=tun0p11;
							tun012[ip]=tun0p12;
							tun021[ip]=tun0p21;
							tun022[ip]=tun0p22;
						}
					} else if (((at1.r!=0.)||(at1.i!=0.))&&((at2.r!=0.)||
						(at2.i!=0.))){
			
						/* case 4: solid-solid */
						if ((al1.r==al2.r)&&(al1.i==al2.i)&&(at1.r==at2.r)
							&&(at1.i==at2.i)) {		
							for(ip=0;ip<block_size;ip++) {
								ijk1=ik1+ip;
								gl1=gl[ijk1];
								gt1=gt[ijk1];
								ewigh11=cexp(cmul(cmplx(0.0,1.0),cmul(t1,cmul(wpie,gl1))));
								ewigh22=cexp(cmul(cmplx(0.0,1.0),cmul(t1,cmul(wpie,gt1))));
								tun0p11=cmul(tun011[ip],ewigh11);
								tun0p12=cmul(tun012[ip],ewigh22);
								tun0p21=cmul(tun021[ip],ewigh11);
								tun0p22=cmul(tun022[ip],ewigh22);
								rtb111=cmul(ewigh11,run011[ip]);
								rtb112=cmul(ewigh11,run012[ip]);
								rtb121=cmul(ewigh22,run021[ip]);
								rtb122=cmul(ewigh22,run022[ip]);
								run011[ip]=cmul(ewigh11,rtb111);
								run012[ip]=cmul(ewigh22,rtb112);
								run021[ip]=cmul(ewigh11,rtb121);
								run022[ip]=cmul(ewigh22,rtb122);
								td0np11=cmul(ewigh11,td0n11[ip]);
								td0np12=cmul(ewigh11,td0n12[ip]);
								td0np21=cmul(ewigh22,td0n21[ip]);
								td0np22=cmul(ewigh22,td0n22[ip]);
								tun011[ip]=tun0p11;
								tun012[ip]=tun0p12;
								tun021[ip]=tun0p21;
								tun022[ip]=tun0p22;
								td0n11[ip]=td0np11;
								td0n12[ip]=td0np12;
								td0n21[ip]=td0np21;
								td0n22[ip]=td0np22;
							}	
						} else {
							d=crmul(csub(cdiv(rho2,cmul(at2,at2)),cdiv(rho1,
								cmul(at1,at1))),2.0);
							for (ip=0;ip<block_size;ip++) {
								ijk1=ik1+ip;
								ijk2=ik2+ip;
								psq=pp[ip];
								gl1=gl[ijk1];
								gt1=gt[ijk1];
								gam1=gam[ijk1];
								gl2=gl[ijk2];
								gt2=gt[ijk2];
								gam2=gam[ijk2];
								ewigh11=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gl1,t1))));
								ewigh22=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gt1,t1))));
								a=csub(gam2,gam1);
								b=cadd(rho1,a);
								c=csub(rho2,a);
								e=cadd(cmul(gl1,b),cmul(gl2,c));
								f=cadd(cmul(gt1,b),cmul(gt2,c));
								g=csub(a,cmul(gl1,cmul(gt2,d)));
								h=csub(a,cmul(gl2,cmul(gt1,d)));
								z=cdiv(cmplx(1.0,0.0),cadd(cmul(e,f),cmul(g,cmul(psq,h))));
								y=cmul(z,crmul(rho1,2.0));
								td11=cmul(y,cmul(gl1,f));
								td12=cmul(y,cmul(gt1,cmul(p[ip],g)));
								td21=cneg(cmul(y,cmul(gl1,cmul(p[ip],h))));
								td22=cmul(y,cmul(gt1,e));
								y=crmul(cmul(z,cmul(p[ip],cadd(cmul(a,b),
									cmul(gl2,cmul(gt2,cmul(c,d)))))),2.0);
								rd11=cmul(z,csub(cmul(f,csub(cmul(gl1,b),
									cmul(gl2,c))),cmul(cadd(a,cmul(gl1,
									cmul(gt2,d))),cmul(psq,h))));
								rd12=cmul(y,gt1);
								rd21=cneg(cmul(y,gl1));
								rd22=cmul(z,csub(cmul(e,csub(cmul(gt1,b),
									cmul(gt2,c))),cmul(cadd(a,cmul(gt1,
									cmul(gl2,d))),cmul(psq,g))));
								y=cmul(z,crmul(rho2,2.0));
								tu11=cmul(y,cmul(gl2,f));
								tu12=cmul(y,cmul(gt2,cmul(p[ip],h)));
								tu21=cneg(cmul(y,cmul(gl2,cmul(p[ip],g))));
								tu22=cmul(y,cmul(gt2,e));
								y=crmul(cmul(z,cmul(p[ip],cadd(cmul(a,c),
									cmul(gl1,cmul(gt1,cmul(b,d)))))),2.0);
								ru11=cmul(z,csub(cmul(f,csub(cmul(gl2,c),
									cmul(gl1,b))),cmul(cadd(a,cmul(gl2,
									cmul(gt1,d))),cmul(psq,g))));
								ru12=cmul(y,gt2);
								ru21=cneg(cmul(y,gl2));
								ru22=cmul(z,csub(cmul(e,csub(cmul(gt2,c),
									cmul(gt1,b))),cmul(cadd(a,cmul(gl1,
									cmul(gt2,d))),cmul(psq,h))));
								ewrd11=cmul(ewigh11,rd11);
								ewrd12=cmul(ewigh11,rd12);
								ewrd21=cmul(ewigh22,rd21);
								ewrd22=cmul(ewigh22,rd22);
								wrn011=cmul(ewigh11,run011[ip]);
								wrn012=cmul(ewigh11,run012[ip]);
								wrn021=cmul(ewigh22,run021[ip]);
								wrn022=cmul(ewigh22,run022[ip]);
								rtb111=cadd(cmul(wrn011,ewrd11),
									cmul(wrn012,ewrd21));
								rtb112=cadd(cmul(wrn011,ewrd12),
									cmul(wrn012,ewrd22));
								rtb121=cadd(cmul(wrn021,ewrd11),
									cmul(wrn022,ewrd21));
								rtb122=cadd(cmul(wrn021,ewrd12),
									cmul(wrn022,ewrd22));
								x=csub(cmplx(1.0,0.0),rtb111);
								y=csub(cmplx(1.0,0.0),rtb122);
								det=csub(cmul(x,y),cmul(rtb112,rtb121));
								rvrb111=cdiv(y,det);
								rvrb112=cdiv(rtb112,det);
								rvrb121=cdiv(rtb121,det);
								rvrb122=cdiv(x,det);
								rtb111=cadd(cmul(wrn011,rvrb111),
									cmul(rvrb112,wrn021));
								rtb112=cadd(cmul(wrn012,rvrb111),
									cmul(rvrb112,wrn022));
								rtb121=cadd(cmul(wrn011,rvrb121),
									cmul(rvrb122,wrn021));
								rtb122=cadd(cmul(wrn012,rvrb121),
									cmul(rvrb122,wrn022));
								rtb211=cadd(cmul(ewrd11,rtb111),
									cmul(ewrd12,rtb121));
								rtb212=cadd(cmul(ewrd11,rtb112),
									cmul(ewrd12,rtb122));
								rtb221=cadd(cmul(ewrd21,rtb111),
									cmul(ewrd22,rtb121));
								rtb222=cadd(cmul(ewrd21,rtb112),
									cmul(ewrd22,rtb122));
								rvrb211=cadd(cmplx(1.0,0.0),rtb211);
								rvrb212=rtb212;
								rvrb221=rtb221;
								rvrb222=cadd(cmplx(1.0,0.0),rtb222);
								rtb111=cmul(ewigh11,td0n11[ip]);
								rtb112=cmul(ewigh11,td0n12[ip]);
								rtb121=cmul(ewigh22,td0n21[ip]);
								rtb122=cmul(ewigh22,td0n22[ip]);
								ewd0211=cadd(cmul(rvrb111,rtb111),
									cmul(rvrb112,rtb121));
								ewd0212=cadd(cmul(rvrb111,rtb112),
									cmul(rvrb112,rtb122));
								ewd0221=cadd(cmul(rvrb121,rtb111),
									cmul(rvrb122,rtb121));
								ewd0222=cadd(cmul(rvrb121,rtb112),
									cmul(rvrb122,rtb122));
								td0n11[ip]=cadd(cmul(td11,ewd0211),
									cmul(ewd0221,td12));
								td0n12[ip]=cadd(cmul(td11,ewd0212),
									cmul(ewd0222,td12));
								td0n21[ip]=cadd(cmul(td21,ewd0211),
									cmul(ewd0221,td22));
								td0n22[ip]=cadd(cmul(td21,ewd0212),
									cmul(ewd0222,td22));
								rtb111=cmul(ewigh11,tu11);
								rtb112=cmul(ewigh11,tu12);
								rtb121=cmul(ewigh22,tu21);
								rtb122=cmul(ewigh22,tu22);
								ewtu211=cadd(cmul(rvrb211,rtb111),
									cmul(rvrb212,rtb121));
								ewtu212=cadd(cmul(rvrb211,rtb112),
									cmul(rvrb212,rtb122));
								ewtu221=cadd(cmul(rvrb221,rtb111),
									cmul(rvrb222,rtb121));
								ewtu222=cadd(cmul(rvrb221,rtb112),
									cmul(rvrb222,rtb122));
								tun0p11=cadd(cmul(tun011[ip],ewtu211),
									cmul(tun012[ip],ewtu221));
								tun0p12=cadd(cmul(tun011[ip],ewtu212),	
									cmul(tun012[ip],ewtu222));
								tun0p21=cadd(cmul(tun021[ip],ewtu211),
									cmul(tun022[ip],ewtu221));
								tun0p22=cadd(cmul(tun021[ip],ewtu212),
									cmul(tun022[ip],ewtu222));
								rtb111=cadd(cmul(ewrd11,ewd0211),
									cmul(ewrd12,ewd0221));
								rtb112=cadd(cmul(ewrd11,ewd0212),
									cmul(ewrd12,ewd0222));
								rtb121=cadd(cmul(ewrd21,ewd0211),
									cmul(ewrd22,ewd0221));
								rtb122=cadd(cmul(ewrd21,ewd0212),
									cmul(ewrd22,ewd0222));
								rtb211=cadd(cmul(rtb111,tun011[ip]),cmul(rtb121,
									tun012[ip]));
								rtb212=cadd(cmul(rtb112,tun011[ip]),cmul(rtb122,
									tun012[ip]));
								rtb221=cadd(cmul(rtb111,tun021[ip]),cmul(rtb121,
									tun022[ip]));
								rtb222=cadd(cmul(rtb112,tun021[ip]),cmul(rtb122,
									tun022[ip]));
								rd0np11=cadd(rd0n11[ip],rtb211);
								rd0np12=cadd(rd0n12[ip],rtb212);
								rd0np21=cadd(rd0n21[ip],rtb221);
								rd0np22=cadd(rd0n22[ip],rtb222);
								rtb111=cadd(cmul(wrn011,ewtu211),
									cmul(ewtu221,wrn012));
								rtb112=cadd(cmul(wrn011,ewtu212),
									cmul(ewtu222,wrn012));
								rtb121=cadd(cmul(wrn021,ewtu211),
									cmul(ewtu221,wrn022));
								rtb122=cadd(cmul(wrn021,ewtu212),
									cmul(ewtu222,wrn022));
								rtb211=cadd(cmul(td11,rtb111),
									cmul(td12,rtb121));
								rtb212=cadd(cmul(td11,rtb112),
									cmul(td12,rtb122));
								rtb221=cadd(cmul(td21,rtb111),
									cmul(td22,rtb121));
								rtb222=cadd(cmul(td21,rtb112),
									cmul(td22,rtb122));
								run011[ip]=cadd(ru11,rtb211);
								run012[ip]=cadd(ru12,rtb212);
								run021[ip]=cadd(ru21,rtb221);
								run022[ip]=cadd(ru22,rtb222);
								rd0n11[ip]=rd0np11;
								rd0n12[ip]=rd0np12;
								rd0n21[ip]=rd0np21;
								rd0n22[ip]=rd0np22;
								tun011[ip]=tun0p11;
								tun012[ip]=tun0p12;
								tun021[ip]=tun0p21;
								tun022[ip]=tun0p22;
							}
						}
					}	
				}					/* closes "if" of layers after first one*/

				if (il==lobs[ijk]-2) {
					ik1=ijk*block_size;
					if (acoustic[ijk]==2.||acoustic[ijk]==4.) {
						for (ip=0; ip<block_size; ip++) {
							iz=ik1+ip;
							rurf11[iz]=run011[ip];
							rurf12[iz]=run012[ip];
							rurf21[iz]=run021[ip];
							rurf22[iz]=run022[ip];
							rdfr11[iz]=rd0n11[ip];
							rdfr12[iz]=rd0n12[ip];
							rdfr21[iz]=rd0n21[ip];
							rdfr22[iz]=rd0n22[ip];
							turf11[iz]=tun011[ip];
							turf12[iz]=tun012[ip];
							turf21[iz]=tun021[ip];
							turf22[iz]=tun022[ip];
							tdfr11[iz]=td0n11[ip];
							tdfr12[iz]=td0n12[ip];
							tdfr21[iz]=td0n21[ip];
							tdfr22[iz]=td0n22[ip];
							tun011[ip]=cmplx(1.0,0.0);
							tun012[ip]=cmplx(0.0,0.0);
							tun021[ip]=cmplx(0.0,0.0);
							tun022[ip]=cmplx(1.0,0.0);
							td0n11[ip]=cmplx(1.0,0.0);
							td0n12[ip]=cmplx(0.0,0.0);
							td0n21[ip]=cmplx(0.0,0.0);
							td0n22[ip]=cmplx(1.0,0.0);
							run011[ip]=cmplx(0.0,0.0);
							run012[ip]=cmplx(0.0,0.0);
							run021[ip]=cmplx(0.0,0.0);
							run022[ip]=cmplx(0.0,0.0);
							rd0n11[ip]=cmplx(0.0,0.0);
							rd0n12[ip]=cmplx(0.0,0.0);
							rd0n21[ip]=cmplx(0.0,0.0);
							rd0n22[ip]=cmplx(0.0,0.0);
						}
					} else {
						for (ip=0; ip<block_size; ip++) {
							iz=ik1+ip;
							rurf11[iz]=run011[ip];
							rurf12[iz]=run012[ip];
							rurf21[iz]=run021[ip];
							rurf22[iz]=run022[ip];
							rdfr11[ip]=rd0n11[ip];
							rdfr12[ip]=rd0n12[ip];
							rdfr21[ip]=rd0n21[ip];
							rdfr22[ip]=rd0n22[ip];
							turf11[iz]=tun011[ip];
							turf12[iz]=tun012[ip];
							turf21[iz]=tun021[ip];
							turf22[iz]=tun022[ip];
							tdfr11[iz]=td0n11[ip];
							tdfr12[iz]=td0n12[ip];
							tdfr21[iz]=td0n21[ip];
							tdfr22[iz]=td0n22[ip];
						}
					}
					ijk++;
				}
				if (il==lsource-2) {
					for (ip=0; ip<block_size; ip++) {
						rusf11[ip]=run011[ip];
						rusf12[ip]=run012[ip];
						rusf21[ip]=run021[ip];
						rusf22[ip]=run022[ip];
						rdfs11[ip]=rd0n11[ip];
						rdfs12[ip]=rd0n12[ip];
						rdfs21[ip]=rd0n21[ip];
						rdfs22[ip]=rd0n22[ip];
						run011[ip]=cmplx(0.0,0.0);
						run012[ip]=cmplx(0.0,0.0);
						run021[ip]=cmplx(0.0,0.0);
						run022[ip]=cmplx(0.0,0.0);
						rd0n11[ip]=cmplx(0.0,0.0);
						rd0n12[ip]=cmplx(0.0,0.0);
						rd0n21[ip]=cmplx(0.0,0.0);
						rd0n22[ip]=cmplx(0.0,0.0);
						tusf11[ip]=tun011[ip];
						tusf12[ip]=tun012[ip];
						tusf21[ip]=tun021[ip];
						tusf22[ip]=tun022[ip];
						tdfs11[ip]=td0n11[ip];
						tdfs12[ip]=td0n12[ip];
						tdfs21[ip]=td0n21[ip];
						tdfs22[ip]=td0n22[ip];
						tun011[ip]=cmplx(1.0,0.0);
						tun012[ip]=cmplx(0.0,0.0);
						tun021[ip]=cmplx(0.0,0.0);
						tun022[ip]=cmplx(1.0,0.0);
						td0n11[ip]=cmplx(1.0,0.0);
						td0n12[ip]=cmplx(0.0,0.0);
						td0n21[ip]=cmplx(0.0,0.0);
						td0n22[ip]=cmplx(1.0,0.0);
					}
				}
			}

			/* loop over receivers */
			flg1=0;
			for (iz=0; iz<nor; iz++) {
				ik1=iz*block_size;
				for (ip=0; ip<block_size; ip++) {
					ijk1=ik1+ip;	
					if (acoustic[iz]==1) {
						det=csub(rd0n11[ip],rdfr11[ijk1]);
					} else {
						det=csub(cmul(csub(rd0n11[ip],rdfr11[ijk1]),
							csub(rd0n22[ip],rdfr22[ijk1])),cmul(csub(rd0n12[ip],
							rdfr12[ijk1]),csub(rd0n21[ip],rdfr21[ijk1])));
					}	
					if (rcabs(det)<=SZERO) {
						prv[iz]=flag[iz];
						flag[iz]=2;
						ibl[iz]=ip;
						break;
					}
				}
				if (acoustic[iz]==2) {
					flg1=1;
					for (ip=0; ip<block_size; ip++) {
						ijk1=ik1+ip;
						rnr11[ip]=rd0n11[ip];
						rnr12[ip]=rd0n12[ip];
						rnr21[ip]=rd0n21[ip];
						rnr22[ip]=rd0n22[ip];
						tdsr11[ip]=tdfr11[ijk1];
						tdsr12[ip]=tdfr12[ijk1];
						tdsr21[ip]=tdfr21[ijk1];
						tdsr22[ip]=tdfr22[ijk1];
						tusr11[ip]=turf11[ijk1];
						tusr12[ip]=turf12[ijk1];
						tusr21[ip]=turf21[ijk1];
						tusr22[ip]=turf22[ijk1];
						rdsr11[ip]=rdfr11[ijk1];	
						rdsr12[ip]=rdfr12[ijk1];	
						rdsr21[ip]=rdfr21[ijk1];	
						rdsr22[ip]=rdfr22[ijk1];	
						rusr11[ip]=rurf11[ijk1];
						rusr12[ip]=rurf12[ijk1];
						rusr21[ip]=rurf21[ijk1];
						rusr22[ip]=rurf22[ijk1];
						rtb111=cadd(cmul(rurf11[ijk1],rnr11[ip]),
							cmul(rurf12[ijk1],rnr21[ip]));
						rtb112=cadd(cmul(rurf11[ijk1],rnr12[ip]),
							cmul(rurf12[ijk1],rnr22[ip]));
						rtb121=cadd(cmul(rurf21[ijk1],rnr11[ip]),
							cmul(rurf22[ijk1],rnr21[ip]));
						rtb122=cadd(cmul(rurf21[ijk1],rnr12[ip]),
							cmul(rurf22[ijk1],rnr22[ip]));
						x=csub(cmplx(1.0,0.0),rtb111);
						y=csub(cmplx(1.0,0.0),rtb122);
						det=csub(cmul(x,y),cmul(rtb112,rtb121));
						rvrb111=cdiv(y,det);
						rvrb112=cdiv(rtb112,det);
						rvrb121=cdiv(rtb121,det);
						rvrb122=cdiv(x,det);
						rtb111=cadd(cmul(rvrb111,tdfr11[ijk1]),cmul(rvrb112,
							tdfr21[ijk1]));
						rtb112=cadd(cmul(rvrb111,tdfr12[ijk1]),cmul(rvrb112,
							tdfr22[ijk1]));
						rtb121=cadd(cmul(rvrb121,tdfr11[ijk1]),cmul(rvrb122,
							tdfr21[ijk1]));
						rtb122=cadd(cmul(rvrb121,tdfr12[ijk1]),cmul(rvrb122,
							tdfr22[ijk1]));
						rtb211=cadd(cmul(rnr11[ip],rtb111),
							cmul(rnr12[ip],rtb121));	
						rtb212=cadd(cmul(rnr11[ip],rtb112),
							cmul(rnr12[ip],rtb122));	
						rtb221=cadd(cmul(rnr21[ip],rtb111),
							cmul(rnr22[ip],rtb121));	
						rtb222=cadd(cmul(rnr21[ip],rtb112),
							cmul(rnr22[ip],rtb122));	
						rd0n11[ip]=cadd(cmul(rtb211,turf11[ijk1]),
							cadd(cmul(rtb221,turf12[ijk1]),rdfr11[ijk1]));
						rd0n12[ip]=cadd(cmul(rtb212,turf11[ijk1]),
							cadd(cmul(rtb222,turf12[ijk1]),rdfr12[ijk1]));
						rd0n21[ip]=cadd(cmul(rtb211,turf21[ijk1]),
							cadd(cmul(rtb221,turf22[ijk1]),rdfr21[ijk1]));
						rd0n22[ip]=cadd(cmul(rtb212,turf21[ijk1]),
							cadd(cmul(rtb222,turf22[ijk1]),rdfr22[ijk1]));
					}
				}
			}

			/* loop over receivers */
			for (iz=0; iz<nor; iz++) {
				ik1=iz*block_size;
				lrec=lobs[iz];
				ik2=(lrec-1)*block_size;
			
				/* receiver above the source */
				if (lsource>lrec) {
					if (acoustic[iz]==4) {
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							ijk2=ik2+ip;
							rtb111=cadd(cmul(rdfs11[ip],rurf11[ijk1]),
								cmul(rdfs12[ip],rurf21[ijk1]));
							rtb112=cadd(cmul(rdfs11[ip],rurf12[ijk1]),
								cmul(rdfs12[ip],rurf22[ijk1]));
							rtb121=cadd(cmul(rdfs21[ip],rurf11[ijk1]),
								cmul(rdfs22[ip],rurf21[ijk1]));
							rtb122=cadd(cmul(rdfs21[ip],rurf12[ijk1]),
								cmul(rdfs22[ip],rurf22[ijk1]));
							x=csub(cmplx(1.0,0.0),rtb111);
							y=csub(cmplx(1.0,0.0),rtb122);
							det=csub(cmul(x,y),cmul(rtb112,rtb121));
							rvrb111=cdiv(y,det);
							rvrb112=cdiv(rtb112,det);
							rvrb121=cdiv(rtb121,det);
							rvrb122=cdiv(x,det);
							rtb111=cadd(cmul(rvrb111,tusf11[ip]),cmul(rvrb112,
								tusf21[ip]));
							rtb112=cadd(cmul(rvrb111,tusf12[ip]),cmul(rvrb112,
								tusf22[ip]));
							rtb121=cadd(cmul(rvrb121,tusf11[ip]),cmul(rvrb122,
								tusf21[ip]));
							rtb122=cadd(cmul(rvrb121,tusf12[ip]),cmul(rvrb122,
								tusf22[ip]));
							rtb211=cadd(cmul(rurf11[ijk1],rtb111),
								cmul(rurf12[ijk1],rtb121));
							rtb212=cadd(cmul(rurf11[ijk1],rtb112),
								cmul(rurf12[ijk1],rtb122));
							rtb221=cadd(cmul(rurf21[ijk1],rtb111),
								cmul(rurf22[ijk1],rtb121));
							rtb222=cadd(cmul(rurf21[ijk1],rtb112),
								cmul(rurf22[ijk1],rtb122));
							rtb311=cadd(cmul(tdfs11[ip],rtb211),cmul(tdfs12[ip],
								rtb221));
							rtb312=cadd(cmul(tdfs11[ip],rtb212),cmul(tdfs12[ip],
								rtb222));
							rtb321=cadd(cmul(tdfs21[ip],rtb211),cmul(tdfs22[ip],
								rtb221));
							rtb322=cadd(cmul(tdfs21[ip],rtb212),cmul(tdfs22[ip],
								rtb222));
							rusf11[ip]=cadd(rusf11[ip],rtb311);
							rusf12[ip]=cadd(rusf12[ip],rtb312);
							rusf21[ip]=cadd(rusf21[ip],rtb321);
							rusf22[ip]=cadd(rusf22[ip],rtb322);
							rtb311=cadd(cmul(rd0n11[ip],rusf11[ip]),
								cmul(rd0n12[ip],rusf21[ip]));
							rtb312=cadd(cmul(rd0n11[ip],rusf12[ip]),
								cmul(rd0n12[ip],rusf22[ip]));
							rtb321=cadd(cmul(rd0n21[ip],rusf11[ip]),
								cmul(rd0n22[ip],rusf21[ip]));
							rtb322=cadd(cmul(rd0n21[ip],rusf12[ip]),
								cmul(rd0n22[ip],rusf22[ip]));
							x=csub(cmplx(1.0,0.0),rtb311);
							y=csub(cmplx(1.0,0.0),rtb322);
							det=csub(cmul(x,y),cmul(rtb312,rtb321));
							rvrb111=cdiv(y,det);
							rvrb112=cdiv(rtb312,det);
							rvrb121=cdiv(rtb321,det);
							rvrb122=cdiv(x,det);
							fact11=cadd(cmul(sigmad1[ip],rd0n11[ip]),
								cadd(sigmau1[ip],cmul(rd0n12[ip],sigmad2[ip])));
							fact12=cadd(cmul(rd0n21[ip],sigmad1[ip]),
								cadd(sigmau2[ip],cmul(rd0n22[ip],sigmad2[ip])));
							vuzs1=cadd(cmul(rvrb111,fact11),
								cmul(rvrb112,fact12));
							vuzs2=cadd(cmul(rvrb121,fact11),
								cmul(rvrb122,fact12));
							up[ip]=cmul(prs[iz],cadd(cmul(vuzs1,cadd(rtb111,
								rtb211)),cmul(vuzs2,cadd(rtb112,rtb212))));
							rtb311=cadd(cmul(rurf11[ijk1],p[ip]),
								csub(cmul(p[ip],gt[ijk2]),rurf21[ijk1]));
							rtb312=cadd(cmul(rurf12[ijk1],p[ip]),
								csub(cmul(p[ip],gt[ijk2]),rurf22[ijk1]));
							rtb321=cadd(cmul(rurf11[ijk1],gl[ijk2]),
								csub(cmul(p[ip],rurf21[ijk1]),gl[ijk2]));
							rtb322=cadd(cmul(rurf12[ijk1],gl[ijk2]),
								cadd(cmul(p[ip],rurf22[ijk1]),p[ip]));
							rtb211=cadd(cmul(rtb311,rtb111),
								cmul(rtb312,rtb121));
							rtb212=cadd(cmul(rtb311,rtb112),
								cmul(rtb312,rtb122));
							rtb221=cadd(cmul(rtb321,rtb111),
								cmul(rtb322,rtb121));
							rtb222=cadd(cmul(rtb321,rtb112),
								cmul(rtb322,rtb122));
							ux[ip]=cadd(cmul(rtb211,vuzs1),cmul(rtb212,vuzs2));
							uz[ip]=cadd(cmul(rtb221,vuzs1),cmul(rtb222,vuzs2));
						}
					} else {
	
						/* source elastic,receiver elastic or*/
						/* source acoustic, receiver elastic */
						if (acoustic[iz]==0||acoustic[iz]==3) {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								det=csub(cmul(turf11[ijk1],turf22[ijk1]),
									cmul(turf21[ijk1],turf12[ijk1]));
								rtb211=cdiv(turf22[ijk1],det);
								rtb212=cneg(cdiv(turf12[ijk1],det));
								rtb221=cneg(cdiv(turf21[ijk1],det));
								rtb222=cdiv(turf11[ijk1],det);
								rdnr11[ip]=cadd(cmul(rtb211,tusf11[ip]),
									cmul(rtb212,tusf21[ip]));
								rdnr12[ip]=cadd(cmul(rtb211,tusf12[ip]),
									cmul(rtb212,tusf22[ip]));
								rdnr21[ip]=cadd(cmul(rtb221,tusf11[ip]),
									cmul(rtb222,tusf21[ip]));
								rdnr22[ip]=cadd(cmul(rtb221,tusf12[ip]),
									cmul(rtb222,tusf22[ip]));
							}
						} else {
			
							/* source elastic,receiver acoustic */
							/* or source and receiver acoustic */
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								rtb111=cdiv(cmplx(1.0,0.0),turf11[ijk1]);
								rdnr11[ip]=cmul(rtb111,tusf11[ip]);
								rdnr12[ip]=cmul(rtb111,tusf12[ip]);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
							}
						}
	
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							ijk2=ik2+ip;
							rtb111=rdnr11[ip];
							rtb112=rdnr12[ip];
							rtb121=rdnr21[ip];
							rtb122=rdnr22[ip];
							rtb211=cadd(cmul(rurf11[ijk1],rtb111),
								cmul(rurf12[ijk1],rtb121));
							rtb212=cadd(cmul(rurf11[ijk1],rtb112),
								cmul(rurf12[ijk1],rtb122));
							rtb221=cadd(cmul(rurf21[ijk1],rtb111),
								cmul(rurf22[ijk1],rtb121));
							rtb222=cadd(cmul(rurf21[ijk1],rtb112),
								cmul(rurf22[ijk1],rtb122));
							rtb311=cadd(cmul(rd0n11[ip],rusf11[ip]),
								cmul(rd0n12[ip],rusf21[ip]));
							rtb312=cadd(cmul(rd0n11[ip],rusf12[ip]),
								cmul(rd0n12[ip],rusf22[ip]));
							rtb321=cadd(cmul(rd0n21[ip],rusf11[ip]),
								cmul(rd0n22[ip],rusf21[ip]));
							rtb322=cadd(cmul(rd0n21[ip],rusf12[ip]),
								cmul(rd0n22[ip],rusf22[ip]));
							x=csub(cmplx(1.0,0.0),rtb311);
							y=csub(cmplx(1.0,0.0),rtb322);	
							det=csub(cmul(x,y),cmul(rtb312,rtb321));
							rvrb111=cdiv(y,det);
							rvrb112=cdiv(rtb312,det);
							rvrb121=cdiv(rtb321,det);
							rvrb122=cdiv(x,det);
							fact11=cadd(cmul(rd0n11[ip],sigmad1[ip]),
								cadd(cmul(rd0n12[ip],sigmad2[ip]),sigmau1[ip]));
							fact12=cadd(cmul(rd0n21[ip],sigmad1[ip]),
								cadd(cmul(rd0n22[ip],sigmad2[ip]),sigmau2[ip]));
							vuzs1=cadd(cmul(rvrb111,fact11),
								cmul(rvrb112,fact12));
							vuzs2=cadd(cmul(rvrb121,fact11),
								cmul(rvrb122,fact12));
							up[ip]=cmul(prs[iz],cadd(cmul(cadd(rtb111,rtb211),
								vuzs1),cmul(cadd(rtb112,rtb212),vuzs2)));
							rtb211=csub(cmul(rurf11[ijk1],p[ip]),cmul(gt[ijk2],
								rurf21[ijk1]));
							rtb212=csub(cmul(rurf12[ijk1],p[ip]),cmul(gt[ijk2],
								rurf22[ijk1]));
							rtb221=cadd(cmul(rurf11[ijk1],gl[ijk2]),
								cmul(rurf21[ijk1],p[ip]));
							rtb222=cadd(cmul(rurf12[ijk1],gl[ijk2]),
								cmul(rurf22[ijk1],p[ip]));
							rtb311=cadd(p[ip],rtb211);
							rtb312=cadd(gt[ijk2],rtb212);
							rtb321=csub(rtb221,gl[ijk2]);
							rtb322=cadd(p[ip],rtb222);
							rtb211=cadd(cmul(rtb311,rtb111),
								cmul(rtb312,rtb121));
							rtb212=cadd(cmul(rtb311,rtb112),
								cmul(rtb312,rtb122));
							rtb221=cadd(cmul(rtb321,rtb111),
								cmul(rtb322,rtb121));
							rtb222=cadd(cmul(rtb321,rtb112),
								cmul(rtb322,rtb122));
							ux[ip]=cadd(cmul(rtb211,vuzs1),cmul(rtb212,vuzs2));
							uz[ip]=cadd(cmul(rtb221,vuzs1),cmul(rtb222,vuzs2));
						}
					}
				} else {
		
					/* receiver below the source */
					if (flag[iz]==2) {
						if (acoustic[iz]==3) {
							for (ip=0; ip<ibl[iz]-1; ip++) {
								ijk1=ik1+ip;
								rtb111=csub(rnr11[ip],rdfr11[ijk1]);
								rtb112=csub(rnr12[ip],rdfr12[ijk1]);
								rtb121=csub(rnr21[ip],rdfr21[ijk1]);
								rtb122=csub(rnr22[ip],rdfr22[ijk1]);
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rtb211=cdiv(rtb122,det);
								rtb212=cneg(cdiv(rtb112,det));
								rtb221=cneg(cdiv(rtb121,det));
								rtb222=cdiv(rtb111,det);
								rtb311=cadd(cmul(turf11[ijk1],rtb211),
									cmul(rtb212,turf21[ijk1]));
								rtb312=cadd(cmul(turf12[ijk1],rtb211),
									cmul(rtb212,turf22[ijk1]));
								rtb321=cadd(cmul(turf11[ijk1],rtb221),
									cmul(rtb222,turf21[ijk1]));
								rtb322=cadd(cmul(turf12[ijk1],rtb221),
									cmul(rtb222,turf22[ijk1]));
								rtb111=cadd(cmul(tdfr11[ijk1],rtb311),cadd(
									cmul(rtb321,tdfr12[ijk1]),rurf11[ijk1])); 
								rtb112=cadd(cmul(tdfr11[ijk1],rtb312),cadd(
									cmul(rtb322,tdfr12[ijk1]),rurf12[ijk1]));
								rtb121=cadd(cmul(tdfr21[ijk1],rtb311),cadd(
									cmul(rtb321,tdfr22[ijk1]),rurf21[ijk1]));
								rtb122=cadd(cmul(tdfr21[ijk1],rtb312),cadd(
									cmul(rtb322,tdfr22[ijk1]),rurf22[ijk1]));
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rdnr11[ip]=cdiv(rtb122,det);
								rdnr12[ip]=cneg(cdiv(rtb112,det));
								rdnr21[ip]=cneg(cdiv(rtb121,det));
								rdnr22[ip]=cdiv(rtb111,det);
								rtb111=cadd(cmul(rusr11[ip],rdfr11[ijk1]),
									cmul(rusr12[ip],rdfr21[ijk1]));
								rtb112=cadd(cmul(rusr11[ip],rdfr12[ijk1]),
									cmul(rusr12[ip],rdfr22[ijk1]));
								rtb121=cadd(cmul(rusr21[ip],rdfr11[ijk1]),
									cmul(rusr22[ip],rdfr21[ijk1]));
								rtb122=cadd(cmul(rusr21[ip],rdfr12[ijk1]),
									cmul(rusr22[ip],rdfr22[ijk1]));
								x=csub(cmplx(1.0,0.0),rtb111);
								y=csub(cmplx(1.0,0.0),rtb122);
								det=csub(cmul(x,y),cmul(rtb112,rtb121));
								rvrb111=cdiv(y,det);
								rvrb112=cdiv(rtb112,det);
								rvrb121=cdiv(rtb121,det);
								rvrb122=cdiv(x,det);
								rtb211=cadd(cmul(tdfr11[ijk1],rvrb111),
									cmul(tdfr12[ijk1],rvrb121));
								rtb212=cadd(cmul(tdfr11[ijk1],rvrb112),
									cmul(tdfr12[ijk1],rvrb122));
								rtb221=cadd(cmul(tdfr21[ijk1],rvrb111),
									cmul(tdfr22[ijk1],rvrb121));
								rtb222=cadd(cmul(tdfr21[ijk1],rvrb112),
									cmul(tdfr22[ijk1],rvrb122));
								tdfr11[ijk1]=cadd(cmul(rtb211,tdsr11[ip]),
									cmul(rtb212,tdsr21[ip]));
								tdfr12[ijk1]=cadd(cmul(rtb211,tdsr12[ip]),
									cmul(rtb212,tdsr22[ip]));
								tdfr21[ijk1]=cadd(cmul(rtb221,tdsr11[ip]),
									cmul(rtb222,tdsr21[ip]));
								tdfr22[ijk1]=cadd(cmul(rtb221,tdsr12[ip]),
									cmul(rtb222,tdsr22[ip]));
								rtb111=cadd(cmul(rusr11[ip],rtb211),cmul(rtb212,
									rusr21[ip]));
								rtb112=cadd(cmul(rusr12[ip],rtb211),cmul(rtb212,
									rusr22[ip]));
								rtb121=cadd(cmul(rusr11[ip],rtb221),cmul(rtb222,
									rusr21[ip]));
								rtb122=cadd(cmul(rusr12[ip],rtb221),cmul(rtb222,
									rusr22[ip]));
								rurf11[ijk1]=cadd(cmul(rtb111,rurf11[ijk1]),
									cadd(cmul(rtb112,turf21[ijk1]),
									rurf11[ijk1]));
								rurf12[ijk1]=cadd(cmul(rtb111,rurf12[ijk1]),
									cadd(cmul(rtb112,turf22[ijk1]),
									rurf12[ijk1]));
								 rurf21[ijk1]=cadd(cmul(rtb121,rurf11[ijk1]),
									cadd(cmul(rtb122,turf21[ijk1]),
									rurf21[ijk1]));
								rurf22[ijk1]=cadd(cmul(rtb121,rurf12[ijk1]),
									cadd(cmul(rtb122,turf22[ijk1]),
									rurf22[ijk1]));
							}
							for (ip=ibl[iz]-1; ip<block_size; ip++) {
								ijk1=ik1+ip;
								rdnr11[ip]=cmplx(0.0,0.0);
								rdnr12[ip]=cmplx(0.0,0.0);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
								rtb111=cadd(cmul(rusr11[ip],rdfr11[ijk1]),
									cmul(rusr12[ip],rdfr21[ijk1]));
								rtb112=cadd(cmul(rusr11[ip],rdfr12[ijk1]),
									cmul(rusr12[ip],rdfr22[ijk1]));
								rtb121=cadd(cmul(rusr21[ip],rdfr11[ijk1]),
									cmul(rusr22[ip],rdfr21[ijk1]));
								rtb122=cadd(cmul(rusr21[ip],rdfr12[ijk1]),
									cmul(rusr22[ip],rdfr22[ijk1]));
								x=csub(cmplx(1.0,0.0),rtb111);
								y=csub(cmplx(1.0,0.0),rtb122);
								det=csub(cmul(x,y),cmul(rtb112,rtb121));
								rvrb111=cdiv(y,det);
								rvrb112=cdiv(rtb112,det);
								rvrb121=cdiv(rtb121,det);
								rvrb122=cdiv(x,det);
								rtb211=cadd(cmul(tdfr11[ijk1],rvrb111),
									cmul(rvrb121,tdfr12[ijk1]));
								rtb212=cadd(cmul(tdfr11[ijk1],rvrb112),
									cmul(rvrb122,tdfr12[ijk1]));
								rtb221=cadd(cmul(tdfr21[ijk1],rvrb111),
									cmul(rvrb121,tdfr22[ijk1]));
								rtb222=cadd(cmul(tdfr21[ijk1],rvrb112),
									cmul(rvrb122,tdfr22[ijk1]));
								tdfr11[ijk1]=cadd(cmul(rtb211,tdsr11[ip]),	
									cmul(rtb212,tdsr21[ip]));
								tdfr12[ijk1]=cadd(cmul(rtb211,tdsr12[ip]),
									cmul(rtb212,tdsr22[ip]));
								tdfr21[ijk1]=cadd(cmul(rtb221,tdsr11[ip]),
									cmul(rtb222,tdsr21[ip]));
								tdfr22[ijk1]=cadd(cmul(rtb221,tdsr12[ip]),
									cmul(rtb222,tdsr22[ip]));
								rtb111=cadd(cmul(rtb211,rusr11[ip]),
									cmul(rtb212,rusr21[ip]));
								rtb112=cadd(cmul(rtb211,rusr12[ip]),
									cmul(rtb212,rusr22[ip]));
								rtb121=cadd(cmul(rtb221,rusr11[ip]),
									cmul(rtb222,rusr21[ip]));
								rtb122=cadd(cmul(rtb221,rusr12[ip]),
									cmul(rtb222,rusr22[ip]));
								rurf11[ijk1]=cadd(cmul(rtb111,turf11[ijk1]),
									cadd(cmul(rtb112,turf21[ijk1]),
									rurf11[ijk1]));
								rurf12[ijk1]=cadd(cmul(rtb111,turf12[ijk1]),
									cadd(cmul(rtb112,turf22[ijk1]),
									rurf12[ijk1]));
								rurf21[ijk1]=cadd(cmul(rtb121,turf11[ijk1]),
									cadd(cmul(rtb122,turf21[ijk1]),
								rurf21[ijk1]));
								rurf22[ijk1]=cadd(cmul(rtb121,turf12[ijk1]),
									cadd(cmul(rtb122,turf22[ijk1]),
									rurf22[ijk1]));
							}
						} else if (acoustic[iz]==1) {
							for (ip=0; ip<ibl[iz]-1; ip++) {
								ijk1=ik1+ip;
								rtb211=cdiv(turf11[ijk1],csub(rd0n11[ip],
									rdfr11[ijk1]));
								rdnr11[ip]=cdiv(cmplx(1.0,0.0),cadd(cmul(tdfr11[ijk1],
									rtb211),rurf11[ijk1]));
								rdnr12[ip]=cmplx(0.0,0.0);   
								rdnr21[ip]=cmplx(0.0,0.0);   
								rdnr22[ip]=cmplx(0.0,0.0);   
							}
							for (ip=ibl[iz]-1; ip<block_size; ip++) {
								rdnr11[ip]=cmplx(0.0,0.0);
								rdnr12[ip]=cmplx(0.0,0.0);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
							}
						} else if (acoustic[iz]==2) {
							for (ip=0; ip<block_size; ip++) {
								rdnr11[ip]=rnr11[ip];
								rdnr12[ip]=rnr12[ip];
								rdnr21[ip]=rnr21[ip];
								rdnr22[ip]=rnr22[ip];
							}
						} else {
							for (ip=0; ip<ibl[iz]-1; ip++) {
								ijk1=ik1+ip;
								rtb111=csub(rd0n11[ip],rdfr11[ijk1]);
								rtb112=csub(rd0n12[ip],rdfr12[ijk1]);
								rtb121=csub(rd0n21[ip],rdfr21[ijk1]);
								rtb122=csub(rd0n22[ip],rdfr22[ijk1]);
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rtb211=cdiv(rtb122,det);
								rtb212=cneg(cdiv(rtb112,det));
								rtb221=cneg(cdiv(rtb121,det));
								rtb222=cdiv(rtb111,det);
								rtb311=cadd(cmul(rtb211,turf11[ijk1]),
									cmul(rtb212,turf21[ijk1]));
								rtb312=cadd(cmul(rtb211,turf12[ijk1]),
									cmul(rtb212,turf22[ijk1]));
								rtb321=cadd(cmul(rtb221,turf11[ijk1]),
									cmul(rtb222,turf21[ijk1]));
								rtb322=cadd(cmul(rtb221,turf12[ijk1]),
									cmul(rtb222,turf22[ijk1]));
								rtb111=cadd(cmul(rtb311,tdfr11[ijk1]),cadd(
									cmul(rtb321,tdfr12[ijk1]),rurf11[ijk1]));
								rtb112=cadd(cmul(rtb312,tdfr11[ijk1]),cadd(
									cmul(rtb322,tdfr12[ijk1]),rurf12[ijk1]));
								rtb121=cadd(cmul(rtb311,tdfr21[ijk1]),cadd(
									cmul(rtb321,tdfr22[ijk1]),rurf21[ijk1]));
								rtb122=cadd(cmul(rtb312,tdfr21[ijk1]),cadd(
									cmul(rtb322,tdfr22[ijk1]),rurf22[ijk1]));
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rdnr11[ip]=cdiv(rtb122,det);
								rdnr12[ip]=cneg(cdiv(rtb112,det));
								rdnr21[ip]=cneg(cdiv(rtb121,det));
								rdnr22[ip]=cdiv(rtb111,det);
							}
							for (ip=ibl[iz]-1; ip<block_size; ip++) {
								rdnr11[ip]=cmplx(0.0,0.0);
								rdnr12[ip]=cmplx(0.0,0.0);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
							}
						}
					} else if (flag[iz]==0) {
						/* source acoustic, 1st elastic rec */
						if (acoustic[iz]==2) {
							for (ip=0; ip<block_size; ip++) {
								rdnr11[ip]=rnr11[ip];
								rdnr12[ip]=rnr12[ip];
								rdnr21[ip]=rnr21[ip];
								rdnr22[ip]=rnr22[ip];
							}
						} else if (acoustic[iz]==3) {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								rtb111=csub(rnr11[ip],rdfr11[ijk1]);
								rtb112=csub(rnr12[ip],rdfr12[ijk1]);
								rtb121=csub(rnr21[ip],rdfr21[ijk1]);
								rtb122=csub(rnr22[ip],rdfr22[ijk1]);
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rtb211=cdiv(rtb122,det);
								rtb212=cneg(cdiv(rtb112,det));
								rtb221=cneg(cdiv(rtb121,det));
								rtb222=cdiv(rtb111,det);
								rtb311=cadd(cmul(turf11[ijk1],rtb211),
									cmul(rtb212,turf21[ijk1]));
								rtb312=cadd(cmul(turf12[ijk1],rtb211),
									cmul(rtb212,turf22[ijk1]));
								rtb321=cadd(cmul(turf11[ijk1],rtb221),
									cmul(rtb222,turf21[ijk1]));
								rtb322=cadd(cmul(turf12[ijk1],rtb221),
									cmul(rtb222,turf22[ijk1]));
								rtb111=cadd(cmul(tdfr11[ijk1],rtb311),cadd(
									cmul(rtb321,tdfr12[ijk1]),rurf11[ijk1]));
								rtb112=cadd(cmul(tdfr11[ijk1],rtb312),cadd(
									cmul(rtb322,tdfr12[ijk1]),rurf12[ijk1]));
								rtb121=cadd(cmul(tdfr21[ijk1],rtb311),cadd(
									cmul(rtb321,tdfr22[ijk1]),rurf21[ijk1]));
								rtb122=cadd(cmul(tdfr21[ijk1],rtb312),cadd(
									cmul(rtb322,tdfr22[ijk1]),rurf22[ijk1]));
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rdnr11[ip]=cdiv(rtb122,det);
								rdnr12[ip]=cneg(cdiv(rtb112,det));
								rdnr21[ip]=cneg(cdiv(rtb121,det));
								rdnr22[ip]=cdiv(rtb111,det);
								rtb111=cadd(cmul(rusr11[ip],rdfr11[ijk1]),
									cmul(rusr12[ip],rdfr21[ijk1]));
								rtb112=cadd(cmul(rusr11[ip],rdfr12[ijk1]),
									cmul(rusr12[ip],rdfr22[ijk1]));
								rtb121=cadd(cmul(rusr21[ip],rdfr11[ijk1]),
									cmul(rusr22[ip],rdfr21[ijk1]));
								rtb122=cadd(cmul(rusr21[ip],rdfr12[ijk1]),
									cmul(rusr22[ip],rdfr22[ijk1]));
								x=csub(cmplx(1.0,0.0),rtb111);
								y=csub(cmplx(1.0,0.0),rtb122);
								det=csub(cmul(x,y),cmul(rtb112,rtb121));
								rvrb111=cdiv(y,det);
								rvrb112=cdiv(rtb112,det);
								rvrb121=cdiv(rtb121,det);
								rvrb122=cdiv(x,det);
								rtb211=cadd(cmul(tdfr11[ijk1],rvrb111),
									cmul(rvrb121,tdfr12[ijk1]));
								rtb212=cadd(cmul(tdfr11[ijk1],rvrb112),
									cmul(rvrb122,tdfr12[ijk1]));
								rtb221=cadd(cmul(tdfr21[ijk1],rvrb111),
									cmul(rvrb121,tdfr22[ijk1]));
								rtb222=cadd(cmul(tdfr21[ijk1],rvrb112),
									cmul(rvrb122,tdfr22[ijk1]));
								tdfr11[ijk1]=cadd(cmul(rtb211,tdsr11[ip]),
									cmul(rtb212,tdsr21[ip]));
								tdfr12[ijk1]=cadd(cmul(rtb211,tdsr12[ip]),
									cmul(rtb212,tdsr22[ip]));
								tdfr21[ijk1]=cadd(cmul(rtb221,tdsr11[ip]),
									cmul(rtb222,tdsr21[ip]));
								tdfr22[ijk1]=cadd(cmul(rtb221,tdsr12[ip]),
									cmul(rtb222,tdsr22[ip]));
								rtb111=cadd(cmul(rtb211,rusr11[ip]),
									cmul(rtb212,rusr21[ip]));
								rtb112=cadd(cmul(rtb211,rusr12[ip]),cmul(rtb212,
									rusr22[ip]));
								rtb121=cadd(cmul(rtb221,rusr11[ip]),cmul(rtb222,
									rusr21[ip]));
								rtb122=cadd(cmul(rtb221,rusr12[ip]),cmul(rtb222,
									rusr22[ip]));
								rurf11[ijk1]=cadd(cmul(rtb111,turf11[ijk1]),
									cadd(cmul(rtb112,turf21[ijk1]),
									rurf11[ijk1]));
								rurf12[ijk1]=cadd(cmul(rtb111,turf12[ijk1]),
									cadd(cmul(rtb112,turf22[ijk1]),
									rurf12[ijk1]));
								rurf21[ijk1]=cadd(cmul(rtb121,turf11[ijk1]),
									cadd(cmul(rtb122,turf21[ijk1]),
									rurf21[ijk1]));
								rurf22[ijk1]=cadd(cmul(rtb121,turf12[ijk1]),
									cadd(cmul(rtb122,turf22[ijk1]),
									rurf22[ijk1]));
							}
						} else if (acoustic[iz]==0) {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								rtb111=csub(rd0n11[ip],rdfr11[ijk1]);
								rtb112=csub(rd0n12[ip],rdfr12[ijk1]);
								rtb121=csub(rd0n21[ip],rdfr21[ijk1]);
								rtb122=csub(rd0n22[ip],rdfr22[ijk1]);
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rtb211=cdiv(rtb122,det);
								rtb212=cneg(cdiv(rtb112,det));
								rtb221=cneg(cdiv(rtb121,det));
								rtb222=cdiv(rtb111,det);
								rtb311=cadd(cmul(rtb211,turf11[ijk1]),
									cmul(rtb212,turf21[ijk1]));
								rtb312=cadd(cmul(rtb211,turf12[ijk1]),
									cmul(rtb212,turf22[ijk1]));
								rtb321=cadd(cmul(rtb221,turf11[ijk1]),
									cmul(rtb222,turf21[ijk1]));
								rtb322=cadd(cmul(rtb221,turf12[ijk1]),	
									cmul(rtb222,turf22[ijk1]));
								rtb111=cadd(cmul(tdfr11[ijk1],rtb311),cadd(
									cmul(tdfr12[ijk1],rtb321),rurf11[ijk1]));
								rtb112=cadd(cmul(tdfr11[ijk1],rtb312),cadd(
									cmul(tdfr12[ijk1],rtb322),rurf12[ijk1]));
								rtb121=cadd(cmul(tdfr21[ijk1],rtb311),cadd(
									cmul(tdfr22[ijk1],rtb321),rurf21[ijk1]));
								rtb122=cadd(cmul(tdfr21[ijk1],rtb312),cadd(
									cmul(tdfr22[ijk1],rtb322),rurf22[ijk1]));
								det=csub(cmul(rtb111,rtb122),
									cmul(rtb112,rtb121));
								rdnr11[ip]=cdiv(rtb122,det);
								rdnr12[ip]=cneg(cdiv(rtb112,det));
								rdnr21[ip]=cneg(cdiv(rtb121,det));
								rdnr22[ip]=cdiv(rtb111,det);
							}
						} else if (acoustic[iz]==1) {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								rtb211=cdiv(turf11[ijk1],csub(rd0n11[ip],
									rdfr11[ijk1]));
								rdnr11[ip]=cdiv(cmplx(1.0,0.0),cadd(cmul(tdfr11[ijk1],
									rtb211),rurf11[ijk1]));
								rdnr12[ip]=cmplx(0.0,0.0);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
							}
						}
					} else {
						if (acoustic[iz]==0||acoustic[iz]==1||acoustic[iz]==2) {
							for (ip=0; ip<block_size; ip++) {
								rdnr11[ip]=cmplx(0.0,0.0);
								rdnr12[ip]=cmplx(0.0,0.0);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
							}
						} else {
							for (ip=0; ip<block_size; ip++) {
								ijk1=ik1+ip;
								rdnr11[ip]=cmplx(0.0,0.0);
								rdnr12[ip]=cmplx(0.0,0.0);
								rdnr21[ip]=cmplx(0.0,0.0);
								rdnr22[ip]=cmplx(0.0,0.0);
								rtb111=cadd(cmul(rusr11[ip],rdfr11[ijk1]),
									cmul(rusr12[ip],rdfr21[ijk1]));
								rtb112=cadd(cmul(rusr11[ip],rdfr12[ijk1]),
									cmul(rusr12[ip],rdfr22[ijk1]));
								rtb121=cadd(cmul(rusr21[ip],rdfr11[ijk1]),
									cmul(rusr22[ip],rdfr21[ijk1]));
								rtb122=cadd(cmul(rusr21[ip],rdfr12[ijk1]),
									cmul(rusr22[ip],rdfr22[ijk1]));
								x=csub(cmplx(1.0,0.0),rtb111);
								y=csub(cmplx(1.0,0.0),rtb122);
								det=csub(cmul(x,y),cmul(rtb112,rtb121));
								rvrb111=cdiv(y,det);
								rvrb112=cdiv(rtb112,det);
								rvrb121=cdiv(rtb121,det);
								rvrb122=cdiv(x,det);
								rtb211=cadd(cmul(tdfr11[ijk1],rvrb111),
									cmul(rvrb121,tdfr12[ijk1]));
								rtb212=cadd(cmul(tdfr11[ijk1],rvrb112),
									cmul(rvrb122,tdfr12[ijk1]));
								rtb221=cadd(cmul(tdfr21[ijk1],rvrb111),
									cmul(rvrb121,tdfr22[ijk1]));
								rtb222=cadd(cmul(tdfr21[ijk1],rvrb112),
									cmul(rvrb122,tdfr22[ijk1]));
								tdfr11[ijk1]=cadd(cmul(rtb211,tdsr11[ip]),
									cmul(rtb212,tdsr21[ip]));
								tdfr12[ijk1]=cadd(cmul(rtb211,tdsr12[ip]),
									cmul(rtb212,tdsr22[ip]));
								tdfr21[ijk1]=cadd(cmul(rtb221,tdsr11[ip]),
									cmul(rtb222,tdsr21[ip]));
								tdfr22[ijk1]=cadd(cmul(rtb221,tdsr12[ip]),
									cmul(rtb222,tdsr22[ip]));
								rtb111=cadd(cmul(rtb211,rusr11[ip]),
									cmul(rtb212,rusr21[ip]));
								rtb112=cadd(cmul(rtb211,rusr12[ip]),
									cmul(rtb212,rusr22[ip]));
								rtb121=cadd(cmul(rtb221,rusr11[ip]),
									cmul(rtb222,rusr21[ip]));
								rtb122=cadd(cmul(rtb221,rusr12[ip]),
									cmul(rtb222,rusr22[ip]));
								rurf11[ijk1]=cadd(cmul(rtb111,turf11[ijk1]),
									cadd(cmul(rtb112,turf21[ijk1]),
									rurf11[ijk1]));
								rurf12[ijk1]=cadd(cmul(rtb111,turf12[ijk1]),
									cadd(cmul(rtb112,turf22[ijk1]),
									rurf12[ijk1]));
								rurf21[ijk1]=cadd(cmul(rtb121,turf11[ijk1]),
									cadd(cmul(rtb122,turf21[ijk1]),
									rurf21[ijk1]));
								rurf22[ijk1]=cadd(cmul(rtb121,turf12[ijk1]),
									cadd(cmul(rtb122,turf22[ijk1]),
									rurf22[ijk1]));
							}
						}
					}	
					if (flag[iz]==2) {
						flag[iz]=prv[iz];	
					}
					for (ip=0; ip<block_size; ip++) {
						ijk1=ik1+ip;
						ijk2=ik2+ip;
						rtb111=cadd(cmul(rurf11[ijk1],rdnr11[ip]),
							cmul(rurf12[ijk1],rdnr21[ip]));
						rtb112=cadd(cmul(rurf11[ijk1],rdnr12[ip]),
							cmul(rurf12[ijk1],rdnr22[ip]));
						rtb121=cadd(cmul(rurf21[ijk1],rdnr11[ip]),
							cmul(rurf22[ijk1],rdnr21[ip]));
						rtb122=cadd(cmul(rurf21[ijk1],rdnr12[ip]),
							cmul(rurf22[ijk1],rdnr22[ip]));
						x=csub(cmplx(1.0,0.0),rtb111);
						y=csub(cmplx(1.0,0.0),rtb122);
						det=csub(cmul(x,y),cmul(rtb112,rtb121));
						rvrb111=cdiv(y,det);
						rvrb112=cdiv(rtb112,det);
						rvrb121=cdiv(rtb121,det);
						rvrb122=cdiv(x,det);
						rtb111=cadd(cmul(rvrb111,tdfr11[ijk1]),cmul(rvrb112,
							tdfr21[ijk1]));
						rtb112=cadd(cmul(rvrb111,tdfr12[ijk1]),cmul(rvrb112,
							tdfr22[ijk1])); 
						rtb121=cadd(cmul(rvrb121,tdfr11[ijk1]),cmul(rvrb122,
							tdfr21[ijk1]));
						rtb122=cadd(cmul(rvrb121,tdfr12[ijk1]),cmul(rvrb122,
							tdfr22[ijk1]));
						rtb211=cadd(cmul(rdnr11[ip],rtb111),cmul(rdnr12[ip],
							rtb121));
						rtb212=cadd(cmul(rdnr11[ip],rtb112),cmul(rdnr12[ip],
							rtb122));
						rtb221=cadd(cmul(rdnr21[ip],rtb111),cmul(rdnr22[ip],
							rtb121));
						rtb222=cadd(cmul(rdnr21[ip],rtb112),cmul(rdnr22[ip],
							rtb122));
						rtb311=cadd(cmul(rusf11[ip],rd0n11[ip]),cmul(rusf12[ip],
							rd0n21[ip]));
						rtb312=cadd(cmul(rusf11[ip],rd0n12[ip]),cmul(rusf12[ip],
							rd0n22[ip]));
						rtb321=cadd(cmul(rusf21[ip],rd0n11[ip]),cmul(rusf22[ip],
							rd0n21[ip]));
						rtb322=cadd(cmul(rusf21[ip],rd0n12[ip]),cmul(rusf22[ip],
							rd0n22[ip]));
						x=csub(cmplx(1.0,0.0),rtb311);
						y=csub(cmplx(1.0,0.0),rtb322);
						det=csub(cmul(x,y),cmul(rtb312,rtb321));
						rvrb111=cdiv(y,det);
						rvrb112=cdiv(rtb312,det);
						rvrb121=cdiv(rtb321,det);
						rvrb122=cdiv(x,det);
						fact11=cadd(cmul(rusf11[ip],sigmau1[ip]),
							cadd(cmul(rusf12[ip],sigmau2[ip]),sigmad1[ip]));
						fact12=cadd(cmul(rusf21[ip],sigmau1[ip]),
							cadd(cmul(rusf22[ip],sigmau2[ip]),sigmad2[ip]));
						vdzs1=cadd(cmul(rvrb111,fact11),cmul(rvrb112,fact12));
						vdzs2=cadd(cmul(rvrb121,fact11),cmul(rvrb122,fact12));
						up[ip]=cmul(prs[iz],cadd(cmul(cadd(rtb111,rtb211),
							vdzs1),cmul(cadd(rtb112,rtb212),vdzs2)));
						rtb211=cadd(cmul(p[ip],rdnr11[ip]),cmul(gt[ijk2],
							rdnr21[ip]));
						rtb212=cadd(cmul(p[ip],rdnr12[ip]),cmul(gt[ijk2],
							rdnr22[ip]));
						rtb221=csub(cmul(rdnr21[ip],p[ip]),cmul(gl[ijk2],
							rdnr11[ip]));
						rtb222=csub(cmul(rdnr22[ip],p[ip]),cmul(gl[ijk2],
							rdnr12[ip]));
						rtb311=cadd(p[ip],rtb211);
						rtb312=csub(rtb212,gt[ijk2]);
						rtb321=cadd(gl[ijk2],rtb221);
						rtb322=cadd(p[ip],rtb222);
						rtb211=cadd(cmul(rtb311,rtb111),cmul(rtb312,rtb121));
						rtb212=cadd(cmul(rtb311,rtb112),cmul(rtb312,rtb122));
						rtb221=cadd(cmul(rtb321,rtb111),cmul(rtb322,rtb121));
						rtb222=cadd(cmul(rtb321,rtb112),cmul(rtb322,rtb122));
						ux[ip]=cadd(cmul(rtb211,vdzs1),cmul(rtb212,vdzs2));
						uz[ip]=cadd(cmul(rtb221,vdzs1),cmul(rtb222,vdzs2));
					}
				}

				/* loop over ranges (traces) */
				for (ix=0; ix<nx; ix++) {
					x1=bx+dx*ix;
					if (x1==0.0) { /* zero offset traces are a special case */
						for (ip=1; ip<block_size-1; ip++) {
							t1=cdiv(cmplx(1.0,0.0),csqrt(p[ip]));
							vos1[ip]=cmul(up[ip],t1);
							vos2[ip]=cmul(ux[ip],t1);
							vos3[ip]=cmul(uz[ip],t1);
						}
						vos1[0]=cmplx(0.0,0.0);
						vos1[1]=crmul(vos1[1],0.5);
						vos1[block_size-2]=crmul(vos1[block_size-2],.5);
					} else {
						temr=crmul(wpie,2*PI*x1);
						temr=cdiv(tem,csqrt(temr));
						sig=crmul(divfac,x1);
						sigh=cmul(sig,cdp);
						for (ip=0; ip<block_size; ip++) {
							texp[ip]=cexp(cmul(sig,p[ip]));
						}

						/******************************************************
						*		compute the slowness inytegral				*
						******************************************************/
						if (int_type==1) { 		/* use trapezoidal rule */
							temr=crmul(cmul(temr,cdp),0.5);
							for (ip=0; ip<block_size-1; ip++) {
								jj=ip+1;
								vos1[ip]=cmul(temr,cadd(cmul(up[ip],texp[ip]),
									cmul(up[jj],texp[jj])));
								vos2[ip]=cmul(temr,cadd(cmul(ux[ip],texp[ip]),
									cmul(ux[jj],texp[jj])));
								vos3[ip]=cmul(temr,cadd(cmul(uz[ip],texp[ip]),
									cmul(uz[jj],texp[jj])));
							}
						} else if (int_type==2) { /* use first order Filon */
							for (ip=0; ip<block_size-1; ip++) {
								jj=ip+1;
								t1=csub(texp[jj],texp[ip]);
								func1=csub(cmul(up[jj],texp[jj]),
									cmul(up[ip],texp[ip]));
								func2=cmul(csub(up[jj],up[ip]),t1);
								func3=csub(cmul(ux[jj],texp[jj]),
									cmul(ux[ip],texp[ip]));
								func4=cmul(csub(ux[jj],ux[ip]),t1);
								func5=csub(cmul(uz[jj],texp[jj]),
									cmul(uz[ip],texp[ip]));
								func6=cmul(csub(uz[jj],uz[ip]),t1);
								vos1[ip]=cmul(cdiv(cdp,sigh),
									cmul(csub(func1,cdiv(func2,sigh)),temr));
								vos2[ip]=cmul(cdiv(cdp,sigh),
									cmul(csub(func3,cdiv(func4,sigh)),temr));
								vos3[ip]=cmul(cdiv(cdp,sigh),
									cmul(csub(func5,cdiv(func6,sigh)),temr));
							}
						}
					}
				
					/**********************************************************
					* 				update output arrays			
					**********************************************************/
					for (ip=0; ip<block_size-1; ip++) {
						response1[iw][ix][iz]=cadd(response1[iw][ix][iz],
							vos1[ip]);
						response2[iw][ix][iz]=cadd(response2[iw][ix][iz],
							vos2[ip]);
						response3[iw][ix][iz]=cadd(response3[iw][ix][iz],
							vos3[ip]);
					}
				}
			}

			/******************************************************************
			* 						update loop variables					*
			*****************************************************************/
			nblock--;
			if (nblock != 0) {

				bp=p[block_size-1].r;
				left++;
				if (left > block_size) {
					left -=block_size;
					nblock++;
				}

			} else {
				if (int_type==1) bp=bp1;
				else if (int_type==2) bp=0.0;
				break;		/* last block, exit while loop */
			}
		}
	}

	/* if requested, output some important processing information */
	if (verbose==1||verbose==3) {
   		fprintf(stderr,"\nA total of %d frequencies, from %g to %g (Hz)\n"
			"and a total of %d ray parameters, from %g to %g (s/km) were "
			"processed\n",nw,wbeg,wfin,np,bp,fp);
	} 
	if (verbose==2||verbose==3) {
   		fprintf(outfp,"\nA total of %d frequencies, from %g to %g (Hz)\n"
			"and a total of %d ray parameters, from %g to %g (s/km) were "
			"processed\n",nw,wbeg,wfin,np,bp,fp);
	} 

	/* free allocated space */
	free1complex(ux);free1complex(uz);free1complex(up);
	free1complex(rd0n11);free1complex(rd0n12);free1complex(rd0n21);
	free1complex(rd0n22);free1complex(td0n11);free1complex(td0n12);
	free1complex(td0n22);free1complex(tun011);free1complex(tun012);
	free1complex(tun021);free1complex(tun022);free1complex(run011);
	free1complex(run012);free1complex(run021);free1complex(run022);
	free1complex(tusf11);free1complex(tusf12);free1complex(tusf21);
	free1complex(tusf22);free1complex(rdfs11);free1complex(rdfs12);
	free1complex(rdfs21);free1complex(rdfs22);free1complex(tdfs11);
	free1complex(tdfs12);free1complex(tdfs21);free1complex(tdfs22);
	free1complex(rurf11);free1complex(rurf12);free1complex(rurf21);
	free1complex(rurf22);free1complex(turf11);free1complex(turf12);
	free1complex(turf21);free1complex(turf22);free1complex(rdfr11);
	free1complex(rdfr12);free1complex(rdfr21);free1complex(rdfr22);
	free1complex(tdfr11);free1complex(tdfr12);free1complex(tdfr21);
	free1complex(tdfr22);free1complex(rnr11);free1complex(rnr12);
	free1complex(rnr21);free1complex(rnr22);free1complex(rdsr11);
	free1complex(rdsr12);free1complex(rdsr21);free1complex(rdsr22);
	free1complex(r11);free1complex(r12);free1complex(r21);free1complex(r22);
	free1complex(vos1);free1complex(vos2);free1complex(vos3);

	/* free more working space */ 
	free1complex(p);
	free1complex(pp);
	free1complex(pwin);
	free1complex(gl);
	free1complex(gt);
	free1complex(gam);
	free1complex(alpha);
	free1complex(betha);
	free1complex(sigmau1);
	free1complex(sigmau2);
	free1complex(sigmad1);
	free1complex(sigmad2);
}

#define BLK 100
#define IMAX 300
#define SZERO 0.000000000001

/**********************************Self-Documentation**************************/
/******************************************************************************
SH_REFLECTIVITIES -	Subroutines to do matrix propagation as the hard core of 
						a reflectivity modeling code for SH wavefields

sh_reflectivities		applies matrix propagation to compute the SH 
						reflectivity response of a horizontally stratified 
						earth model

*******************************************************************************
Function Prototypes:
void sh_reflectivities (int int_type, int verbose, int wtype, int nw,
	int nlayers, int nx, int layern, int nor, int np, float bp1, float m1,
	float m2, float m3, float h1, float h2, int lsource, float bx, float dx,
	float xmax, float decay, float fref, float wrefp, float wrefs, float tsec,
	float p2w, float fs, float epsp, float epss, float sigp, float sigs,
	float pw1, float pw2, float pw3, float pw4, int *flag, int *lobs,
	float *rho, float *t, float *cl, float *ct, float *ql, float *qt,
	complex ***response1, FILE *outfp);
*******************************************************************************
sh_reflectivities
Input:
nw  			number of frequencies
nlayers 		number of reflecting layers
nx  			number of ranges
nor 			number of receivers
lsource 		layer on top of which the source is located
bx  			beginning range
fx  			final range
dx  			range increment
flag			array[nor] of flags for source type
rho 			array[nlayers] of densities
t   			array[nlayers] of layer thicknesses

Output
response1   	array[nw][nor][nx] of updated tangential field response
*******************************************************************************
Credits:



******************************************************************************/
/*****************************End Self-Documentation**************************/




/******************************************************************************

		Subroutine to compute the SH propagation matrices for a single
							frequency step

******************************************************************************/
void sh_reflectivities (int int_type, int verbose, int wtype, int nw,
	int nlayers, int nx, int layern, int nor, int np, float bp1, float m1,
	float m2, float m3, float h1, float h2, int lsource, float bx, float dx,
	float xmax, float decay, float fref, float wrefp, float wrefs, float tsec,
	float p2w, float fs, float epsp, float epss, float sigp, float sigs,
	float pw1, float pw2, float pw3, float pw4, int *flag, int *lobs,
	float *rho, float *t, float *cl, float *ct, float *ql, float *qt,
	complex ***response1, FILE *outfp)
/******************************************************************************
Input:
nw  			number of frequencies
nlayers 		number of reflecting layers
nx  			number of ranges
nor 			number of receivers
lsource 		layer on top of which the source is located
bx  			beginning range
fx  			final range
dx  			range increment
flag			array[nor] of flags for source type
rho 			array[nlayers] of densities
t   			array[nlayers] of layer thicknesses

Output
response1   	array[nw][nor][nx] of updated tangencialfield response
******************************************************************************/
{
	int iw,iz,ip,ix;			/* loop counters */
	int ijk1=0,ik1,ik2,il,jl;	/* auxiliary indices */
	int ijk=0,ijk2,jj;			/* more auxiliary indices */
	int lrec;				
	float bp;					/* beginning ray parameter */
	float fp;					/* final ray parameter */
	float dp;					/* ray parameter increment */
	int nblock;					/* number of blocks to process */
	int block_size;				/* size of processing blocks */
	int left;					/* remainder */
	int *prv,*ibl;				/* scratch arrays */
	float x1;
	float w;
	complex wpie,cdp;			/* complex frecuency and ray parameter inc */
		
	/* complex auxiliary variables */
	complex x,y,t1,divfac;
	complex det,psq,gl1,gt1,gl2,gt2,gam1,gam2,at1,at2,al1,al2;
	complex tem,temr,sig,sigh,rho1,rho2;
	complex rvrb111,rvrb112,rvrb121,rvrb122,rvrb211;
	complex ewigh11,ewigh22,wrn011,ewrd11;
	complex ewd0211,ewd0212,ewtu211;
	complex rtb111,rtb112,rtb121,rtb122,rtb211;
	complex rtb212,rtb221,rtb222,rtb311,rtb312,rtb321,rtb322;
	complex func1,func2;
	complex tun0p11,tun0p21,rd0np11,rd0np12,rd0np21;
	complex rd0np22,td0np11,td0np12;
	complex rd11,td11,tu11,ru11;
	complex fact11,fact12,vuzs1,vuzs2,vdzs1,vdzs2;

	/* complex scratch arrays */
	complex *rd0n11,*rd0n12,*rd0n21,*rd0n22,*td0n11,*td0n12;
	complex *td0n21,*td0n22,*tun011,*tun012,*tun021,*tun022;
	complex *run011,*run012,*run021,*run022;
	complex *rusf21,*rusf22,*tusf11,*tusf12,*tusf21,*tusf22;
	complex *rdfs11,*rdfs12,*rdfs21,*rdfs22,*rurf11,*rurf12;
	complex *rurf21,*rurf22,*turf11,*turf12,*turf21,*turf22;
	complex *rdfr11,*rdfr12,*rdfr21,*rdfr22,*tdfr11,*tdfr12;
	complex *tdfr21,*tdfr22,*r11,*r12,*r21,*r22;
	complex *texp,*vos1,*vos2,*vos3,*up;
	complex *sigmau1,*sigmau2,*sigmad1,*sigmad2,*alpha,*betha;
	complex *al,*at,*gl,*gt,*gam,*p,*pp,*prs,*pwin;
	
	/* complex pointers */
	complex *rusf11,*rusf12;
	complex *tusr11,*tusr12,*tusr21,*tusr22;
	complex *rusr11,*rusr12,*rusr21,*rusr22;
	complex *tdsr11,*tdsr12,*tdsr21,*tdsr22;
	complex *rdnr11,*rdnr12,*rdnr21,*rdnr22;

	/* allocate working space */

	/* allocate working space */
	up=alloc1complex(BLK);
	rd0n11=alloc1complex(BLK);rd0n12=alloc1complex(BLK);
	rd0n21=alloc1complex(BLK);rd0n22=alloc1complex(BLK);
	td0n11=alloc1complex(BLK);td0n12=alloc1complex(BLK);
	td0n21=alloc1complex(BLK);td0n22=alloc1complex(BLK);
	tun011=alloc1complex(BLK);tun012=alloc1complex(BLK);
	tun021=alloc1complex(BLK);tun022=alloc1complex(BLK);
	run011=alloc1complex(BLK);run012=alloc1complex(BLK);
	run021=alloc1complex(BLK);run022=alloc1complex(BLK);
	tusf11=alloc1complex(BLK);tusf12=alloc1complex(BLK);
	tusf21=alloc1complex(BLK);tusf22=alloc1complex(BLK);
	rdfs11=alloc1complex(BLK);rdfs12=alloc1complex(BLK);
	rdfs21=alloc1complex(BLK);rdfs22=alloc1complex(BLK);
	rurf11=alloc1complex(IMAX);rurf12=alloc1complex(IMAX);
	rurf21=alloc1complex(IMAX);rurf22=alloc1complex(IMAX);
	turf11=alloc1complex(IMAX);turf12=alloc1complex(IMAX);
	turf21=alloc1complex(IMAX);turf22=alloc1complex(IMAX);
	rdfr11=alloc1complex(IMAX);rdfr12=alloc1complex(IMAX);
	rdfr21=alloc1complex(IMAX);rdfr22=alloc1complex(IMAX);
	tdfr11=alloc1complex(IMAX);tdfr12=alloc1complex(IMAX);
	tdfr21=alloc1complex(IMAX);tdfr22=alloc1complex(IMAX);
	rusf21=alloc1complex(BLK);rusf22=alloc1complex(BLK);
	vos1=alloc1complex(BLK);vos2=alloc1complex(BLK);vos3=alloc1complex(BLK);
	r11=alloc1complex(BLK);r12=alloc1complex(BLK);
	r21=alloc1complex(BLK);texp=alloc1complex(BLK);

	/* allocate other working space */
	prv=alloc1int(nor);
	ibl=alloc1int(BLK);
    p=alloc1complex(BLK);
    pp=alloc1complex(BLK);
    pwin=alloc1complex(BLK);
    gl=alloc1complex(BLK);
    gt=alloc1complex(BLK*nlayers);
    gam=alloc1complex(BLK*nlayers);
    alpha=alloc1complex(BLK);
    betha=alloc1complex(BLK);
    sigmau1=alloc1complex(BLK);
    sigmau2=alloc1complex(BLK);
    sigmad1=alloc1complex(BLK);
    sigmad2=alloc1complex(BLK);

	/* initialize pointers */
	rusf11=alpha;
	rusf12=betha;
	tusr11=tun011;
	tusr12=tun012;
	tusr21=tun021;
	tusr22=tun022;
	rusr11=run011;
	rusr12=run012;
	rusr21=run021;
	rusr22=run022;
	tdsr11=td0n11;
	tdsr12=td0n12;
	tdsr21=td0n21;
	tdsr22=td0n22;
	rdnr11=r11;
	rdnr12=r12;
	rdnr21=r21;
	rdnr22=r22;

	/* assign initial value to working variables */
	tem=cdiv(cmplx(1.0,0.0),cexp(crmul(cmplx(0.0,1.0),PI/4)));
	ewigh11=cmplx(0.0,0.0);
	ewigh22=cmplx(0.0,0.0);

	/* initialize complex output arrays */
    for (iw=0; iw<nw; iw++)
	for (ix=0; ix<nx; ix++)
	    for (iz=0; iz<nor; iz++) {
		response1[iw][ix][iz]=cmplx(0.0,0.0);
	    }


	/**************************************************************************
	*					Main loop over frequencies			    *	
	**************************************************************************/
	for (iw=0; iw<nw; iw++) {
		w=(iw+1)*PI*2/tsec;		/* w in radians/sec */
		wpie=cmplx(w,decay);		/* complex w */

		/* compute frequency-dependent auxiliary variables for reflectivity */
		compute_w_aux_arrays (wtype, layern, nlayers, nor, lsource,
			&np, &block_size, &nblock, &left, fref, wrefp, wrefs, 
			lobs, tsec, p2w, fs, xmax, w, decay, epsp, epss, sigp, 
			sigs, &pw1, &pw2, &pw3, &pw4, &dp, &fp, wpie, &cdp, cl,
			ct, ql, qt, rho, t, al, at, prs);

		/**********************************************************************
		* 	loop over slopes to compute the reflectivities (by blocks)		  *
		**********************************************************************/
		while (1) {

			if ((nblock==1) && (left !=0)) block_size=left;

			/* compute p_aux_arrays */
			compute_p_aux_arrays (wtype, nlayers, lsource, block_size, bp, dp,
		w, decay, pw1, pw2, pw3, pw4, pwin, m1, m2, m3, h1, h2,
		wpie, &divfac, p, pp, al, at, rho, gl, gt, gam, alpha, betha,
				sigmad1, sigmad2, sigmau1, sigmau2);

			/* if requested, output processing information */
			if (verbose==1||verbose==3) {
				fprintf(stderr,"%3d%6.1f%7.3f%7.3f%6d%7.3f%7.3f%7.3f"
				"%7.3f%7.3f\n",iw,w,bp,fp,np,dp,pw1,pw2,pw3,pw4);
			} if (verbose==2||verbose==3) {
				fprintf(outfp,"%3d%6.1f%7.3f%7.3f%6d%7.3f%7.3f%7.3f"
				"%7.3f%7.3f\n",iw,w,bp,fp,np,dp,pw1,pw2,pw3,pw4);
			}



			/******************************************************************
			* 			start the computation of the reflectivities 		*
			******************************************************************/
			/* loop over reflecting layers */
			for (il=0; il<nlayers; il++) {
				jl=il+1;
				ik1=il*block_size;
				ik2=(il+1)*block_size;
				al1=al[il];
				al2=al[jl];
				at1=at[il];
				at2=at[jl];
				rho1=cmplx(rho[il],0.0);
				rho2=cmplx(rho[jl],0.0);
				t1=cmplx(t[il],0.0);
				if (il==0) {
					for (ip=0; ip<block_size; ip++) {
						ijk1=ik1+ip;
						gt1=gt[ijk1];
						ewigh11=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gt1,t1))));
						rd0n11[ip]=cmplx(0.0,0.0);
						rd0n12[ip]=cmplx(0.0,0.0);
						rd0n21[ip]=cmplx(0.0,0.0);
						rd0n22[ip]=cmplx(0.0,0.0);

						/* free surface */
						td0n11[ip]=ewigh11;
						td0n12[ip]=cmplx(0.0,0.0);
						td0n21[ip]=cmplx(0.0,0.0);
						td0n22[ip]=cmplx(0.0,0.0);
						tun011[ip]=ewigh11;
						tun012[ip]=cmplx(0.0,0.0);
						tun021[ip]=cmplx(0.0,0.0);
						tun022[ip]=cmplx(0.0,0.0);
						run011[ip]=cmul(ewigh11,ewigh11);
						run012[ip]=cmplx(0.0,0.0);
						run021[ip]=cmplx(0.0,0.0);
						run022[ip]=cmplx(0.0,0.0);
					}	
				} else {
					if ((at1.r==at2.r)&&(at1.i==at2.i)) {
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							gt1=gt[ijk1];
							ewigh11=cexp(cmul(cmplx(0.0,1.0),cmul(wpie,cmul(gt1,t1))));
							tun0p11=cmul(tun011[ip],ewigh11);
							tun0p21=cmul(tun021[ip],ewigh11);
						
							/* -R/T coefficients betha1=betha2 */
							rtb111=cmul(ewigh11,run011[ip]);
							run011[ip]=cmul(rtb111,ewigh11);
							run012[ip]=cmplx(0.0,0.0);
							run021[ip]=cmplx(0.0,0.0);
							run022[ip]=cmplx(0.0,0.0);
							td0np11=cmul(ewigh11,td0n11[ip]);
							td0np12=cmul(ewigh11,td0n12[ip]);
							tun011[ip]=tun0p11;
							tun012[ip]=cmplx(0.0,0.0);
							tun021[ip]=tun0p21;
							tun022[ip]=cmplx(0.0,0.0);
							td0n11[ip]=td0np11;
							td0n12[ip]=td0np12;
							td0n21[ip]=cmplx(0.0,0.0);
							td0n22[ip]=cmplx(0.0,0.0);
						}
					} else {
		
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							ijk2=ik2+ip;
							psq=pp[ip];
							gl1=gl[ijk1];
							gt1=gt[ijk1];
							gam1=gam[ijk1];
							gl2=gl[ijk2];
							gt2=gt[ijk2];
							gam2=gam[ijk2];
							ewigh11=cexp(cmul(wpie,cmul(cmplx(0.0,1.0),cmul(t1,gt1))));
							y=cadd(cmul(rho1,cdiv(gt1,cmul(at1,at1))),
								cmul(rho2,cdiv(gt2,cmul(at2,at2))));
							td11=crmul(cmul(rho1,cdiv(gt1,cmul(y,
								cmul(at1,at1)))),2.);
							rd11=cdiv(csub(cmul(rho1,cdiv(at1,at1)),
								cmul(rho1,cdiv(gt2,cmul(at2,at2)))),y);
							tu11=crmul(cmul(rho2,cdiv(gt2,cmul(y,
								cmul(at2,at2)))),2.);
							ru11=cneg(rd11);
							ewrd11=cmul(ewigh11,rd11);
							wrn011=cmul(ewigh11,run011[ip]);
							rvrb111=cdiv(cmplx(1.0,0.0),csub(cmplx(1.0,0.0),cmul(wrn011,ewrd11)));
							rvrb211=cadd(cmplx(1.0,0.0),cmul(rvrb111,cmul(ewrd11,wrn011)));
							ewd0211=cmul(td0n11[ip],cmul(rvrb111,ewigh11));
							ewd0212=cmul(td0n12[ip],cmul(rvrb111,ewigh11));
							td0n11[ip]=cmul(td11,ewd0211);
							td0n12[ip]=cmul(td11,ewd0212);
							td0n21[ip]=cmplx(0.0,0.0);
							td0n22[ip]=cmplx(0.0,0.0);
							ewtu211=cmul(rvrb211,cmul(ewigh11,tu11));
							tun0p11=cmul(ewtu211,tun011[ip]);
							tun0p21=cmul(ewtu211,tun021[ip]);
							rtb111=cmul(ewrd11,ewd0211);
							rtb112=cmul(ewrd11,ewd0212);
							rd0np11=cadd(rd0n11[ip],cmul(tun011[ip],rtb111));
							rd0np12=cadd(rd0n12[ip],cmul(tun011[ip],rtb112));
							rd0np21=cadd(rd0n21[ip],cmul(tun021[ip],rtb111));
							rd0np22=cadd(rd0n22[ip],cmul(tun022[ip],rtb112));
							run011[ip]=cadd(ru11,cmul(ewtu211,
								cmul(wrn011,td11)));
							run012[ip]=cmplx(0.0,0.0);
							run021[ip]=cmplx(0.0,0.0);
							run022[ip]=cmplx(0.0,0.0);
							tun011[ip]=tun0p11;
							tun012[ip]=cmplx(0.0,0.0);
							tun021[ip]=tun0p21;
							tun022[ip]=cmplx(0.0,0.0);
							rd0n11[ip]=rd0np11;
							rd0n12[ip]=rd0np12;
							rd0n21[ip]=rd0np21;
							rd0n22[ip]=rd0np22;
						}
					}
				} 
				if (il==lobs[ijk]-1) {
					ik1=ijk*block_size;		
					for (ip=0; ip<block_size; ip++) {
						iz=ik1+ip;
						rurf11[iz]=run011[ip];
						rurf12[iz]=run012[ip];
						rurf21[iz]=run021[ip];
						rurf22[iz]=run022[ip];
						rdfr11[iz]=rd0n11[ip];
						rdfr12[iz]=rd0n12[ip];
						rdfr21[iz]=rd0n21[ip];
						rdfr22[iz]=rd0n22[ip];
						turf11[iz]=tun011[ip];
						turf12[iz]=tun012[ip];
						turf21[iz]=tun021[ip];
						turf22[iz]=tun022[ip];
						tdfr11[iz]=td0n11[ip];
						tdfr12[iz]=td0n12[ip];
						tdfr21[iz]=td0n21[ip];
						tdfr22[iz]=td0n22[ip];
					}
					ijk++;
				} 

				if (il==lsource-1) {
			    for (ip=0; ip<block_size; ip++) {
				rusf11[ip]=run011[ip];
				rusf12[ip]=run012[ip];
				rusf21[ip]=run021[ip];
				rusf22[ip]=run022[ip];
				rdfs11[ip]=rd0n11[ip];
				rdfs12[ip]=rd0n12[ip];
				rdfs21[ip]=rd0n21[ip];
				rdfs22[ip]=rd0n22[ip];
				run011[ip]=cmplx(0.0,0.0);
				run012[ip]=cmplx(0.0,0.0);
				run021[ip]=cmplx(0.0,0.0);
				run022[ip]=cmplx(0.0,0.0);
				rd0n11[ip]=cmplx(0.0,0.0);
				rd0n12[ip]=cmplx(0.0,0.0);
				rd0n21[ip]=cmplx(0.0,0.0);
				rd0n22[ip]=cmplx(0.0,0.0);
				tusf11[ip]=tun011[ip];
				tusf12[ip]=tun012[ip];
				tusf21[ip]=tun021[ip];
				tusf22[ip]=tun022[ip];
				tun011[ip]=cmplx(1.0,0.0);
				tun012[ip]=cmplx(0.0,0.0);
				tun021[ip]=cmplx(0.0,0.0);
				tun022[ip]=cmplx(1.0,0.0);
				td0n11[ip]=cmplx(1.0,0.0);
				td0n12[ip]=cmplx(0.0,0.0);
				td0n21[ip]=cmplx(0.0,0.0);
				   	td0n22[ip]=cmplx(1.0,0.0);
	    		}
			}
    		}

			/* loop over receivers */
		    for (iz=0; iz<nor; iz++) {
			ik1=iz*block_size;
			for (ip=0; ip<block_size; ip++) {
			    ijk1=ik1+ip;    
			    det=csub(rd0n11[ip],rdfr11[ijk1]);
			    if (rcabs(det)<=SZERO) {
				prv[iz]=flag[iz];
				flag[iz]=2;
				ibl[iz]=ip;
				break;
			    }
			}
    		}


 		   for (iz=0; iz<nor; iz++) {
		ik1=iz*block_size;
			lrec=lobs[iz];
			ik2=(lrec-1)*block_size;

			/* receiver above the source */
			if (lsource>lrec) {
			    for (ip=0; ip<block_size; ip++) {
				ijk1=ik1+ip;
						ijk2=ik2+ip;
						rtb111=cdiv(cmplx(1.0,0.0),turf11[ijk1]);
						rdnr11[ip]=cmul(rtb111,tusf11[ip]);
						rdnr12[ip]=cmul(rtb111,tusf12[ip]);
						rdnr21[ip]=cmplx(0.0,0.0);
						rdnr22[ip]=cmplx(0.0,0.0);
						rtb111=rdnr11[ip];
						rtb112=rdnr12[ip];
						rtb121=rdnr21[ip];
						rtb122=rdnr22[ip];
						rtb211=cadd(cmul(rurf11[ijk1],rtb111),cmul(rurf12[ijk1],
							rtb121));
						rtb212=cadd(cmul(rurf11[ijk1],rtb112),cmul(rurf12[ijk1],
							rtb122));
						rtb221=cadd(cmul(rurf21[ijk1],rtb111),cmul(rurf22[ijk1],
							rtb121));
						rtb222=cadd(cmul(rurf21[ijk1],rtb112),cmul(rurf22[ijk1],
							rtb122));
						rtb311=cadd(cmul(rd0n11[ip],rusf11[ip]),cmul(rd0n12[ip],
							rusf21[ip]));
						rtb312=cadd(cmul(rd0n11[ip],rusf12[ip]),cmul(rd0n12[ip],
							rusf22[ip]));
						rtb321=cadd(cmul(rd0n21[ip],rusf11[ip]),cmul(rd0n22[ip],
							rusf21[ip]));
						rtb322=cadd(cmul(rd0n21[ip],rusf12[ip]),cmul(rd0n22[ip],
							rusf22[ip]));
						x=csub(cmplx(1.0,0.0),rtb311);
						y=csub(cmplx(1.0,0.0),rtb322);	
						det=csub(cmul(x,y),cmul(rtb312,rtb321));
						rvrb111=cdiv(y,det);
						rvrb112=cdiv(rtb312,det);
						rvrb121=cdiv(rtb321,det);
						rvrb122=cdiv(x,det);
						fact11=cadd(cmul(rd0n11[ip],sigmad1[ip]),
							cadd(cmul(rd0n12[ip],sigmad2[ip]),sigmau1[ip]));
						fact12=cadd(cmul(rd0n21[ip],sigmad1[ip]),
							cadd(cmul(rd0n22[ip],sigmad2[ip]),sigmau2[ip]));
						vuzs1=cadd(cmul(rvrb111,fact11),cmul(rvrb112,fact12));
						vuzs2=cadd(cmul(rvrb121,fact11),cmul(rvrb122,fact12));
						up[ip]=cmul(p[ip],cadd(cmul(cadd(rtb111,rtb211),vuzs1),
							cmul(cadd(rtb112,rtb212),vuzs2)));
					}
				} else {
				
					/* receiver below the source */
					if (flag[iz]==2) {
						for (ip=0; ip<ibl[iz]-1; ip++) {
							ijk1=ik1+ip;
							rtb211=cdiv(turf11[ijk1],csub(rd0n11[ip],
							rdfr11[ijk1]));
							rdnr11[ip]=cdiv(cmplx(1.0,0.0),cadd(cmul(tdfr11[ijk1],rtb211),
								rurf11[ijk1]));
							rdnr12[ip]=cmplx(0.0,0.0);   
							rdnr21[ip]=cmplx(0.0,0.0);   
							rdnr22[ip]=cmplx(0.0,0.0);   
						}
						for (ip=ibl[iz]-1; ip<block_size; ip++) {
							rdnr11[ip]=cmplx(0.0,0.0);
							rdnr12[ip]=cmplx(0.0,0.0);
							rdnr21[ip]=cmplx(0.0,0.0);
							rdnr22[ip]=cmplx(0.0,0.0);
						}
					} else if (flag[iz]==0) {
			
						for (ip=0; ip<block_size; ip++) {
							ijk1=ik1+ip;
							rtb211=cdiv(turf11[ijk1],csub(rd0n11[ip],
								rdfr11[ijk1]));
							rdnr11[ip]=cdiv(cmplx(1.0,0.0),cadd(cmul(tdfr11[ijk1],rtb211),
								rurf11[ijk1]));
							rdnr12[ip]=cmplx(0.0,0.0);
							rdnr21[ip]=cmplx(0.0,0.0);
							rdnr22[ip]=cmplx(0.0,0.0);
						}
					} else {
						for (ip=0; ip<block_size; ip++) {
							rdnr11[ip]=cmplx(0.0,0.0);
							rdnr12[ip]=cmplx(0.0,0.0);
							rdnr21[ip]=cmplx(0.0,0.0);
							rdnr22[ip]=cmplx(0.0,0.0);
						}
					}	
					if (flag[iz]==2) flag[iz]=prv[iz];	
					for (ip=0; ip<block_size; ip++) {
						ijk1=ik1+ip;
						ijk2=ik2+ip;
						rtb111=cadd(cmul(rurf11[ijk1],rdnr11[ip]),
							cmul(rurf12[ijk1],rdnr21[ip]));
						rtb112=cadd(cmul(rurf11[ijk1],rdnr12[ip]),
							cmul(rurf12[ijk1],rdnr22[ip]));
						rtb121=cadd(cmul(rurf21[ijk1],rdnr11[ip]),
							cmul(rurf22[ijk1],rdnr21[ip]));
						rtb122=cadd(cmul(rurf21[ijk1],rdnr12[ip]),
							cmul(rurf22[ijk1],rdnr22[ip]));
						x=csub(cmplx(1.0,0.0),rtb111);
						y=csub(cmplx(1.0,0.0),rtb122);
						det=csub(cmul(x,y),cmul(rtb112,rtb121));
						rvrb111=cdiv(y,det);
						rvrb112=cdiv(rtb112,det);
						rvrb121=cdiv(rtb121,det);
						rvrb122=cdiv(x,det);
						rtb111=cadd(cmul(rvrb111,tdfr11[ijk1]),cmul(rvrb112,
							tdfr21[ijk1]));
						rtb112=cadd(cmul(rvrb111,tdfr12[ijk1]),cmul(rvrb112,
							tdfr22[ijk1])); 
						rtb121=cadd(cmul(rvrb121,tdfr11[ijk1]),cmul(rvrb122,
							tdfr21[ijk1]));
						rtb122=cadd(cmul(rvrb121,tdfr12[ijk1]),cmul(rvrb122,
							tdfr22[ijk1]));
						rtb211=cadd(cmul(rdnr11[ip],rtb111),cmul(rdnr12[ip],
							rtb121));
						rtb212=cadd(cmul(rdnr11[ip],rtb112),cmul(rdnr12[ip],
							rtb122));
						rtb221=cadd(cmul(rdnr21[ip],rtb111),cmul(rdnr22[ip],
							rtb121));
						rtb222=cadd(cmul(rdnr21[ip],rtb112),cmul(rdnr22[ip],
							rtb122));
						rtb311=cadd(cmul(rusf11[ip],rd0n11[ip]),cmul(rusf12[ip],
							rd0n21[ip]));
						rtb312=cadd(cmul(rusf11[ip],rd0n12[ip]),cmul(rusf12[ip],
							rd0n22[ip]));
						rtb321=cadd(cmul(rusf21[ip],rd0n11[ip]),cmul(rusf22[ip],
							rd0n21[ip]));
						rtb322=cadd(cmul(rusf21[ip],rd0n12[ip]),cmul(rusf22[ip],
							rd0n22[ip]));
						x=csub(cmplx(1.0,0.0),rtb311);
						y=csub(cmplx(1.0,0.0),rtb322);
						det=csub(cmul(x,y),cmul(rtb312,rtb321));
						rvrb111=cdiv(y,det);
						rvrb112=cdiv(rtb312,det);
						rvrb121=cdiv(rtb321,det);
						rvrb122=cdiv(x,det);
						fact11=cadd(cmul(rusf11[ip],sigmau1[ip]),cadd(
							cmul(rusf12[ip],sigmau2[ip]),sigmad1[ip]));
						fact12=cadd(cmul(rusf21[ip],sigmau1[ip]),cadd(
							cmul(rusf22[ip],sigmau2[ip]),sigmad2[ip]));
						vdzs1=cadd(cmul(rvrb111,fact11),cmul(rvrb112,fact12));
						vdzs2=cadd(cmul(rvrb121,fact11),cmul(rvrb122,fact12));
						up[ip]=cmul(p[ip],cadd(cmul(cadd(rtb111,rtb211),vdzs1),
							cmul(cadd(rtb112,rtb212),vdzs2)));
					}
				}
				for (ix=0; ix<nx; ix++) {
					x1=bx+dx*ix;
					if (x1==0.0) {
						for (ip=1; ip<block_size-1; ip++) {
							t1=cdiv(cmplx(1.0,0.0),csqrt(p[ip]));
							vos1[ip]=cmul(up[ip],t1);
						}
						vos1[0]=cmplx(0.0,0.0);
						vos1[1]=crmul(vos1[1],0.5);
						vos1[block_size-2]=crmul(vos1[block_size-2],.5);
					} else {
						temr=crmul(wpie,2*PI*x1);
						temr=cdiv(tem,csqrt(temr));
						sig=crmul(divfac,x1);
						sigh=cmul(sig,cdp);
						for (ip=0; ip<block_size-1; ip++) {
							texp[ip]=cexp(cmul(sig,p[ip]));
						}

						/******************************************************
						*			Compute the slowness integral			  *
						******************************************************/
						if (int_type==1) {		/* use trapezoidal rule */
							temr=crmul(cmul(temr,cdp),0.5);
							for (ip=0; ip<block_size-1; ip++) {
								vos1[ip]=cmul(temr,cadd(cmul(up[ip],texp[ip]),
									cmul(up[jj],texp[jj])));
							}
						} else if (int_type==2) {
							for (ip=0; ip<block_size-1; ip++) {
								jj=ip+1;
								t1=csub(texp[jj],texp[ip]);
								func1=csub(cmul(up[jj],texp[jj]),
									cmul(up[ip],texp[ip]));
								func2=cmul(csub(up[jj],up[ip]),t1);
								vos1[ip]=cmul(cdiv(cdp,sigh),cmul(csub(func1,
									cdiv(func2,sigh)),temr));
							}
						}
					}
		/**********************************************************
	    *		update output array			*
	    **********************************************************/
				for (ip=0; ip<block_size-1; ip++) {
						response1[iw][ix][iz]=cadd(response1[iw][ix][iz],
							vos1[ip]);
					}
				}
			}

	/* update loop variables */
            nblock--;
	    if (nblock != 0) {

		bp=p[block_size].r;
		left++;
		if (left > block_size) {
		    left -=block_size;
		    nblock++;
		}

	    } else {
				if (int_type==1) bp=bp1;
				else if (int_type==2) bp=0.0;
				break;	/* last block, exit while loop */
			}
		}
	}
	
	/* free allocated space */
	free1complex(up);
	free1complex(rd0n11);free1complex(rd0n12);free1complex(rd0n21);
	free1complex(rd0n22);free1complex(td0n11);free1complex(td0n12);
	free1complex(td0n22);free1complex(tun011);free1complex(tun012);
	free1complex(tun021);free1complex(tun022);free1complex(run011);
	free1complex(run012);free1complex(run021);free1complex(run022);
	free1complex(tusf11);free1complex(tusf12);free1complex(tusf21);
	free1complex(tusf22);free1complex(rdfs11);free1complex(rdfs12);
	free1complex(rdfs21);free1complex(rdfs22);free1complex(rurf11);
	free1complex(rurf12);free1complex(rurf21);free1complex(rurf22);
	free1complex(turf11);free1complex(turf12);free1complex(turf21);
	free1complex(turf22);free1complex(rdfr11);free1complex(rdfr12);
	free1complex(rdfr21);free1complex(rdfr22);free1complex(tdfr11);
	free1complex(tdfr12);free1complex(tdfr21);free1complex(tdfr22);
	free1complex(r11);free1complex(r12);free1complex(r21);free1complex(r22);
	free1complex(vos1);free1complex(vos2);free1complex(vos3);

	/* free working space */
    free1complex(p);
    free1complex(pp);
    free1complex(pwin);
    free1complex(gl);
    free1complex(gt);
    free1complex(gam);
    free1complex(alpha);
    free1complex(betha);
    free1complex(sigmau1);
    free1complex(sigmau2);
    free1complex(sigmad1);
    free1complex(sigmad2);

}


/******************************Self-Documentation*****************************/
/******************************************************************************
SYNTHETICS - Subroutine to compute a synthetic seismogram from the output
				of the reflectivity modeling code

*******************************************************************************
Function Prototypes:
void compute_synthetics (int verbose, int nt, int ntc, int nx, int nor, int nw,
	int nlayers, int lsource, int nf, int flt, int vsp, int win, int wtype, 
	float tlag, float red_vel, float decay, float tsec, float bx, float dx, 
	float w1, float w2, int *fil_phase, int nfilters, int *fil_type, 
	float *dbpo, float *f1, float *f2, int *lobs, float *cl, float *t, 
	complex ***response, float **reflectivity, FILE *outfp);

void red_vel_factor (float x, float red_vel, float tlag, complex wpie, 
	complex wsq, complex *rvfac);

void construct_tx_trace (int nw, int nt, int ntfft, int nfilters,
	int *filters_phase, float tsec, float unexp, float sphrd, complex *refw,
	int *fil_type, float *f1, float *f2, float *dbpo, float *reft);

void compute_Hanning_window (int iwin, int iw, int if1, int if2, int nf, 
	complex *win);

void apply_filters (int *min_phase, int nfilters, int nw, float tsec, float *f1,
	float *f2, float *dbpo, int *filter_type, complex *refw);
*******************************************************************************
compute_synthetics:
Input:
nt			number of time samples in the computed synthetics
tlag		time lag in seconds to be used in computing the synthetics
nf			number of frequencies to be used in computing the synthetics.
			Set to zero if all frequencies are to be used
flt			=1 to apply the earth flattening correction
vsp			=1 to compute synthetic vsp
win			=1 ray parameter windows ???
wtype		=1 for displacement
			=2 for velocity
			=3 for acceleration
w1			frequency to start lo end hanning taper. If w1=0, deafult=0.15*nf
			frequency to start hi end hanning taper. If w2=0, deafult=0.85*nf
red_vel		reducing velocity in km/s. If set to zero, use the highest
			model velocity
nfilters	number of filters to be applied to the synthetics
fil_phase	=1 for minimum phase filters
			=0 for zero phase filters
fil_type	array[nfilters] of filter flags: =1 for high cut, =2 for low cut,
			=3 for notch filter
dbpo		array[nfilters] of slopes in db/octave
f1			frequency 1 in hertz
f2 			frequency 2 in hertz (only in the case of notch filter)
response	array[nw]nx][nor] of computed wavefield amplitudes 

Output:
reflectivity	array[nx][nt] of computed reflectivities	
*******************************************************************************
compute_red_vel_factor
Input:
x			range (offset) of current trace 
red_vel		reducing velocity
tlag		time lag to be applied to the seismogram
wpie
wsq			complex factor

Output
rvfac		computed reducing velocity factor
*******************************************************************************
construct_tx_trace:
Input:
nw			number of frequencies
nt			number of time samples
ix			trace index
nfilt		number of filters to be applied
tsec		length of computed trace
unexp		parameter to undo decay factor	
sphrd		flattening earth correction factor
refw		array[nw+1] of complex trace

Output:
reft		array[nt] current trace in t-x domain
*******************************************************************************
compute_Hanning_window:
Input:
iwin		=1 for Hanning window
if1			lower f=window frequency
if2			higher window frequency
nw			number of frequencies in output data
iw			current frequency

Output:
win			computed Hanning window for given frequency
*******************************************************************************
apply_filters:
Input:
min_phase		=1 for minimum phase filters
				=0 for zero phase filters
nfilters		number of filters to apply
nw				number of frequencies
tsec
f1				array[nfilters] of low frequencies
f2				array[nfilters] of high frequencies
dbpo			array[nfilters] of filter slopes in db/oct
filtype			array[nfilters] of filter types:
				=1 low cut filter
				=2 high cut filter
				=3 notch filter
refw			array[nw+1] of complex samples to filter

Output:
refw			array[nw+1] of complex filtered samples 

Note:
refw contains only the positive frequencies, the negatives are simply their
complex conjugates and can be computed when necessary
*******************************************************************************/
/***********************************End Self_documentation********************/




/******************************************************************************

	Subroutine to generate the synthetic seismograms based on the
		information contained in the files wxp,wxr and wxz

******************************************************************************/
void compute_synthetics (int verbose, int nt, int ntc, int nx, int nor, int nw,
	int nlayers, int lsource, int nf, int flt, int vsp, int win, int wtype, 
	float tlag, float red_vel, float decay, float tsec, float bx, float dx, 
	float w1, float w2, int *fil_phase, int nfilters, int *fil_type, 
	float *dbpo, float *f1, float *f2, int *lobs, float *cl, float *t, 
	complex ***response, float **reflectivity, FILE *outfp)
/****************************************************************************** 
Input:
nt			number of time samples in the computed synthetics
tlag		time lag in seconds to be used in computing the synthetics
nf			number of frequencies to be used in computing the synthetics.
			Set to zero if all frequencies are to be used
flt			=1 to apply the earth flattening correction
vsp			=1 to compute synthetic vsp
win			=1 ray parameter windows ???
wtype		=1 for displacement
			=2 for velocity
			=3 for acceleration
w1			frequency to start lo end hanning taper. If w1=0, deafult=0.15*nf
			frequency to start hi end hanning taper. If w2=0, deafult=0.85*nf
red_vel		reducing velocity in km/s. If set to zero, use the highest
			model velocity
nfilters	number of filters to be applied to the synthetics
fil_phase	=1 for minimum phase filters
			=0 for zero phase filters
fil_type	array[nfilters] of filter flags: =1 for high cut, =2 for low cut,
			=3 for notch filter
dbpo			array[nfilters] of slopes in db/octave
f1			frequency 1 in hertz
f2 			frequency 2 in hertz (only in the case of notch filter)
response	array[nw]nx][nor] of computed wavefield amplitudes 

Output:
reflectivity	array[nx][nt] of computed reflectivities	
******************************************************************************/
{	
	int il,iw,ix,iz=0;	/* loop counters */
	int kz;			/* auxiliary index */
	int ntfft;		/* number of FFT samples */
	int nw1;		/* number of frequencies for FFT */
	float sum=0.0;		/* auxiliary variable */
	float *zr,zs;		/* depths of source and receivers */
	float sphrd=1.0;	/* factor for flattening earth correction */
	int if1=0,if2=0; 	/* freq indices to start and end Hanning window */
	float unexp;		/* parameter to undo decay factor */
	float x,z;		/* range and depth */
	float w;		/* frequency in rad/sec */
	complex wpie;		/* complex frequency */
	complex wsq;		/* complex frequency squared */
	complex rvfac;		/* reducing velocity factor */
	complex *refw;		/* scratch array for complex wavefield */
	complex window;		/* frequency domain Hanning window */

	/* if requested, check input parameters */
	if (verbose==1||verbose==3) {
		fprintf (stderr,"in compute reflectivity series, checking input ...\n");
		fprintf (stderr,"nt=%d nx=%d nor=%d nw=%d",nt,nx,nor,nw);
		fprintf (stderr," nlayers=%d lsource=%d nf=%d\n",nlayers,lsource,nf);
		fprintf (stderr,"flt=%d vsp=%d win=%d wtype=%d\n",flt,vsp,win,wtype);
		fprintf (stderr,"tlag=%g red_vel=%g decay=%g ",tlag,red_vel,decay);
		fprintf (stderr,"tsec=%g bx=%g dx=%g w1=%g w2=%g\n",tsec,bx,dx,w1,w2);
		fprintf (stderr,"nfilters=%d\n",nfilters);
	}
	if (verbose==2||verbose==3) {
		fprintf (outfp,"in compute reflectivity series, checking input ...\n");
		fprintf (outfp,"nt=%d nx=%d nor=%d nw=%d",nt,nx,nor,nw);
		fprintf (outfp," nlayers=%d lsource=%d nf=%d\n",nlayers,lsource,nf);
		fprintf (outfp,"flt=%d vsp=%d win=%d wtype=%d\n",flt,vsp,win,wtype);
		fprintf (outfp,"tlag=%g red_vel=%g decay=%g ",tlag,red_vel,decay);
		fprintf (outfp,"tsec=%g bx=%g dx=%g w1=%g w2=%g\n",tsec,bx,dx,w1,w2);
		fprintf (outfp,"nfilters=%d\n",nfilters);
	}

	/* compute number of fft samples and frequencies */
	ntfft=npfa(ntc);
	nw1=ntfft/2;
	if (nf>0 && nf<=nw) nw=nf;
	fprintf (stderr,"\n\n nt=%d ntfft=%d nw=%d nw1=%d\n",nt,ntfft,nw,nw1);

	/* allocate working space */
	zr=alloc1float(nor);
	refw=alloc1complex(ntfft);

	/* if not provided, set reducing velocity to highest pwave velocity */
	if (red_vel<0.0) {
		red_vel=1.51;	
		for (il=0; il<nlayers; il++) {
			if (cl[il]>red_vel) red_vel=cl[il];
		}
	}

	/* compute depths of source and receivers */
	iz=0;
	for (il=0; il<nlayers-1; il++) {
		kz=il+1;
		sum +=t[il];
		if (kz==lsource-1) zs=sum;	/* depth of the source */
		if ((iz<nor)&&(kz==lobs[iz]-1)) {
			zr[iz]=sum;		/* depth of the receivers */
			iz++;
		}
	}

	/* if requested, output processing information */
	if (verbose==1||verbose==3) {
		fprintf(stderr,"\nSOURCE AND RECEIVER INFORMATION\n");
		fprintf(stderr,"\nReducing velocity=%g source depth=%g\n",red_vel,zs);
		fprintf(stderr,"\nReceiver Number  Depth   \n");
		for (iz=0; iz<nor; iz++) {
			fprintf (stderr,"%8d%15.3f\n",iz,zr[iz]);
		}
	}
	if (verbose==2||verbose==3) {
		fprintf(outfp,"\nSOURCE AND RECEIVER INFORMATION\n");
		fprintf(outfp,"\nReducing velocity=%g source depth=%g\n",red_vel,zs);
		fprintf(outfp,"\nReceiver Number  Depth   \n");
		for (iz=0; iz<nor; iz++) {
			fprintf (outfp,"%8d%15.3f\n",iz,zr[iz]);
		}
	}
	
	/* compute windowed frequencies */
	if (win==1) {
		if (w1==0) if1=0.15*nf;
		else  if1=w1*tsec;
		if (w2==0) if2=0.85*nf;
		else if2=w2*tsec;
	}
	unexp=decay*tsec;					/* to undo exponential decay */

	/* main loop to compute a vsp or a seismogram */
	if (vsp==1) {
		for (ix=0; ix<nx; ix++) {

			/* compute range and flattening correction factor */
			x=bx+dx*ix;
			if (flt==1) sphrd=sqrt((x/RSO)/ABS(sin(x/RSO)));

			/* loop over the receivers */
			for (iz=0; iz<nor; iz++) {
				z=zr[iz];

				/* loop over frequencies */
				for (iw=0; iw<nw1; iw++) {

					/* initialize output array */
					if (iw<nw) {
						w=(iw+1)*PI*2/tsec;
						refw[iw+1]=response[iw][ix][iz];
					} else {
						w=0.0;
						refw[iw+1]=cmplx(0.0,0.0);
					}

					/* compute complex frequencies */
					wpie=cmplx(w,decay);
					wsq=cneg(cmul(cmplx(0.0,1.0),wpie));

					/* compute reducing velocity factor */
					red_vel_factor (x, red_vel, tlag, wpie,wsq, &rvfac);

					/* compute Hanning window */
					compute_Hanning_window (win, iw, if1, if2, nw, &window);

					/* apply Hanning window */
					refw[iw+1]=cmul(refw[iw+1],cmul(rvfac,window));
				}
			
				/* construct time image */
				construct_tx_trace (nw1, nt, ntc, ntfft, nfilters, fil_phase,
					tsec, unexp, sphrd, refw, fil_type, f1, f2, dbpo,
					reflectivity[ix]);
			}
		}

	} else {		/* compute "normal" seismogram */

		/* loop over recievers */	
		for (iz=0; iz<nor; iz++) {
			z=zr[iz];

			/* loop over ranges (seismogram traces) */
			for (ix=0; ix<nx; ix++) {
				x=bx+dx*ix;

				/* if earth flattening correction requested */
				if (flt==1) sphrd=sqrt((x/RSO)/ABS(sin(x/RSO)));
				
				/* loop over frequencies */
				for (iw=0; iw<nw1; iw++) {

					/* initialize output array */
					if (iw<nw) {
						w=(iw+1)*PI*2/tsec;
						refw[iw+1]=response[iw][ix][iz];
					} else {
						w=0.0;
						refw[iw+1]=cmplx(0.0,0.0);
					}

					/* compute complex frequencies */
					wpie=cmplx(w,decay);
					wsq=cmul(cmplx(0.0,1.0),wpie);
					wsq=cipow(wsq,wtype);

					/* compute reducing velocity factor */
					red_vel_factor (x, red_vel, tlag, wpie, wsq, &rvfac);

					/* compute Hanning window */
					compute_Hanning_window (win, iw, if1, if2, nw, &window);

					/* apply Hanning window and rvfac */
					refw[iw+1]=cmul(refw[iw+1],cmul(rvfac,window));
				}

				/* construct time image */
				construct_tx_trace (nw1, nt, ntc, ntfft,nfilters, fil_phase,
					tsec, unexp, sphrd, refw, fil_type, f1, f2, dbpo,
					reflectivity[ix]);
			}
		}
	}

	/* free working space */
	free1float(zr);
	free1complex(refw);
}
		
/******************************************************************************

			Subroutine to compute the reducing velocity factor

******************************************************************************/
void red_vel_factor (float x, float red_vel, float tlag, complex wpie, 
	complex wsq, complex *rvfac)
/******************************************************************************
Input:
x			range (offset) of current trace 
red_vel		reducing velocity
tlag		time lag to be applied to the seismogram
wpie
wsq			complex factor

Output
rvfac		computed reducing velocity factor
******************************************************************************/
{

	/* compute reducing velocity factor */
	if (red_vel==0.) {
		*rvfac=crmul(cmul(cmplx(0.0,1.0),wpie),tlag);
	} else {
		*rvfac=crmul(cmul(cmplx(0.0,1.0),wpie),tlag-x/red_vel);
	}

	/* multiply by complex factor */
	*rvfac=cmul(cexp1(*rvfac),wsq);
}


/******************************************************************************	

			Subroutine to construct the trace in t-x domain

******************************************************************************/
void construct_tx_trace (int nw, int nt, int ntc, int ntfft, int nfilters,
	int *filters_phase, float tsec, float unexp, float sphrd, complex *refw,
	int *fil_type, float *f1, float *f2, float *dbpo, float *reft)
/******************************************************************************
Input:
nw				number of frequencies
nt				number of time samples
ix				trace index
nfilt			number of filters to be applied
tsec
unexp
sphrd			flattening earth correction factor
refw			array[nw+1] of complex trace

Output:
reft			array[nt] current trace in t-x domain
******************************************************************************/
{
	int it;			/* loop counter */
	float a,b,c;		/* auxiliary variables */
	
	/* if requested, apply filters */
	if (nfilters !=0)  {
		apply_filters (filters_phase, nfilters, nw, tsec, f1, f2, dbpo, 
			fil_type, refw);
	}

	/* inverse fft to transfer data to t-x domain */
	pfacc (-1, ntfft, refw);
	

	/* construct the t-x image */
	for (it=0; it<nt; it++) {
		a=(float)it/ntc;
		b=unexp*a;
		c=exp(b);
		reft[it]=refw[it].r*c*sphrd;
	}

	/* reinitialize working arrays */
	for (it=0; it<ntfft; it++) {
		refw[it]=cmplx(0.0,0.0);
	}
}
					
					
/******************************************************************************

				Subroutine to compute a Hanning window

******************************************************************************/
void compute_Hanning_window (int iwin, int iw, int if1, int if2, int nf, 
	complex *win)
/******************************************************************************
Input:
iwin		=1 for Hanning window
if1			lower f=window frequency
if2			higher window frequency
nw			number of frequencies in output data
iw			current frequency

Output:
win			computed Hanning window for given frequency
******************************************************************************/
{

	/* compute Hanning window */
	if (iwin==1) {
		if (iw<if1-1) {
			*win=crmul(cmplx(1.0,0.0),0.5*(1.+cos(PI*(if1-iw+1)/if1)));
		} else if((iw>=if1-1)&&(iw<=if2-1)) {
			*win=cmplx(1.0,0.0);
		} else if((iw>if2-1)&&(iw<nf-1)) {
			*win=crmul(cmplx(1.0,0.0),0.5*(1.+cos(PI*(iw-if2+1)/(nf-if2))));
		} else {
			*win=cmplx(0.0,0.0);
		}
	} else {
		if (iw<nf-1) {
			*win=crmul(cmplx(1.0,0.0),0.5*(1.+cos(PI*(iw+1)/nf)));
		} else {
			*win=cmplx(0.0,0.0);
		}
	}
}
			
/******************************************************************************

		Subroutine to apply hi-cut, lo-cut or notch zero or minimum
							phase filters

******************************************************************************/
void apply_filters (int *min_phase, int nfilters, int nw, float tsec, float *f1,
	float *f2, float *dbpo, int *filter_type, complex *refw)
/******************************************************************************
Input:
min_phase		=1 for minimum phase filters
				=0 for zero phase filters
nfilters		number of filters to apply
nw				number of frequencies
tsec
f1				array[nfilters] of low frequencies
f2				array[nfilters] of high frequencies
dbpo				array[nfilters] of filter slopes in db/oct
filtype			array[nfilters] of filter types:
				=1 low cut filter
				=2 high cut filter
				=3 notch filter
refw			array[nw+1] of complex samples to filter

Output:
refw			array[nw+1] of complex filtered samples 
*******************************************************************************
Note:
refw contains only the positive frequencies, the negatives are simply their
complex conjugates and can be computed when necessary
******************************************************************************/
{
	int i,j,iw;			/* loop counters */
	int nw1=nw+1;		/* number of frequencies (positive+zero) */
	int nwt=2*nw;		/* total number of frequencies */
	int index1,index2;	/* auxiliary indices for notch filter */
	float delfq=0.0;
	float poles;		/* filter poles */
	float r,factor;		/* auxiliary variables */
	float maxabs;
	complex *filter;	/* scratch array for filter coefficients */
	complex *filter1;	/* scratch array for filter coefficients */


	/* defensive programming */
	if (nfilters==0) return;

	/* allocate working space */
	filter=alloc1complex(2*nwt);
	filter1=alloc1complex(2*nwt);

	/* initialize filter array */
	for (iw=0; iw<nw1; iw++) filter[iw]=cmplx(1.0,0.0);

	/* main loop over number of requested filters */
	for (i=0; i<nfilters; i++) {
		
		/* smearing range */
		if (min_phase[i]==1) delfq=2*PI/tsec;

		if (filter_type[i]==1) { 	/* if low-pass Butterworth */
			poles=dbpo[i]/6.+1;
			r=1./((f1[i]-delfq)*tsec);

			/* compute filter coefficients */
			for (iw=0; iw<nw1; iw++) {
				factor=1.0/sqrt(1.+pow(iw*r,poles));
				filter[iw]=crmul(filter[iw],factor);
			}

		} else if (filter_type[i]==2) {	/* hi-pass Butterworth */
			poles=dbpo[i]/6.+1;
			r=1./((f1[i]+delfq)*tsec);

			/* compute filter coefficients */
			for (iw=0; iw<nw1; iw++) {
				factor=pow(iw*r,poles);	
				filter[iw]=crmul(filter[iw],sqrt(factor/(1+factor)));
			}

		} else if (filter_type[i]==3) { /* notch filter */
			index1=(f1[i]-delfq)*tsec+1;
			index2=(f2[i]+delfq)*tsec+2;

			if ((index2-index1)<16) {
				warn("in notch filter %d f1 too close to f2, "
				"this filter skiped\n",i);
				continue;
			}

			/* db reduction Neils design */
			r=1.0-pow(10.0,-dbpo[i]/20.);
			for (j=index1; j<=index2; j++) {
				factor=cos(2*PI*(j-index1)/(index2-index1))-1;
				filter[j-1]=crmul(filter[j-1],(1+r*factor)/2.);
			}
		} else {
				warn("unknown filter type for filter number %d,"
				" this filter skiped\n",i);
		}

		/* apply minimum phase correction */
		if (min_phase[i]==1) {
			for (iw=0; iw<nw1; iw++) {
				if (filter[iw].r==0.0) {
					filter[iw]=cmplx(-30.0,0.0);
				} else {

					/* set A[w]=ln(f[w]) */
					filter[iw]=cmplx(log(filter[iw].r),0.0);
				}
			}


			/* take care of negative frequencies needed for FFT */
			for (iw=nw1; iw<nwt; iw++) {
				filter[iw]=conjg(filter[nwt-iw+1]);
			}

			/* take inverse FFT to go to time domain */
			pfacc (-1, nwt, filter);

			for (iw=1; iw<nw1; iw++) {
				r=(1.+cos(PI*iw/nw))/2.;	
				filter[iw]=crmul(filter[iw],r);
				filter[nwt-iw+1]=crmul(filter[nwt-iw+1],r);
			}

			/* construct filter coefficients for all frequencies */
			for (iw=0; iw<nw1; iw++) {
				filter1[iw]=filter[iw];
			}
			for (iw=nw1; iw<nwt; iw++) {
				filter1[iw]=cneg(conjg(filter[iw]));
			}

			/* take forward FFT to get back to frequency domain */
			pfacc (1, nwt, filter);
			pfacc (1, nwt, filter1);
	
			maxabs=0.0;
			for (iw=0; iw<nw1; iw++) {
				filter[iw]=cexp1(cadd(filter[iw],filter1[iw]));
				maxabs=MAX(rcabs(filter[iw]),maxabs);
			}
	
			/* normalize */
			maxabs=1.0/maxabs;
			for (iw=0; iw<nw1; iw++) {
				filter[iw]=crmul(filter[iw],maxabs);
			}
		}
	}

	/* apply the filter */
	for (iw=0; iw<nw1; iw++) {
		refw[iw]=cmul(refw[iw],filter[iw]);
	}
	for (iw=nw1; iw<nwt; iw++) {
		refw[iw]=conjg(refw[nwt-iw]);
	}

	/* free allocated space */
	free1complex(filter);
	free1complex(filter1);
}
