/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SUSYNVXZ: $Revision: 1.16 $ ; $Date: 1996/09/13 21:49:05 $	*/

#include "su.h" 
#include "segy.h" 

/*********************** self documentation **********************/
char *sdoc[] = {
" 									",
" SUSYNVXZ - SYNthetic seismograms of common offset V(X,Z) media via	",
" 		Kirchhoff-style modeling				",
" 									",
" susynvxz >outfile [optional parameters]				",
" 									",
" Required Parameters:							",
" <vfile		file containing velocities v[nx][nz]		",
" nx=			number of x samples (2nd dimension)		",
" nz=			number of z samples (1st dimension)		",
" Optional Parameters:							",
" nxb=nx		band centered at midpoint			",
" nxd=1			skipped number of midponits			",
" dx=100		x sampling interval (m)				",
" fx=0.0		first x sample					",
" dz=100		z sampling interval (m)				",
" nt=101		number of time samples				",
" dt=0.04		time sampling interval (sec)			",
" ft=0.0		first time (sec)				",
" nxo=1		 	number of offsets				",
" dxo=50		offset sampling interval (m)			",
" fxo=0.0		first offset (m)				",
" nxm=101		number of midpoints				",
" dxm=50		midpoint sampling interval (m)			",
" fxm=0.0		first midpoint (m)				",
" fpeak=0.2/dt		peak frequency of symmetric Ricker wavelet (Hz)	",
" ref=\"1:1,2;4,2\"	reflector(s):  \"amplitude:x1,z1;x2,z2;x3,z3;...\"",
" smooth=0		=1 for smooth (piecewise cubic spline) reflectors",
" ls=0			=1 for line source; default is point source	",
" tmin=10.0*dt		minimum time of interest (sec)			",
" ndpfz=5		number of diffractors per Fresnel zone		",
" verbose=0		=1 to print some useful information		",
" 									",
" Notes:								",
" This algorithm is based on formula (58) in Geo. Pros. 34, 686-703,	",
" by N. Bleistein.							",
" 									",
" Offsets are signed - may be positive or negative.			", 
" Traveltime and amplitude are calculated by finite differences which	",
" is done only in part of midpoints; in the skiped midpoint, interpolation",
" is used to calculate traveltime and amplitude.			", 
"									",
" More than one ref (reflector) may be specified.			",
" Note that reflectors are encoded as quoted strings, with an optional	",
" reflector amplitude: preceding the x,z coordinates of each reflector.	",
" Default amplitude is 1.0 if amplitude: part of the string is omitted.	",
"									",
NULL};

/*
 *   CWP:  Zhenyue Liu, 07/20/92
 *	Many subroutines borrowed from Dave Hale's program: SUSYNLV
 *
 * Trace header fields set: trid, counit, ns, dt, delrt,
 *				tracl. tracr,
 *				cdp, cdpt, d2, f2, offset, sx, gx
 */
/**************** end self doc ***********************************/

/* these structures are defined in par.h -- this is documentation only
 *
 * typedef struct ReflectorSegmentStruct {
 *	float x;	( x coordinate of segment midpoint )
 *	float z;	( z coordinate of segment midpoint )
 *	float s;	( x component of unit-normal-vector )
 *	float c;	( z component of unit-normal-vector )
 * } ReflectorSegment;
 * typedef struct ReflectorStruct {
 *	int ns;			( number of reflector segments )
 *	float ds;		( segment length )
 *	float a;		( amplitude of reflector )
 *	ReflectorSegment *rs;	( array[ns] of reflector segments )
 * } Reflector;
 * typedef struct WaveletStruct {
 *	int lw;			( length of wavelet )
 *	int iw;			( index of first wavelet sample )
 *	float *wv;		( wavelet sample values )
 * } Wavelet;
 *
 */

/* parameters for half-derivative filter */
#define LHD 20
#define NHD 1+2*LHD

/* prototypes */
static void makeone (float **ts, float **as, float **sgs, float **tg, 
	float **ag, float **sgg, float ex, float ez, float dx,  
	float dz, float fx, float vs0, float vg0, int ls, Wavelet *w,
	int nr, Reflector *r, int nt, float dt, float ft, float *trace);
static void eikpex (int na, float da, float r, float dr, 
	float sc[], float uc[], float wc[], float tc[],
	float sn[], float un[], float wn[], float tn[]);
static void sigma (int na, float da, float r, float dr, 
	float uc[], float wc[], float sc[],
	float un[], float wn[], float sn[]);
static void beta (int na, float da, float r, float dr, 
	float uc[], float wc[], float bc[],
	float un[], float wn[], float bn[]);
static void tripp (int n, float *d, float *e, float *c, float *b);
static void eiktam (float xs, float zs, 
	int nz, float dz, float fz, int nx, float dx, float fx, float **vel,
	float **time, float **angle, float **sig, float **beta);


/* segy trace */
segy tr;

int
main (int argc, char **argv)
{
	int 	nr,ir,ls,smooth,ndpfz,ns,ixo,ixm,nxo,nxm,nt,
		nx,nz,nxb,nxd,ixd,i,ix,iz,nx1,nx0,nxd1,
		verbose,tracl,
		*nxz;
	float   tmin,temp,temp1,
		dsmax,fpeak,dx,dz,fx,ex,fx1,ex1,
		dxm,dxo,dt,fxm,fxo,ft,xo,xm,vs0,vg0,
		xs,xg,ez,
		*ar,**xr,**zr,
		**vold,**ts,**as,**sgs,**tg,**ag,**sgg,**bas,**bag,
		**v,**ts1=NULL,**as1=NULL,**sgs1=NULL,
		**tg1=NULL,**ag1=NULL,**sgg1=NULL;
	FILE *vfp=stdin;
	Reflector *r;
	Wavelet *w;

	/* hook up getpar to handle the parameters */
	initargs(argc,argv);
	requestdoc(0);

	/* get required parameters */
	if (!getparint("nx",&nx)) err("must specify nx!\n");
	if (!getparint("nz",&nz)) err("must specify nz!\n");
	
	/* get optional parameters */
	if (!getparint("nxb",&nxb)) nxb = nx;
	if (!getparint("nxd",&nxd)) nxd = 1;
	if (!getparfloat("dx",&dx)) dx = 100;
	if (!getparfloat("fx",&fx)) fx = 0.0;
	if (!getparfloat("dz",&dz)) dz = 100;
	if (!getparint("nt",&nt)) nt = 101; CHECK_NT("nt",nt);
	if (!getparfloat("dt",&dt)) dt = 0.04;
	if (!getparfloat("ft",&ft)) ft = 0.0;
	if (!getparint("nxo",&nxo)) nxo = 1;
	if (!getparfloat("dxo",&dxo)) dxo = 50;
	if (!getparfloat("fxo",&fxo)) fxo = 0.0;
	if (!getparint("nxm",&nxm)) nxm = 101;
	if (!getparfloat("dxm",&dxm)) dxm = 50;
	if (!getparfloat("fxm",&fxm)) fxm = 0.0;
	if (!getparfloat("fpeak",&fpeak)) fpeak = 0.2/dt;
	if (!getparint("ls",&ls)) ls = 0;
	if (!getparfloat("tmin",&tmin)) tmin = 10.0*dt;
	if (!getparint("ndpfz",&ndpfz)) ndpfz = 5;
	if (!getparint("smooth",&smooth)) smooth = 0;
	if (!getparint("verbose",&verbose)) verbose = 0;
	
	/* check the ranges of shots and receivers */
	ex = fx+(nx-1)*dx;
	ez = (nz-1)*dz;
 	for (ixm=0; ixm<nxm; ++ixm) 
		for (ixo=0; ixo<nxo; ++ixo) {
			/* compute source and receiver coordinates */
			xs = fxm+ixm*dxm-0.5*(fxo+ixo*dxo);
			xg = xs+fxo+ixo*dxo;
			if (fx>xs || ex<xs || fx>xg || ex<xg) 
		err("shot or receiver lie outside of specified (x,z) grid\n");
	} 
		
	
	decodeReflectors(&nr,&ar,&nxz,&xr,&zr);
	if (!smooth) breakReflectors(&nr,&ar,&nxz,&xr,&zr);

	/* allocate space */
	vold = ealloc2float(nz,nx);
	/* read velocities */
	if(fread(vold[0],sizeof(float),nx*nz,vfp)!=nx*nz)
		err("cannot read %d velocities from file %s",nx*nz,vfp);
	/* determine maximum reflector segment length */
	tmin = MAX(tmin,MAX(ft,dt));
	dsmax = vold[0][0]/(2*ndpfz)*sqrt(tmin/fpeak);
 	
	/* make reflectors */
	makeref(dsmax,nr,ar,nxz,xr,zr,&r);

	/* count reflector segments */
	for (ir=0,ns=0; ir<nr; ++ir)
		ns += r[ir].ns;

	/* make wavelet */
	makericker(fpeak,dt,&w);
	
	/* if requested, print information */
	if (verbose) {
		warn("\nSUSYNVXZ:");
		warn("Total number of small reflecting segments is %d.\n",ns);
	}
	
	/* set constant segy trace header parameters */
	memset( (void *) &tr, (int) '\0', sizeof(tr));
	tr.trid = 1;
	tr.counit = 1;
	tr.ns = nt;
	tr.dt = 1.0e6*dt;
	tr.delrt = 1.0e3*ft;
	
	/* allocate space */
	nx1 = 1+2*nxb;
	ts = ealloc2float(nz,nx1);
	as = ealloc2float(nz,nx1);
	sgs = ealloc2float(nz,nx1);
	tg = ealloc2float(nz,nx1);
	ag = ealloc2float(nz,nx1);
	sgg = ealloc2float(nz,nx1);
	v = ealloc2float(nz,nx1);
	bas = ealloc2float(nz,nx1);
	bag = ealloc2float(nz,nx1);
	if(nxd>1) {
		/* allocate space for interpolation */
		ts1 = ealloc2float(nz,nx1);
		as1 = ealloc2float(nz,nx1);
		sgs1 = ealloc2float(nz,nx1);
		tg1 = ealloc2float(nz,nx1);
		ag1 = ealloc2float(nz,nx1);
		sgg1 = ealloc2float(nz,nx1);
  	}
		

	/* loop over offsets and midpoints */
	for (ixo=0, tracl=0; ixo<nxo; ++ixo){
	    xo = fxo+ixo*dxo;
	    if(ABS(xo)>nxb*dx) err("\t band NXB is too small!\n");
	    nxd1 = nxd;
	    for (ixm=0; ixm<nxm; ixm +=nxd1){
		xm = fxm+ixm*dxm;
   		xs = xm-0.5*xo;
		xg = xs+xo;
		/* set range for traveltimes' calculation */
		fx1 = xm-nxb*dx;
		ex1 = MIN(ex+(nxd1-1)*dxm,xm+nxb*dx);
		nx1 = 1+(ex1-fx1)/dx;	
		nx0 = (fx1-fx)/dx;
		temp = (fx1-fx)/dx-nx0;
		/* transpose velocity such that the first row is at fx1 */
		for(ix=0;ix<nx1;++ix)
		    for(iz=0;iz<nz;++iz){
		    	if(ix<-nx0) 
			   	v[ix][iz] = vold[0][iz];
		    	else if(ix+nx0>nx-2) 
				v[ix][iz]=vold[nx-1][iz];
			else
				v[ix][iz] = vold[ix+nx0][iz]*(1.0-temp)
					+temp*vold[ix+nx0+1][iz];
		    }
			
		if(ixm==0 || nxd1==1){
		/* No interpolation */
	
			/* compute traveltimes, propagation angles, sigmas 
	  		 from shot and receiver respectively	*/
			eiktam(xs,0.,nz,dz,0.,nx1,dx,fx1,v,ts,as,sgs,bas);
			eiktam(xg,0.,nz,dz,0.,nx1,dx,fx1,v,tg,ag,sgg,bag);
			ixd = NINT((xs-fx)/dx);
			vs0 = vold[ixd][0];
			ixd = NINT((xg-fx)/dx);
			vg0 = vold[ixd][0];
				
			/* make one trace */
			ex1 = MIN(ex,xm+nxb*dx);
			makeone(ts,as,sgs,tg,ag,sgg,ex1,ez,dx,dz,fx1,vs0,vg0,
				ls,w,nr,r,nt,dt,ft,tr.data);
			/* set segy trace header parameters */
			tr.tracl = tr.tracr = ++tracl;
			tr.cdp = 1+ixm;
			tr.cdpt = 1+ixo;
			tr.offset = NINT(xo);
			tr.sx = NINT(xs);
			tr.gx = NINT(xg);
			/* write trace */
			puttr(&tr);
		}
		else {
			/* Linear interpolation */
			
			eiktam(xs,0,nz,dz,0,nx1,dx,fx1,v,ts1,as1,sgs1,bas);
			eiktam(xg,0,nz,dz,0,nx1,dx,fx1,v,tg1,ag1,sgg1,bag);
			ixd = NINT((xs-fx)/dx);
			vs0 = vold[ixd][0];
			ixd = NINT((xg-fx)/dx);
			vg0 = vold[ixd][0];
			
		    	xm -= nxd1*dxm;
		    for(i=1; i<=nxd1; ++i) {
		    	xm += dxm;
			xs = xm-0.5*xo;
			xg = xs+xo;
			fx1 = xm-nxb*dx;	
			ex1 = MIN(ex+(nxd1-1)*dxm,xm+nxb*dx);
			nx1 = 1+(ex1-fx1)/dx;	
			temp = nxd1-i;
			temp1 = 1.0/(nxd1-i+1);
			for(ix=0;ix<nx1;++ix)
			    for(iz=0;iz<nz;++iz){
			    if(i==nxd1){
			   	ts[ix][iz] = ts1[ix][iz];
			   	tg[ix][iz] = tg1[ix][iz];
			   	sgs[ix][iz] = sgs1[ix][iz];
			   	ag[ix][iz] = ag1[ix][iz];
			   	sgg[ix][iz] = sgg1[ix][iz];
			   	as[ix][iz] = as1[ix][iz];
				}
			    else{
			   	ts[ix][iz] = (temp*ts[ix][iz]
					+ts1[ix][iz])*temp1;
			   	tg[ix][iz] = (temp*tg[ix][iz]
					+tg1[ix][iz])*temp1;
			    	as[ix][iz] = (temp*as[ix][iz]
					+as1[ix][iz])*temp1;
			   	sgs[ix][iz] = (temp*sgs[ix][iz]
					+sgs1[ix][iz])*temp1;
			   	ag[ix][iz] = (temp*ag[ix][iz]
					+ag1[ix][iz])*temp1;
			   	sgg[ix][iz] = (temp*sgg[ix][iz]
					+sgg1[ix][iz])*temp1;
				}
			}
				
			/* make one trace */
			ex1 = MIN(ex,xm+nxb*dx);
			makeone(ts,as,sgs,tg,ag,sgg,ex1,ez,dx,dz,fx1,vs0,vg0,
				ls,w,nr,r,nt,dt,ft,tr.data);
			/* set segy trace header parameters */
			tr.tracl = tr.tracr = ++tracl;
			tr.cdp = 1+ixm-nxd1+i;
			tr.cdpt = 1+ixo;
			tr.offset = NINT(xo);
			tr.d2=dxm;
			tr.f2=fxm;
			tr.sx = NINT(xs);
			tr.gx = NINT(xg);
			/* write trace */
			puttr(&tr);
		    }
		}
		    /* set skip parameter */
		    if(ixm<nxm-1 && ixm>nxm-1-nxd1) nxd1 = nxm-1-ixm;

	    }
	    warn("\t finish offset %f\n",xo);
	}

	free2float(vold);
	free2float(ts);
	free2float(bas);
	free2float(sgs);
	free2float(as);
	free2float(v);
	free2float(tg);
	free2float(bag);
	free2float(sgg);
	free2float(ag);
	if(nxd>1) {
		free2float(ts1);
		free2float(as1);
		free2float(sgs1);
		free2float(tg1);
		free2float(ag1);
		free2float(sgg1);
  	}
	return EXIT_SUCCESS;
}

static void makeone (float **ts, float **as, float **sgs, 
	float **tg, float **ag, float **sgg, float ex, float ez, float dx, 
	float dz, float fx, float vs0, float vg0, int ls, Wavelet *w,
	int nr, Reflector *r, int nt, float dt, float ft, float *trace)
/*****************************************************************************
Make one synthetic seismogram 
******************************************************************************
Input:
**v		array[nx][nz] containing velocities 
nz		number of z samples
dz		z sampling interval
nx		number of x samples
dx		x sampling interval
fx		first x sample
ls		=1 for line source amplitudes; =0 for point source
w		wavelet to convolve with trace
xs		x coordinate of source
xg		x coordinate of receiver group
nr		number of reflectors
r		array[nr] of reflectors
nt		number of time samples
dt		time sampling interval
ft		first time sample

Output:
trace		array[nt] containing synthetic seismogram
*****************************************************************************/
{
	int it,ir,is,ns,ix,iz;
	float ar,ds,xd,zd,cd,sd,xi,zi,ci,cr,time,amp,sx,sz,
		tsd,asd,sgsd,tgd,agd,sggd,
		*temp;
	ReflectorSegment *rs;
	int lhd=LHD,nhd=NHD;
	static float hd[NHD];
	static int madehd=0;

	/* if half-derivative filter not yet made, make it */
	if (!madehd) {
		mkhdiff(dt,lhd,hd);
		madehd = 1;
	}
 
	/* zero trace */
	for (it=0; it<nt; ++it)
		trace[it] = 0.0;
	
	/* loop over reflectors */
	for (ir=0; ir<nr; ++ir) {

		/* amplitude, number of segments, segment length */
		ar = r[ir].a;
		ns = r[ir].ns;
		ds = r[ir].ds;
		rs = r[ir].rs;
	
		/* loop over diffracting segments */
		for (is=0; is<ns; ++is) {
		
			/* diffractor midpoint, unit-normal, and length */
			xd = rs[is].x;
			zd = rs[is].z;
			cd = rs[is].c;
			sd = rs[is].s;
			
			/* check range of reflector */
			if(xd<fx || xd>=ex || zd>=ez)
				continue;
			/* determine sample indices */
			xi = (xd-fx)/dx;
			ix = xi;
			zi = zd/dz;
			iz = zi;
			/* bilinear interpolation */
			sx = xi-ix;
			sz = zi-iz;
			tsd = (1.0-sz)*((1.0-sx)*ts[ix][iz] + 
						sx*ts[ix+1][iz]) +
					sz*((1.0-sx)*ts[ix][iz+1] +
						sx*ts[ix+1][iz+1]);
			asd = (1.0-sz)*((1.0-sx)*as[ix][iz] + 
						sx*as[ix+1][iz]) +
					sz*((1.0-sx)*as[ix][iz+1] +
						sx*as[ix+1][iz+1]);
			sgsd = (1.0-sz)*((1.0-sx)*sgs[ix][iz] + 
						sx*sgs[ix+1][iz]) +
					sz*((1.0-sx)*sgs[ix][iz+1] +
						sx*sgs[ix+1][iz+1]);
			tgd = (1.0-sz)*((1.0-sx)*tg[ix][iz] + 
						sx*tg[ix+1][iz]) +
					sz*((1.0-sx)*tg[ix][iz+1] +
						sx*tg[ix+1][iz+1]);
			agd = (1.0-sz)*((1.0-sx)*ag[ix][iz] + 
						sx*ag[ix+1][iz]) +
					sz*((1.0-sx)*ag[ix][iz+1] +
						sx*ag[ix+1][iz+1]);
			sggd = (1.0-sz)*((1.0-sx)*sgg[ix][iz] + 
						sx*sgg[ix+1][iz]) +
					sz*((1.0-sx)*sgg[ix][iz+1] +
						sx*sgg[ix+1][iz+1]);
			
			/* cosines of incidence and reflection angles */
			ci = cd*cos(asd)+sd*sin(asd);
			cr = cd*cos(agd)+sd*sin(agd);

			/* two-way time and amplitude */
			time = tsd+tgd;

			if (ls)
			     amp = sqrt(vs0*vg0/(sgsd*sggd));
			else
			     amp = sqrt(vs0*vg0/(sgsd*sggd*(sgsd+sggd)));
					   
			amp *= ABS(ci+cr)*ar*ds;
		
			/* add sinc wavelet to trace */
			addsinc(time,amp,nt,dt,ft,trace);
		}
	}
	
	/* allocate workspace */
	temp = ealloc1float(nt);
	
	/* apply half-derivative filter to trace */
	conv(nhd,-lhd,hd,nt,0,trace,nt,0,temp);

	/* convolve wavelet with trace */
	conv(w->lw,w->iw,w->wv,nt,0,temp,nt,0,trace);
	
	/* free workspace */
	free1float(temp);
}


#define TINY 1.0e-3	/* avoid divide by zero */
#define CFL 0.98	/* Courant/Friedrichs/Lewy stability factor */

static void eikpex (int na, float da, float r, float dr, 
	float sc[], float uc[], float wc[], float tc[],
	float sn[], float un[], float wn[], float tn[])
/*****************************************************************************
Eikonal equation extrapolation of times and derivatives in polar coordinates
******************************************************************************
Input:
na		number of a samples
da		a sampling interval
r		current radial distance r
dr		radial distance to extrapolate
sc		array[na] of slownesses at current r
uc		array[na] of dt/dr at current r
wc		array[na] of dt/da at current r
tc		array[na] of times t at current r
sn		array[na] of slownesses at next r

Output:
un		array[na] of dt/dr at next r (may be equivalenced to uc)
wn		array[na] of dt/da at next r (may be equivalenced to wc)
tn		array[na] of times t at next r (may be equivalenced to tc)
******************************************************************************
Notes:
If na*da==2*PI, then the angular coordinate is wrapped around (periodic). 

This function implements the finite-difference method described by Bill
Symes (Rice University) and Jos van Trier (Stanford University) in a
(1990) preprint of a paper submitted to Geophysics.
******************************************************************************
Author:  Dave Hale, Colorado School of Mines, 07/16/90
******************************************************************************/
{
	int i,wrap;
	float drleft,drorig,frac,cmax,umaxl,uminr,uminm,umaxm,
		uu,unew,uold,ueol,ueor,wor,or,*wtemp,*s;
	
	/* allocate workspace */
	wtemp = alloc1float(na);
	s = alloc1float(na);
	
	/* remember the step size */
	drleft = drorig = dr;
	
	/* initialize slownesses to values at current r */
	for (i=0; i<na; ++i)
		s[i] = sc[i];
	
	/* copy inputs to output */
	for (i=0; i<na; ++i) {
		un[i] = uc[i];
		wn[i] = wc[i];
		tn[i] = tc[i];
	}
	
	/* determine if angular coordinate wraps around */
	wrap = ABS(na*da-2.0*PI)<0.01*ABS(da);
	
	/* loop over intermediate steps with adaptive stepsize */
	while (drleft>0.0) {
		
		/* determine adaptive step size according to CFL condition */
		for (i=0,cmax=TINY; i<na; ++i) {
			if (r*ABS(un[i])<TINY*ABS(wn[i]))
				cmax = 1.0/TINY;
			else
				cmax = MAX(cmax,ABS(wn[i]/(r*un[i])));
		}
		dr = MIN(drleft,CFL/cmax*r*da);
		
		/* if angles wrap around */
		if (wrap) {
			umaxl = (wn[na-1]>0.0 ? un[na-1] : s[0]);
			if (wn[0]>0.0) {
				uminm = s[0];
				umaxm = un[0];
			} else {
				uminm = un[0];
				umaxm = s[0];
			}
			uminr = (wn[1]>0.0 ? s[0] : un[1]);
			ueol = uminm+umaxl;
			ueor = uminr+umaxm;
			wtemp[0] = wn[0]+dr*(ueor-ueol)/da;
			umaxl = (wn[na-2]>0.0 ? un[na-2] : s[na-1]);
			if (wn[na-1]>0.0) {
				uminm = s[na-1];
				umaxm = un[na-1];
			} else {
				uminm = un[na-1];
				umaxm = s[na-1];
			}
			uminr = (wn[0]>0.0 ? s[na-1] : un[0]);
			ueol = uminm+umaxl;
			ueor = uminr+umaxm;
			wtemp[na-1] = wn[na-1]+dr*(ueor-ueol)/da;
		
		/* else, if angles do not wrap around */
		} else {
			if (wn[0]<=0.0)
				wtemp[0] = wn[0] + 
					dr*(un[1]-un[0])/da; 
			else
				wtemp[0] = 0.0;
			if (wn[na-1]>=0.0) 
				wtemp[na-1] = wn[na-1] +
					dr*(un[na-1]-un[na-2])/da;
			else
				wtemp[na-1] = 0.0;
		}
		
		/* update interior w values via Enquist/Osher scheme */
		for (i=1; i<na-1; ++i) {
			umaxl = (wn[i-1]>0.0 ? un[i-1] : s[i]);
			if (wn[i]>0.0) {
				uminm = s[i];
				umaxm = un[i];
			} else {
				uminm = un[i];
				umaxm = s[i];
			}
			uminr = (wn[i+1]>0.0 ? s[i] : un[i+1]);
			ueol = uminm+umaxl;
			ueor = uminr+umaxm;
			wtemp[i] = wn[i]+dr*(ueor-ueol)/da;
		}
		
		/* decrement the size of step left to do */
		drleft -= dr;
		
		/* update radial coordinate and its inverse */
		r += dr;
		or = 1.0/r;
		
		/* linearly interpolate slowness for new r */
		frac = drleft/drorig;
		for (i=0; i<na; ++i)
			s[i] = frac*sc[i]+(1.0-frac)*sn[i];
		
		/* update w and u; integrate u to get t */
		for (i=0; i<na; i++) {
			wn[i] = wtemp[i];
			wor = wn[i]*or;
			uu = (s[i]-wor)*(s[i]+wor);
			if(uu<=0)
				err("\tRaypath has too large a curvature!\n\t"
				    "A smoother velocity is required. \n");
 			unew = sqrt(uu); 
			uold = un[i];
			un[i] = unew;
			tn[i] += 0.5*dr*(unew+uold);
		}
	}
	
	/* free workspace */
	free1float(wtemp);
	free1float(s);
}

static void sigma (int na, float da, float r, float dr, 
	float uc[], float wc[], float sc[],
	float un[], float wn[], float sn[])
/*****************************************************************************
difference equation extrapolation of "sigma" in polar coordinates
******************************************************************************
Input:
na		number of a samples
da		a sampling interval
r		current radial distance r
dr		radial distance to extrapolate
uc		array[na] of dt/dr at current r
wc		array[na] of dt/da at current r
sc		array[na] of sigma  at current r
un		array[na] of dt/dr at next r
wn		array[na] of dt/da at next r

Output:
sn		array[na] of sigma at next r 
******************************************************************************

This function implements the Crank-Nicolson finite-difference method with
boundary conditions dsigma/da=0. 

Author:  Zhenyue Liu, Center for Wave Phenomena, 07/8/92
******************************************************************************/
{
	int i;
	float r1,*d,*b,*c,*e;
	
	/* allocate workspace */
	d = alloc1float(na-2);
	b = alloc1float(na-2);
	c = alloc1float(na-2);
	e = alloc1float(na-2);
	
	r1 = r+dr;
 	
	/* Crank-Nicolson */
 	for (i=0; i<na-2; ++i) {
		d[i] = (uc[i+1]+un[i+1])/(2.0*dr);
		e[i] = (wn[i+1]/(r1*r1)+wc[i+1]/(r*r))/(8.0*da);
		b[i] = 1.0-(sc[i+2]-sc[i])*e[i]
			+d[i]*sc[i+1];
		c[i] = -e[i];
	} 
	d[0] += c[0];
	d[na-3] += e[na-3]; 
	
	tripp(na-2,d,e,c,b);
	for(i=0;i<na-2; ++i) sn[i+1]=b[i];
	sn[0] = sn[1];
	sn[na-1] = sn[na-2];
	
	
	/* free workspace */
	free1float(d);
	free1float(c);
	free1float(e);
	free1float(b);
}

static void beta (int na, float da, float r, float dr, 
	float uc[], float wc[], float bc[],
	float un[], float wn[], float bn[])
/*****************************************************************************
difference equation extrapolation of "beta" in polar coordinates
******************************************************************************
Input:
na		number of a samples
da		a sampling interval
r		current radial distance r
dr		radial distance to extrapolate
uc		array[na] of dt/dr at current r
wc		array[na] of dt/da at current r
bc		array[na] of beta  at current r
un		array[na] of dt/dr at next r
wn		array[na] of dt/da at next r

Output:
bn		array[na] of beta at next r 
******************************************************************************

This function implements the Crank-Nicolson finite-difference method, with 
boundary conditions dbeta/da=1. 

author:  Zhenyue Liu, Center for Wave Phenomena, 07/8/92
******************************************************************************/
{
	int i;
	float r1,*d,*b,*c,*e;
	
	/* allocate workspace */
	d = alloc1float(na-2);
	b = alloc1float(na-2);
	c = alloc1float(na-2);
	e = alloc1float(na-2);
	
	r1 = r+dr;
	/* Crank-Nicolson */
   	for (i=0; i<na-2; ++i) {
		d[i] = uc[i+1]*r*r+un[i+1]*r1*r1;
		e[i] = (wn[i+1]+wc[i+1])*dr/(4.0*da);
		b[i] = -(bc[i+2]-bc[i])*e[i]
			+d[i]*bc[i+1];
		c[i] = -e[i];
	}   
	d[0] += c[0];
	d[na-3] += e[na-3]; 
	b[0] += da*c[0];
	b[na-3] -= da*e[na-3];
	
	tripp(na-2,d,e,c,b);
	for(i=0;i<na-2; ++i) bn[i+1]=b[i];
	bn[0] = bn[1]-da;
	bn[na-1] = bn[na-2]+da;
	
	
	/* free workspace */
	free1float(d);
	free1float(c);
	free1float(e);
	free1float(b);
}

static void exch(float x, float y);
static void exch(float x, float y)
{    
	float t;
	t=x; x=y; y=t;
}

static void tripp(int n, float *d, float *e, float *c, float *b)
/*******************************************************************
Solve an unsymmetric tridiagonal system that uses Gaussian elimination 
with partial pivoting
********************************************************************
Input:
d	diagonal vector of matrix
e       upper-diagonal vector of matrix
c       lower-diagonal vector of matrix
b       right-hand vector
n       dimension of matrix

Output:
b       solution vector
*******************************************************************
Author: Zhenyue Liu, Colorado School of Mines, 7/06/92
*********************************************************************/
{
	int k;
	float temp;

	
/*      elimination   */
	for(k=0; k<n-1; ++k){
	    c[k] = 0;
 	    if(ABS(d[k])<ABS(c[k+1])){
	        exch(d[k],c[k+1]);
		exch(e[k],d[k+1]);
		exch(c[k],e[k+1]);
		exch(b[k],b[k+1]);
		} 
		
	    if(d[k]==0 ) err("coefficient matrix is singular!\n");
	    temp = c[k+1]/d[k];  
	    d[k+1] -= temp*e[k];
	    e[k+1] -= temp*c[k];
	    b[k+1] -= temp*b[k];
        } 
	 
/*      substitution      */
	if(d[n-1]==0 ) err("coefficient matrix is singular!\n");
	b[n-1] = b[n-1]/d[n-1];
	b[n-2] = (b[n-2] - b[n-1]*e[n-2])/d[n-2];		
	for(k=n-3; k>=0; --k)
	    b[k] = (b[k] - b[k+1]*e[k] - b[k+2]*c[k])/d[k];
	    
}	

/* functions defined and used internally */
static void eiktam (float xs, float zs, 
	int nz, float dz, float fz, int nx, float dx, float fx, float **vel,
	float **time, float **angle, float **sig, float **bet)
/*****************************************************************************
Compute traveltimes t(x,z) and  propagation angle a(x,z) via eikonal equation,
 and sigma sig(x,z), incident angle bet(x,z) via Crank-Nicolson Method
******************************************************************************
Input:
xs		x coordinate of source (must be within x samples)
zs		z coordinate of source (must be within z samples)
nz		number of z samples
dz		z sampling interval
fz		first z sample
nx		number of x samples
dx		x sampling interval
fx		first x sample
vel		array[nx][nz] containing velocities

Output:
time		array[nx][nz] containing first-arrival times
angle		array[nx][nz] containing propagation angles
sig  		array[nx][nz] containing sigmas
bet		array[nx][nz] containing betas
******************************************************************************
Notes:
The actual computation of times and sigmas is done in polar coordinates,
with bilinear interpolation used to map to/from rectangular coordinates.
******************************************************************************
Revisor:  Zhenyue Liu, Colorado School of Mines, 7/8/92
******************************************************************************/
{
	int ix,iz,ia,ir,na,nr;
	float ss,a,r,da,dr,fa,fr,ex,ez,ea,rmax,rmaxs,
		**s,**sp,**tp,**up,**wp,**ap;

	/* shift coordinates so source is at (x=0,z=0) */
	fx -= xs;
	fz -= zs;
	ex = fx+(nx-1)*dx;
	ez = fz+(nz-1)*dz;
	
	/* determine polar coordinate sampling */
	rmaxs = fx*fx+fz*fz;
	rmaxs = MAX(rmaxs,fx*fx+ez*ez);
	rmaxs = MAX(rmaxs,ex*ex+ez*ez);
	rmaxs = MAX(rmaxs,ex*ex+fz*fz);
	rmax = sqrt(rmaxs);
	dr = MIN(ABS(dx),ABS(dz));
	nr = 1+NINT(rmax/dr);
	dr = rmax/(nr-1);
	fr = 0.0;
	if (fx==0.0 && fz==0.0) {
		fa = 0.0;  ea = PI/2.0;
	} else if (fx<0.0 && fz==0.0) {
		fa = -PI/2.0;  ea = PI/2.0;
	} else if (fx==0.0 && fz<0.0) {
		fa = 0.0;  ea = PI;
	} else {
		fa = -PI;  ea = PI;
	}
	da = dr/rmax;
	na = 1+NINT((ea-fa)/da);
	da = (ea-fa)/(na-1);
	if (fa==-PI && ea==PI)
		na = na-1;
	
	/* allocate space */
	s = alloc2float(nz,nx);
	sp = alloc2float(na,nr);
	tp = alloc2float(na,nr);
	up = alloc2float(na,nr);
	wp = alloc2float(na,nr);
	ap = alloc2float(na,nr);
	
	/* compute slownesses */
	for (ix=0; ix<nx; ++ix)
		for (iz=0; iz<nz; ++iz)
			s[ix][iz] = 1.0/vel[ix][iz];
	
	/* convert from rectangular to polar coordinates */
	recttopolar(nz,dz,fz,nx,dx,fx,s,na,da,fa,nr,dr,fr,sp);
	
	/* average the slownesses in source region */
	for (ir=0,ss=0.0; ir<2; ++ir)
		for (ia=0; ia<na; ++ia)
			ss += sp[ir][ia];
	ss /= 2*na;

	/* compute traveltimes and derivatives in source region */
	for (ir=0,r=0; ir<2; ++ir,r+=dr) {
		for (ia=0; ia<na; ++ia) {
			up[ir][ia] = ss;
			wp[ir][ia] = 0.0;
			tp[ir][ia] = r*ss;
		}
	}

/* 	tt=cpusec();   */
	/* solve eikonal equation for remaining times and derivatives */
	for (ir=1,r=dr; ir<nr-1; ++ir,r+=dr) {
		eikpex(na,da,r,dr,
			sp[ir],up[ir],wp[ir],tp[ir],
			sp[ir+1],up[ir+1],wp[ir+1],tp[ir+1]);
	}
	
	/* convert times from polar to rectangular coordinates */
	polartorect(na,da,fa,nr,dr,fr,tp,nz,dz,fz,nx,dx,fx,time);

/*  	fprintf(stderr,"\t CPU time for traveltimes= %f \n",cpusec()-tt); 
 	tt=cpusec();   */
	
	/* compute propagation angles in polar and convert */
	for (ia=0,a=fa; ia<na; ++ia,a+=da)
		ap[0][ia] = a;
	for (ir=1,r=fr+dr; ir<nr; ++ir,r+=dr)
		for (ia=0,a=fa; ia<na; ++ia,a+=da){
		    ap[ir][ia] = a+asin(wp[ir][ia]/(sp[ir][ia]*r));
		}
	polartorect(na,da,fa,nr,dr,fr,ap,nz,dz,fz,nx,dx,fx,angle);
/*  	fprintf(stderr,"\t CPU time for propagation angles= %f\n", 	
		cpusec()-tt); 
	tt=cpusec();   */
	
	/* compute sigmas  for initial values */
	for (ir=0,r=0; ir<2; ++ir,r+=dr) 
		for (ia=0; ia<na; ++ia) tp[ir][ia] = r/ss;

	/* solve diffrence equation for remaining sigmas */
	for (ir=1,r=dr; ir<nr-1; ++ir,r+=dr) 
 		sigma(na,da,r,dr,up[ir],wp[ir],tp[ir],
			up[ir+1],wp[ir+1],tp[ir+1]);  
	polartorect(na,da,fa,nr,dr,fr,tp,nz,dz,fz,nx,dx,fx,sig);

/* 	fprintf(stderr,"\t CPU time for sigmas= %f \n",cpusec()-tt); 
	tt=cpusec(); */
	
	/* compute betas for initial values */
	for (ir=0; ir<2; ++ir) 
		for (ia=0,a=fa; ia<na; ++ia,a+=da) tp[ir][ia] = a;

	/* solve diffrence equation for remaining betas */
	for (ir=1,r=dr; ir<nr-1; ++ir,r+=dr) 
 		beta(na,da,r,dr,up[ir],wp[ir],tp[ir],
			up[ir+1],wp[ir+1],tp[ir+1]);  
	polartorect(na,da,fa,nr,dr,fr,tp,nz,dz,fz,nx,dx,fx,bet);
	
/* 	fprintf(stderr,"\t CPU time for incident angles= %f \n",
		cpusec()-tt); */
	
	/* free space */
	free2float(s);
	free2float(sp);
	free2float(tp);
	free2float(up);
	free2float(wp);
	free2float(ap);
}

