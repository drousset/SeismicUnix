/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* FGETTR: $Revision: 1.37 $; $Date: 1996/09/16 17:11:52 $	*/


/*********************** self documentation **********************/
/****************************************************************************
FGETTR - Routines to get an SU trace from a file 

fgettr		get a fixed-length segy trace from a file by file pointer
fvgettr		get a variable-length segy trace from a file by file pointer
fgettra		get a fixed-length trace from disk file by trace number
gettr		macro using fgettr to get a trace from stdin
vgettr		macro using fvgettr to get a trace from stdin
gettra		macro using fgettra to get a trace from stdin by trace number
 
*****************************************************************************
Function Prototype:
int fgettr(FILE *fp, segy *tp);
int fvgettr(FILE *fp, segy *tp);
int fgettra(FILE *fp, segy *tp, int itr);

*****************************************************************************
Returns:
fgettr, fvgettr:
int: number of bytes read on current trace (0 after last trace)

fgettra:
int: number of traces in disk file
 
The function gettr(x) is a macro defined in su.h
#define gettr(x)	fgettr(stdin, (x))

Usage example:
 	segy tr;
 	...
 	while (gettr(&tr)) {
 		tr.offset = abs(tr.offset);
 		puttr(&tr);
 	}
 	...

*****************************************************************************
Authors: SEP & MOBIL: Stewart A. Levin
	 SEP: Einar Kjartansson
         CWP: Shuki Ronen, Jack Cohen
****************************************************************************/
/**************** end self doc ********************************/

#include "su.h"
#include "segy.h"
#include "header.h"

static struct insegyinfo {
	FILE *infp;                  /* FILE * ptr for search	 */
	struct insegyinfo *nextinfo; /* linked list pointer      */
	unsigned long itr;	     /* number of traces read	 */
	int nsfirst;		     /* samples from 1st header	 */
	unsigned short bytesper;     /* bytes per datum		 */
	int nsegy; 		     /* segy bytes from nsfirst	 */
	int ntr;                     /* traces in input,if known */
	FileType ftype;		     /* file type of input *fp	 */
} *insegylist = (struct insegyinfo *) NULL;

static FILE *lastfp = (FILE *) NULL;
static struct insegyinfo *infoptr, **oldinfoptr;

static
void searchlist(FILE *fp)
{
	oldinfoptr = &insegylist;
	for(infoptr = insegylist; infoptr != ((struct insegyinfo *) NULL);
	    infoptr = infoptr->nextinfo) {
		if(fp == infoptr->infp) break;
		oldinfoptr = &infoptr->nextinfo;
	}
}

static
int dataread(segy *tp, struct insegyinfo *iptr, cwp_Bool fixed_length)
{
	unsigned int nsread = fixed_length?iptr->nsfirst:tp->ns;
	unsigned int databytes = infoptr->bytesper*nsread;
	int nread = (int) efread((char *) (&((tp->data)[0])),1, databytes,
			   iptr->infp);

	if(nread > 0 && nread != databytes) 
		err("%s: on trace #%ld, tried to read %d bytes, "
		    "read %d bytes ",
		    __FILE__, (infoptr->itr)+1, databytes, nread);

	return(nread);
}


static
int fgettr_internal(FILE *fp, segy *tp, cwp_Bool fixed_length)
{
	int nread;	/* bytes seen by fread calls	*/

	/* search linked list for possible alternative */
	if(fp != lastfp)  searchlist(fp);

	if (infoptr == ((struct insegyinfo *) NULL)) {
		/* initialize new segy input stream */
		unsigned int databytes;	/* bytes from nsfirst	*/

		/* allocate new segy input information table */
		*oldinfoptr = (struct insegyinfo *)
			malloc(sizeof(struct insegyinfo));
		infoptr = *oldinfoptr;
		infoptr->nextinfo = (struct insegyinfo *) NULL;
		infoptr->infp = fp;  /* save FILE * ptr */
		infoptr->itr = 0;
		infoptr->ntr = -1;
		
		switch (infoptr->ftype = filestat(fileno(fp))) {
		case DIRECTORY:
			err("%s: segy input can't be a directory", __FILE__);
		case TTY:
			err("%s: segy input can't be tty", __FILE__);
		default:
			/* all others are ok */
		break;
		}

		/* Get the header */
		switch (nread = (int) efread(tp, 1, HDRBYTES, infoptr->infp)) {
		case 0:   return 0; /* no traces; trap in mains */
		default:  if (nread != HDRBYTES)
				err("%s: bad first header", __FILE__);
		}		

		/* Have the header, now for the data */
		infoptr->nsfirst = tp->ns;
		if (infoptr->nsfirst > SU_NFLTS)
			err("%s: unable to handle %d > %d samples per trace",
			    __FILE__, infoptr->nsfirst, SU_NFLTS);

		switch (tp->trid) {
		case CHARPACK:
			infoptr->bytesper = sizeof(char); break;
		case SHORTPACK:
			infoptr->bytesper = 2*sizeof(char); break;
		default:
			infoptr->bytesper = sizeof(float); break;
		}

		databytes = infoptr->bytesper * tp->ns;

		infoptr->nsegy = HDRBYTES + databytes;

		/* Inconvenient to bump nread here; do it in the switch */
		nread = dataread(tp, infoptr, fixed_length);

		switch (nread) {
		case 0:   err("%s: no data on first trace", __FILE__);
		default:  if (nread != databytes)
				err("%s: first trace: "
				    "read only %d bytes of %u",
				    __FILE__, nread, databytes);
			  else nread += HDRBYTES;
		}

		if (infoptr->ftype == DISK) { /* compute ntr */
			efseek(fp,0L,SEEK_END);
			infoptr->ntr = (int)(eftell(fp)/infoptr->nsegy);
			efseek(fp,infoptr->nsegy,SEEK_SET); /* reset fp */
	        }


	} else {		/* Not first entry */
		switch (nread = (int) efread(tp, 1, HDRBYTES, infoptr->infp)) {
		case 0: lastfp = infoptr->infp;
			return 0; /* finished */
		default:  if (nread != HDRBYTES)
				err("%s: on trace #%ld read %d bytes ",
				    "expected %d bytes",
				    __FILE__,(infoptr->itr)+1,nread,HDRBYTES);
		}

                nread += dataread(tp, infoptr, fixed_length);

		if (fixed_length && (tp->ns != infoptr->nsfirst))
			err("%s: on trace #%ld, "
			    "number of samples in header (%d) "
			    "differs from number for first trace (%d)", 
			    __FILE__, (infoptr->itr)+1, tp->ns,
			    infoptr->nsfirst);
	}

	++(infoptr->itr);
	lastfp = infoptr->infp;
	return (nread);
}

int fgettr(FILE *fp, segy *tp)
{
	return(fgettr_internal(fp,tp,cwp_true));
}

int fvgettr(FILE *fp, segy *tp)
{
	return(fgettr_internal(fp,tp,cwp_false));
}

int fgettra(FILE *fp, segy *tp, int itr)
{
	int nread;
	if(lastfp != fp)  searchlist(fp);  /* search for match */
		
	
	if(infoptr == (struct insegyinfo *) NULL) {
		/* get first trace */
		if(0 >= fgettr(fp, tp)) return(0); /* error return */

		switch(infoptr->ftype) {
		case TTY:
			warn("stdin not redirected");
		break;
		case DISK:	/* correct */
		break;
		default:
			err("%s: input must be disk file",__FILE__);
		}
      
		efseek(fp,0L,SEEK_END);
		infoptr->ntr = (int) (eftell(fp)/infoptr->nsegy);
	} /* end first entry initialization */
	
	/* Check on requested trace number */
	if(itr >= infoptr->ntr)
		err("%s: trying to read off end of file",__FILE__);
	
	/* Position file pointer at start of requested trace */
	efseek(fp, itr*infoptr->nsegy, SEEK_SET);
	
	nread=fgettr(fp, tp); /* let fgettr do the work */
	if(nread != infoptr->nsegy)
		err("%s: read %d bytes in trace of %d bytes",
		    __FILE__,nread,infoptr->nsegy);
	
	if(tp->ns != infoptr->nsfirst)
		warn("%s: header ns field = %d differs from first trace = %d",
		     __FILE__,tp->ns,infoptr->nsfirst);
	
	return(infoptr->ntr);
}

#ifdef TEST

char *sdoc[] = {
"								",
" tgettr <stdin >stdout						",
"								",
" 	Test harness for gettr.c				",
"	Changes cdp to abs(cdp)					",
"	Contrast the following results:	 			",
"	suplane offset=-100 | sugethw offset 			",
"	suplane offset=-100 | tgettr | sugethw offset		",
"								",
NULL};

segy tr;

main(int argc, char **argv)
{
	initargs(argc, argv);
	requestdoc(1);

 	while (gettr(&tr)) {
 		tr.offset = abs(tr.offset);
 		puttr(&tr);
 	}

	return EXIT_SUCCESS;
}
#endif
