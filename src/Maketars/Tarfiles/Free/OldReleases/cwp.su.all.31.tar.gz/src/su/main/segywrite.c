/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SEGYWRITE: $Revision: 1.39 $ ; $Date: 1997/08/07 14:58:39 $    */

#include "su.h"
#include "segy.h"
#include "tapesegy.h"
#include "tapebhdr.h"
#include "bheader.h"

/*********************** self documentation **********************/
char *sdoc[] = {
"									",
" SEGYWRITE - write an SEG-Y tape					",
"									",
" segywrite <stdin tape=						",
"									",
" Required parameters:							",
"	tape=		tape device to use (see sudoc segyread)		",
"									",
" Optional parameter:							",
"	verbose=0	silent operation				",
"			=1 ; echo every 'vblock' traces			",
"	vblock=50	echo every 'vblock' traces under verbose option ",
"	buff=1		for buffered device (9-track reel tape drive)	",
"			=0 possibly useful for 8mm EXABYTE drive	",
"	conv=1		=0 don't convert to IBM format			",
"	hfile=header	ebcdic card image header file			",
"	bfile=binary	binary header file				",
"	trmin=1 first trace to write					",
"	trmax=INT_MAX  last trace to write			       ",
"	endian=1	=0 for little-endian machines (PC's, DEC,etc...)",
"	errmax=0	allowable number of consecutive tape IO errors	",
"									",
" Note: The header files may be created with  'segyhdrs'.		",
"									",
"									",
" Note: For buff=1 (default) tape is accessed with 'write', for buff=0	",
"	tape is accessed with fwrite. Try the default setting of buff=1 ",
"	for all tape types.						",
" Caveat: may be slow on an 8mm streaming (EXABYTE) tapedrive		",
" Warning: segyread or segywrite to 8mm tape is fragile. Allow time	",
"	   between successive reads and writes.				",
" Precaution: make sure tapedrive is set to read/write variable blocksize",
"	   tapefiles.							",
"									",
" For more information, type:	sudoc <segywrite>			",
NULL};

/*
 * Warning: may return the error message "efclose: fclose failed"
 *	 intermittently when segyreading/segywriting to 8mm EXABYTE tape,
 *	 even if actual segyread/segywrite is successful. However, this
 *	 may indicate that your tape drive has been set to a fixed block
 *	 size. Tape drives should be set to variable block size before reading
 *	 or writing tapes in the SEG-Y format.
 */

/* Credits:
 *	SEP: Einar Kjartansson
 *	CWP: Jack, Brian, Chris
 *	   : John Stockwell (added EXABYTE functionality)
 * Notes:
 *	Brian's subroutine, float_to_ibm, for converting IEEE floating
 *	point to IBM floating point is NOT portable and must be
 *	altered for non-IEEE machines.	See the subroutine notes below.
 *
 *	On machines where shorts are not 2 bytes and/or ints are not 
 *	4 bytes, routines to convert SEGY 16 bit and 32 bit integers 
 *	will be required.
 *
 *	The program, segyhdrs, can be used to make the ascii and binary
 *	files required by this code.
 */

/**************** end self doc ***********************************/

/* subroutine prototypes */
static void float_to_ibm(int from[], int to[], int n, int endian);
static void bhed_to_tapebhed(const bhed *bhptr, tapebhed *tapebhptr); 
static void
	segy_to_tapesegy(const segy *trptr, tapesegy *tapetrptr, size_t nsegy); 

tapesegy tapetr;
tapebhed tapebh;
segy tr;
bhed bh;

int
main(int argc, char **argv)
{
	cwp_String tape;	/* name of raw tape device		*/
	cwp_String hfile;	/* name of ebcdic header file		*/
	cwp_String bfile;	/* name of binary header file		*/

	FILE *pipefp;		/* file pointer for popen read		*/
	FILE *tapefp=NULL;	/* file pointer for tape		*/
	FILE *binaryfp;		/* file pointer for bfile		*/

	int tapefd=0;		/* file descriptor for tape buff=0	*/

	int i;			/* counter				*/
	int ns;			/* number of data samples		*/
	size_t nsegy;		/* size of whole trace in bytes		*/
	int itr;		/* current trace number			*/
	int trmax;		/* last trace to write			*/
	int trmin;		/* first trace to write			*/
	int verbose;		/* echo every ...			*/
	int vblock;		/* ... vblock traces with verbose=1	*/
	int buff;		/* buffered or unbuffered device	*/
	int endian;		/* =0 little endian; =1 big endian	*/
	int conv;		/* =1 IBM format =0 don't convert	*/
	int errmax;		/* max consecutive tape io errors	*/
	int errcount = 0;	/* counter for tape io errors		*/
	char cmdbuf[BUFSIZ];	/* dd command buffer			*/
	char ebcbuf[EBCBYTES];	/* ebcdic data buffer			*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get parameters */
	MUSTGETPARSTRING("tape", &tape);
	if (!getparstring("hfile", &hfile))	hfile = "header";
	if (!getparstring("bfile", &bfile))	bfile = "binary";
	if (!getparint	 ("trmin", &trmin))	trmin = 1;
	if (!getparint	 ("trmax", &trmax))	trmax = INT_MAX;
	if (!getparint	 ("verbose", &verbose)) verbose = 0;
	if (!getparint	 ("vblock", &vblock))	vblock = 50;
	if (!getparint	 ("buff", &buff))	buff = 1;
	if (!getparint	 ("conv", &conv))	conv = 1;
	if (!getparint	 ("endian", &endian))	endian = 1;
	if (!getparint	 ("errmax", &errmax))	errmax = 0;
	
	/* Check parameters */
	if (trmin < 1 || trmax < 1 || trmax < trmin)
		err("bad trmin/trmax values, trmin = %d, trmax = %d",
			trmin, trmax);

	/* Get first trace early to be sure that binary file is ready */
	gettr(&tr);

	/* Open files - first the tape */
	if (buff) tapefd = eopen(tape, O_WRONLY | O_CREAT | O_TRUNC, 0666);
	else tapefp = efopen(tape, "w");
	if (verbose) warn("tape opened successfully ");

	/* - binary header file */
	binaryfp = efopen(bfile, "r");
	if (verbose) warn("binary file opened successfully");

	/* Open pipe to use dd to convert ascii to ebcdic */
	sprintf(cmdbuf, "dd if=%s conv=ebcdic cbs=80 obs=3200", hfile);
	pipefp = epopen(cmdbuf, "r");

	/* Read ebcdic stream from pipe into buffer */
	efread(ebcbuf, 1, EBCBYTES, pipefp);

	/* Write ebcdic stream to tape */
	if (buff) {
		if (EBCBYTES != write(tapefd, ebcbuf, EBCBYTES)) {
			if (verbose)
				warn("tape write error on ebcdic header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	} else {
		 fwrite(ebcbuf, 1, EBCBYTES, tapefp);
		 if (ferror(tapefp)) {
			if (verbose)
				warn("tape write error on ebcdic header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
			clearerr(tapefp);
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	}

	/* Read binary file into bh structure */
	efread((char *) &bh, 1, BNYBYTES, binaryfp);
	bh.format = 1;	/* indicate SEG-Y data	*/

	if (bh.ntrpr == 0) bh.ntrpr  = 1;	/* one trace per record */

	/* Compute trace size (can't use HDRBYTES here!) */
	ns = bh.hns;
	if (!ns) err("bh.hns not set in binary header");
	nsegy = ns*4 + SEGY_HDRBYTES;

	/* if little endian (endian=0) swap bytes of binary header */
	if (endian==0) for (i = 0; i < BHED_NKEYS; ++i) swapbhval(&bh,i);

	/* Convert from ints/shorts to bytes */
	bhed_to_tapebhed(&bh, &tapebh);

	/* Write binary structure to tape */
	if (buff) {
		if (BNYBYTES != write(tapefd, (char *) &tapebh, BNYBYTES)) {
			if (verbose)
				warn("tape write error on binary header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	} else {
		 fwrite((char *) &tapebh, 1, BNYBYTES, tapefp);
		 if (ferror(tapefp)) {
			if (verbose)
				warn("tape write error on binary header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
			clearerr(tapefp);
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	}


	/* Copy traces from stdin to tape */
	itr = 0;
	do {

		/* Set/check trace header words */
		tr.tracr = ++itr;
		if (tr.ns != ns)
			err("conflict: tr.ns = %d, bh.ns = %d: trace %d",
					tr.ns, ns, itr);

		/* Convert and write desired traces */
		if (itr >= trmin) {

		
			/* Convert internal floats to IBM floats */
			if (conv)
				float_to_ibm((int *) tr.data, (int *) tr.data,
								ns, endian);

		       /* handle no ibm conversion for little endian case */
		       if (conv==0 && endian==0)
				for (i = 0; i < ns ; ++i)
					swap_float_4(&tr.data[i]);
			
			/* if little endian, swap bytes in header */
			if (endian==0)
			    for (i = 0; i < SEGY_NKEYS; ++i) swaphval(&tr,i);

			/* Convert from ints/shorts to bytes */
			segy_to_tapesegy(&tr, &tapetr, nsegy);

			/* Write the trace to tape */
			if (buff) {
			    if (nsegy !=
			       write(tapefd, (char *) &tapetr, nsegy)){
				if (verbose)
				    warn("tape write error on trace %d", itr);
				if (++errcount > errmax)
				    err("exceeded maximum io errors");
			    } else { /* Reset counter on successful tape IO */
				errcount = 0;
			    }
			} else {
			    fwrite((char *)&tapetr,1,nsegy,tapefp);
			    if (ferror(tapefp)) {
				if (verbose)
				    warn("tape write error on trace %d", itr);
				if (++errcount > errmax)
				    err("exceeded maximum io errors");
				    clearerr(tapefp);
			    } else { /* Reset counter on successful tape IO */
				errcount = 0;
			    }
			}

			/* Echo under verbose option */
			if (verbose && itr % vblock == 0)
				warn(" %d traces written to tape", itr);
		}
	} while (gettr(&tr) && itr < trmax);


	/* Clean up */
	(buff) ?  eclose(tapefd) :
		  efclose(tapefp);
	if (verbose) warn("tape closed successfully");

	efclose(binaryfp);
	if (verbose) warn("binary file closed successfully");

	epclose(pipefp);

	return EXIT_SUCCESS;
}

/* Assumes sizeof(int) == 4 */
static void float_to_ibm(int from[], int to[], int n, int endian)
/**********************************************************************
 float_to_ibm - convert between 32 bit IBM and IEEE floating numbers
*********************************************************************** 
Input:
from	   input vector
n	   number of floats in vectors
endian	   =0 for little endian machine, =1 for big endian machines

Output:
to	   output vector, can be same as input vector

*********************************************************************** 
Notes:
Up to 3 bits lost on IEEE -> IBM

IBM -> IEEE may overflow or underflow, taken care of by 
substituting large number or zero

Only integer shifting and masking are used.
*********************************************************************** 
Credits:     CWP: Brian Sumner
***********************************************************************/
{
    register int fconv, fmant, i, t;

    for (i=0;i<n;++i) {
	fconv = from[i];
	if (fconv) {
	    fmant = (0x007fffff & fconv) | 0x00800000;
	    t = (int) ((0x7f800000 & fconv) >> 23) - 126;
	    while (t & 0x3) { ++t; fmant >>= 1; }
	    fconv = (0x80000000 & fconv) | (((t>>2) + 64) << 24) | fmant;
	}
	if(endian==0)
		fconv = (fconv<<24) | ((fconv>>24)&0xff) |
			((fconv&0xff00)<<8) | ((fconv&0xff0000)>>8);

	to[i] = fconv;
    }
    return;
}


static void bhed_to_tapebhed(const bhed *bhptr, tapebhed *tapebhptr)
/***************************************************************************
bhed_tape_bhed -- converts the binary tape header in the machine's short
and int types to, respectively, the seg-y standard 2 byte and 4 byte integer
types.
****************************************************************************
Input:
bhptr		pointer to binary header vector

Output:
tapebhptr	pointer to tape binary header vector
****************************************************************************
Notes:
The present implementation assumes that these types are actually the "right"
size (respectively 2 and 4 bytes), so this routine is only a placeholder for
the conversions that would be needed on a machine not using this convention.
****************************************************************************
Author: CWP: Jack K. Cohen  August 1994
***************************************************************************/
{
	register int i;
	Value val;
	
	/* convert the binary header field by field */
	for (i = 0; i < BHED_NKEYS; ++i) {
		getbhval(bhptr, i, &val);
		puttapebhval(tapebhptr, i, &val);
	}
}

static
void segy_to_tapesegy(const segy *trptr, tapesegy *tapetrptr, size_t nsegy)
/***************************************************************************
tapesegy_to_segy -- converts the integer header fields from, respectively,
		    the machine's short and int types to the  seg-y standard
		    2 byte and 4 byte types.
****************************************************************************
Input:
trptr		pointer to SU SEG-Y data vector		
nsegy		whole size of a SEG-Y trace in bytes

Output:
tapetrptr	pointer to tape SEG-Y data vector
****************************************************************************
Notes:
Also copies the float data byte by byte.  The present implementation assumes
that the integer types are actually the "right" size (respectively 2 and
4 bytes), so this routine is only a placeholder for the conversions that
would be needed on a machine not using this convention.	 The float data
is preserved as four byte fields and is later converted to internal floats
by float_to_ibm (which, in turn, makes additonal assumptions)
****************************************************************************
Author: CWP: Jack K. Cohen  August 1994
***************************************************************************/
{
	register int i;
	Value val;
	
	/* convert trace header, field by field */
	for (i = 0; i < SEGY_NKEYS; ++i) {
		gethval(trptr, i, &val);
		puttapehval(tapetrptr, i, &val);
	}
	
	/* copy optional portion */
	memcpy(tapetrptr->unass, (char *)&(trptr->otrav)+2, 60);

	/* copy data portion */
	memcpy(tapetrptr->data, trptr->data, 4*SU_NFLTS);

} 
