/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SURANGE: $Revision: 1.11 $ ; $Date: 1996/09/13 21:49:05 $	*/

#include "su.h"
#include "segy.h"
#include "header.h"
#include <signal.h>

/*********************** self documentation **********************/
char *sdoc[] = {
" 								",
" SURANGE - get max and min values for non-zero header entries	",
" 								",
" surange <stdin	 					",
" 								",
" Note: gives partial results if interrupted			",
" 								",
NULL};

/* Credits:
 *	SEP: Stew
 *	CWP: Jack
 *
 * Note: the use of "signal" is inherited from BSD days and may
 *       break on some UNIXs.  It is dicy in that the responsibility
 *	 for program termination is lateraled back to the main.
 *
 */
/**************** end self doc ***********************************/


/* Prototypes */
void printrange(segy *tpmin, segy *tpmax);
static void closeinput(void);

segy tr, trmin, trmax;

int
main(int argc, char **argv)
{
	int ntr;		/* number of traces		*/
	Value val;		/* value of current keyword	*/
	Value valmin;		/* smallest seen so far		*/
	Value valmax;		/* largest seen so far		*/
	cwp_String type;	/* data type of keyword		*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	memset((void *) &trmin, (int) '\0', sizeof(segy));
	memset( (void *) &trmax, (int) '\0', sizeof(segy));
	signal(SIGINT, (void (*) (int)) closeinput);
	signal(SIGTERM, (void (*) (int)) closeinput);

	/* Do first trace outside loop to initialize mins and maxs */
	if (!gettr(&tr)) err("can't get first trace");
	{ register int i;
	  for (i = 0; i < SU_NKEYS; ++i) {
		gethval(&tr, i, &val);
		puthval(&trmin, i, &val);
		puthval(&trmax, i, &val);
	  }
	}


	ntr = 1;
	while (gettr(&tr)) {
		register int i;
	        for (i = 0; i < SU_NKEYS; ++i) {
			type = hdtype(getkey(i));
			gethval(&tr, i, &val);
			gethval(&trmin, i, &valmin);
			gethval(&trmax, i, &valmax);
			if (valcmp(type, val, valmin) < 0)
				puthval(&trmin, i, &val);
			if (valcmp(type, val, valmax) > 0)
				puthval(&trmax, i, &val);
		}
		++ntr;
	}

	printf("%d traces:\n", ntr);
	printrange(&trmin, &trmax);


	return EXIT_SUCCESS;
}



/* printrange - print non-zero header values ranges	*/
void printrange(segy *tpmin, segy *tpmax)
{
	register int i, j = 0;
	Value valmin, valmax;
	double dvalmin, dvalmax;
	cwp_String key;
	cwp_String type;

	for (i = 0; i < SU_NKEYS; ++i) {
		key = getkey(i);
		type = hdtype(key);
		gethval(tpmin, i, &valmin);
		gethval(tpmax, i, &valmax);
		dvalmin = vtod(type, valmin);
		dvalmax = vtod(type, valmax);
		if (dvalmin || dvalmax) {
			if (dvalmin < dvalmax) {
				printf(" %s=(", key);
				printfval(type, valmin);
				putchar(',');
				printfval(type, valmax);
				printf(") ");
			} else {
				printf(" %s=", key);
				printfval(type, valmin);
			}
			if ((++j % 5) == 0)
				putchar('\n');
		}
	}
	putchar('\n');
	return;
}


static void closeinput(void) /* for graceful interrupt termination */
{
	/* Close stdin and open /dev/null in its place.  Now we are reading */
	/* from an empty file and the loops terminate in a normal fashion.  */

	efreopen("/dev/null", "r", stdin);
}
