/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SUZERO: $Revision: 1.9 $ ; $Date: 1996/09/13 21:49:05 $	*/

#include "su.h"
#include "segy.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 								",
" SUZERO -- zero-out data within a time window	 		",
" 								",
" suzero itmax= < indata > outdata				",
" 								",
" Required parameters						",
" 	itmax=		last time sample to zero out		",
" 								",
" Optional parameters						",
" 	itmin=0		first time sample to zero out		",
" 								",
" See also: sukill, sumute					",
" 								",
NULL};

/* Credits:
 *	CWP: Chris
 *
 * Trace header fields accessed: ns
 */
/**************** end self doc ***********************************/


segy tr;

int
main(int argc, char **argv)
{
	int itmin;		/* first sample to zero out		*/
	int itmax;		/* last sample to zero out	 	*/
	int nt;			/* time samples per trace in input data	*/

	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);

	/* Get information from first trace */
	if (!gettr(&tr)) err("can't get first trace");
	nt = tr.ns;

	/* Get params from user */
	MUSTGETPARINT("itmax", &itmax);
	if (!getparint("itmin", &itmin))	itmin = 0;

	/* Error checking */
	if (itmax > nt)    err("itmax = %d, must be < nt", itmax);
	if (itmin < 0)     err("itmin = %d, must not be negative", itmin);
	if (itmax < itmin) err("itmax < itmin, not allowed");

	/* Main loop over traces */
	do { 
		register int i;
		for (i = itmin; i <= itmax; ++i)  tr.data[i] = 0.0;
		
		puttr(&tr);
	} while(gettr(&tr));


	return EXIT_SUCCESS;
}
