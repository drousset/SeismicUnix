/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SUOP: $Revision: 1.13 $ ; $Date: 1997/06/09 16:55:17 $		*/

#include "su.h"
#include "segy.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 								",
" SUOP - do unary arithmetic operation on segys 		",
" 								",
" suop <stdin >stdout op=abs					",
" 								",
" Required parameters:						",
"	none							",
"								",
" Optional parameter:						",
"	op=abs		operation flag				",
"			abs   : absolute value			",
"			ssqrt : signed square root		",
"			sqr   : square				",
"			ssqr  : signed square			",
"			sgn   : signum function			",
"			exp   : exponentiate			",
"			slog  : signed natural log		",
"			slog10: signed common log		",
"			cos   : cosine				",
"			sin   : sine				",
"			tan   : tangent				",
"			cosh  : hyperbolic cosine		",
"			sinh  : hyperbolic sine			",
"			tanh  : hyperbolic tangent		",
"			norm  : divide trace by Max. Value	",
"			db    : 20 * slog10 (data)		",
"								",
" Note:	Binary ops are provided by suop2.			",
" Operations slog and slog10 are \"punctuated\", meaning that if",
" the input contains 0 values,	0 values are returned.		",
"								",
NULL};

/* Credits:
 *
 *	CWP: Shuki, Jack
 *	Toralf Foerster: norm and db operations, 10/95.
 *
 * Notes:
 *	If efficiency becomes important consider inverting main loop
 *      and repeating operation code within the branches of the switch.
 *
 *	Note on db option.  The following are equivalent:
 *	... | sufft | suamp | suop op=norm | suop op=slog10 |\
 *		sugain scale=20| suxgraph style=normal
 *
 *	... | sufft | suamp | suop op=db | suxgraph style=normal
 */
/**************** end self doc ***********************************/


#define	FABS	1
#define	SSQRT	2
#define	SQR	3
#define	SSQR	4
#define EXP	5
#define SLOG	6
#define SLOG10	7
#define COS	8
#define SIN	9
#define TAN	10
#define COSH	11
#define SINH	12
#define TANH	13
#define NORM    14	/* normalize at maximal value   */
#define DB      15	/* for frequency plot in db     */
#define SIGN     16	/* signum function		*/


segy tr;

int
main(int argc, char **argv)
{
	cwp_String op="abs";	/* operation: abs, exp, ..., 		*/
	int iop=FABS;		/* integer abbrev. for op in switch	*/
	int nt;			/* number of samples on input trace	*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get information from first trace */
	if (!gettr(&tr)) err("can't get first trace");
	nt = tr.ns;


	/* Get operation, recall iop initialized to the default FABS */
	getparstring("op", &op);
	if      (STREQ(op, "ssqrt"))	iop = SSQRT;
	else if (STREQ(op, "sqr"))	iop = SQR;
	else if (STREQ(op, "ssqr"))	iop = SSQR;
	else if (STREQ(op, "sgn"))	iop = SIGN;
	else if (STREQ(op, "exp"))	iop = EXP;
	else if (STREQ(op, "slog"))	iop = SLOG;
	else if (STREQ(op, "slog10"))	iop = SLOG10;
	else if (STREQ(op, "cos"))	iop = COS;
	else if (STREQ(op, "sin"))	iop = SIN;
 	else if (STREQ(op, "tan"))	iop = TAN;
	else if (STREQ(op, "cosh"))	iop = COSH;
	else if (STREQ(op, "sinh"))	iop = SINH;
	else if (STREQ(op, "tanh"))	iop = TANH;
	else if (STREQ(op, "norm"))     iop = NORM;
	else if (STREQ(op, "db"))       iop = DB;
	else if (!STREQ(op, "abs"))
		err("unknown operation=\"%s\", see self-doc", op);


	/* Main loop over traces */
	do {

		switch(iop) { register int i;
		case FABS:
			for (i = 0; i < nt; ++i)
				tr.data[i] = ABS(tr.data[i]);
		break;
		case SSQRT:
			for (i = 0; i < nt; ++i) {
				float x = tr.data[i];
				tr.data[i] = SGN(x) * sqrt(ABS(x));
			}
		break;
		case SQR:
			for (i = 0; i < nt; ++i) {
				float x = tr.data[i];
				tr.data[i] = x * x;
			}
		break;
		case SSQR:
			for (i = 0; i < nt; ++i) {
				float x = tr.data[i];
				tr.data[i] = SGN(x) * x * x;
			}
		break;
		case SIGN:
			for (i = 0; i < nt; ++i) {
				float x = tr.data[i];
				tr.data[i] = SGN(x);
			}
		break;
		case EXP:
			for (i = 0; i < nt; ++i)
				tr.data[i] = exp(tr.data[i]);
		break;
		case SLOG:
			for (i = 0; i < nt; ++i) {
				float x = tr.data[i];

				if (ABS(x) > 0) {
					tr.data[i] = SGN(x) * log(ABS(x));
				} else {
					tr.data[i] = 0;
				}
			}
		break;
		case SLOG10:
			for (i = 0; i < nt; ++i) {
				float x = tr.data[i];
				if (ABS(x) > 0) {
					tr.data[i] = SGN(x) * log10(ABS(x));
				} else {
					tr.data[i] = 0;
				}
					
			}
		break;
		case COS:
			for (i = 0; i < nt; ++i)
				tr.data[i] = cos(tr.data[i]);
		break;
		case SIN:
			for (i = 0; i < nt; ++i)
				tr.data[i] = sin(tr.data[i]);
		break;
		case TAN:
			for (i = 0; i < nt; ++i)
				tr.data[i] = tan(tr.data[i]);
		break;
		case COSH:
			for (i = 0; i < nt; ++i)
				tr.data[i] = cosh(tr.data[i]);
		break;
		case SINH:
			for (i = 0; i < nt; ++i)
				tr.data[i] = sinh(tr.data[i]);
		break;
		case TANH:
			for (i = 0; i < nt; ++i)
				tr.data[i] = tanh(tr.data[i]);
		break;
		case DB:
                case NORM:
		      { float x, max;
			max = 0.0;
			for (i = 0; i < nt; ++i) {
				x = ABS (tr.data [i]);
				if (max < x) max = x;
			}
			if (max != 0.0)
				for (i = 0; i < nt; ++i) tr.data [i] /= max;
 
			if (iop == DB)  {
				for (i = 0; i < nt; ++i) {
					x = tr.data[i];
					tr.data[i] = (ABS(x) > 0) ?
					   20.0*SGN(x)*log10(ABS(x)) : 0;
				}
			}
		      }	/* end scope of x, max */
		      break;
		      default:  /* defensive programming */
			err("mysterious operation=\"%s\"", op);
		} /* end scope of i */

		puttr(&tr);

	} while (gettr(&tr));


	return EXIT_SUCCESS;
}
