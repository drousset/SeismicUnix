/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* SUVCAT: $Revision: 1.13 $ ; $Date: 1996/09/13 21:49:05 $	*/

#include "su.h"
#include "segy.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 								",
" SUVCAT - append one data set to another			",
" 								",
" suvcat data1 data2 >stdout					",
" 								",
" Required parameters:						",
" 	none							",
" 								",
" Optional parameters:						",
" 	none							",
" 								",
" Notes:							",
" Output = modified header of data1 then data1 then data2	",
" 								",
" This program vertically concatenates data2 onto data1, meaning",
" that each trace of data2 is appended to the corresponding	",
" trace of data1. To do a simple or horizontal concatenation,	",
" so that the traces of data2 simply follow the traces of data1,",
" use the Unix commmand						",
" 								",
"       cat data1 data2 > sdtout				",
NULL};

/* Credits:
 *	CWP: Jack K. Cohen, Michel Dietrich
 *
 * Trace header fields accessed:  ns
 * Trace header fields modified:  ns
 */
/**************** end self doc ***********************************/


segy intrace1, intrace2;

int
main(int argc, char **argv)
{
	FILE *fp1;	/* file pointer for first file		*/
	FILE *fp2;	/* file pointer for second file		*/
	int data2flag=0;/* return from gettr on data set #2	*/
	int itr = 0;	/* number of trace being processed	*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(2); /* two file args required */


	/* Open two files given as arguments for reading */
	fp1 = efopen(argv[1], "r");
	fp2 = efopen(argv[2], "r");


	/* Loop over the traces */
	while (fgettr(fp1, &intrace1) &&
				(data2flag = fgettr(fp2, &intrace2))) {
		int nt1 = intrace1.ns;
		int nt2 = intrace2.ns;
		int nt  = nt1+nt2;

		if (nt > SU_NFLTS)
			err("nt=%d exceeds SU_NFLTS=%d", nt, SU_NFLTS);
		
		memcpy( (void *) (intrace1.data + nt1),
				(const void *) intrace2.data, nt2*FSIZE); 
		intrace1.ns = nt;
		puttr(&intrace1);
		++itr;
	}

	/* See if both files exhausted; notice if fd1 exhausted, then
	   we don't do an fgettr on fd2 on the final pass above */
	if (!data2flag) {
		warn("%s still had traces when %s was exhausted",
						argv[1], argv[2]);
		warn("processed %d pairs of traces before EOF", itr);
	} else if (fgettr(fp2, &intrace2)) {
		warn("%s still had traces when %s was exhausted",
						argv[2], argv[1]);
		warn("processed %d pairs of traces before EOF", itr);
	}


	return EXIT_SUCCESS;
}
