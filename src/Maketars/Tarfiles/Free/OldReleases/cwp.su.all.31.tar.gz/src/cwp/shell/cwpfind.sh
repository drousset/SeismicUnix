#! /bin/sh
# /*********************** self documentation **********************/
# CWPFIND - look for files with patterns in CWPROOT/src/cwp/lib
#
# Usage: cwpfind  pattern_fragment
#        cwpfind -e exact_pattern
#
# /**************** end self doc ********************************/

# Copyright 1985 by Jack K. Cohen

ROOT=${CWPROOT}
BIN=$ROOT/bin
CWP=$ROOT/src/cwp

PATH=/bin:/usr/bin:/usr/ucb:$BIN
CWPLIB=$CWP/lib
PAGE_PROGRAM=more

cmd=`basename $0`
WHITE='[ 	]'

case $# in
1|2)	# OK
;;
*)
    	echo "CWPFIND - search for files with patterns in ../src/cwp/lib"
	echo
    	echo "Usage: $cmd keyword_fragment"
	echo "or:    $cmd -e exact_keyword"
	1>&2; exit 1
esac

option=fragment
word=
for i
do
	case $i in
	-e)
		option=wholeword
	;;
	-*)
    		echo "Illegal option: $i ($cmd [-e] word)"
		1>&2; exit 1
	;;
	*)
		word="$i"
	;;
	esac
done

echo "Scanning $CWPLIB ..."
case $option in
fragment)
	grep -li "$word" $CWPLIB/*.c
;;
*)
	egrep -l "$WHITE$word$WHITE|^$word$WHITE|$WHITE$word$|^$word$"\
		 $CWPLIB/*.c
;;
esac |
sed 's:.*/::'

exit 0
