/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* PSMANAGER: $Revision: 1.3 $ ; $Date: 1997/10/15 18:20:23 $	*/

#include "par.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 								",
" PSMANAGER - printer MANAGER for HP 4MV Laserjet PostScript 	",
" 								",
"   psmanager < stdin  [optional parameters] > stdout 		",
" 								",
" Required Parameters:						",
"  none 							",
" Optional Parameters:						",
" media=0	paper media  (US Letter default)		",
" 		=1       US Legal				",
" 		=2	 A4					",
" 		=3     	 11x17					",
" 								",
" orient=0	paper orientation (Portrait default)		",
"  		=1   	Landscape				",
" 								",
" tray=0	tray 	Cassette				",
"  		=1	Multi-Purpose slot			",
"  		=2	Lower Cassette				",
" 								",
" manual=0	no manual feed 					",
"  		=1     (Manual Feed)				",
" 								",
" Notes:							",
" The option manual=1 implies tray=1.				",
" This version tested for single page documents, only.		",
" 								",
NULL};

/*
 * Author:  John Stockwell
 */
/**************** end self doc ********************************/

/* Statically defined strings */
static char *letter = {"<</DeferredMediaSelection true /PageRegion [612 792] /ImagingBBox null>> setpagedevice"};
static char *legal = {"<</DeferredMediaSelection true /PageRegion [612 1008] /ImagingBBox null>> setpagedevice"};
static char *tabloid = {"<</DeferredMediaSelection true /PageRegion [792 1224] /ImagingBBox null>> setpagedevice"};
static char *a4 = {"<</DeferredMediaSelection true /PageRegion [595 842] /ImagingBBox null>> setpagedevice"};
static char *cass = {"<</DeferredMediaSelection true /MediaPosition 0>> setpagedevice"};
static char *lcass = {"<</DeferredMediaSelection true /MediaPosition 1>> setpagedevice"};
static char *mp = {"<</DeferredMediaSelection true /MediaPosition 3>> setpagedevice"};

/* Statically defined integer arrays */
static int letterdim[] = {612,792};
static int legaldim[] = {612,1008};
static int tabloiddim[] = {792,1224};
static int a4dim[] = {595,842};

/* Prototypes of subroutines used internally */
void pstitle(void);
void documentpapersizes(char *size);
void orientation(char *direction);
void endprolog(void);
void space(void);
void grestore(void);
void gsave(void);
void showpage(void);
void setuppage(char *pagestr,char *mediastr,int orient,int manual,
		char *slotstr, char *traystr, int *pagedim,int llx,int lly,int urx,int ury,
		float pllx,float plly,float purx,float pury);
void pagetrailer(int pages,int *pagedim,int orient,float pllx,
			float plly,float purx,float pury);


int main (int argc, char **argv)
{
	int media;		/* print media			*/
	int orient;		/* portrait or landscape	*/
	int tray;		/* paper tray			*/
	int manual;		/* manual feed			*/

	cwp_String mediastr=NULL;	/* media name		*/
	cwp_String orientstr=NULL;	/* orientation name	*/
	cwp_String traystr=NULL;	/* tray name		*/
	cwp_String slotstr=NULL;	/* input slot name	*/
	char line[BUFSIZ];	/* one line in input		*/

	int llx=0;		/* BoundingBox lower left  x 	*/
	int lly=0;		/*    ...      ...   ...   y	*/
	int urx=0;		/*    ...      upper right x	*/
	int ury=0;		/*    ...      ...   ...   y	*/
	int pages=1;		/*   pages in output		*/

	float fllx=0.;		/* BoundingBox lower left  x 	*/
	float flly=0.;		/*    ...      ...   ...   y	*/
	float furx=0.;		/*    ...      upper right x	*/
	float fury=0.;		/*    ...      ...   ...   y	*/

	float pllx;		/* PageBoundingBox parameters	*/
	float plly;		
	float purx;
	float pury;

	int pagedim[2];		/* dimensions of page		*/

	char *pagestr=NULL;	/* page style instructions	*/

	FILE *infp=stdin;	/* input file pointer		*/
	FILE *outfp=stdout;	/* output file pointer		*/
	FILE *tmpfp;		/* tempfile pointer 		*/

	/* Initialize getpar */
	initargs(argc,argv);
	requestdoc(1);

	/* Get parameters */
	if (!getparint("media",&media))		media = 0 ;
	if (!getparint("orient",&orient))	orient = 0;
	if (!getparint("tray",&tray))		tray = 0;
	if (!getparint("manual",&manual))	manual = 0;

	/* Set up the tray */
	if (tray==0) {
		slotstr="Cassette";
		traystr=cass;
	} else if (tray==1) {
		slotstr="MP";
		traystr=mp;
	} else if (tray==2) {
		slotstr="LargeCapacity";
		traystr=lcass;
	} else {
		err("Unsupported tray, %d", tray);
	}

	/* Manual feed */
	if (manual) {
		tray=1;
		traystr=mp;
	}

	/* Set up identifying strings for orientation */
	if (orient==0) {
		orientstr="Portrait";
	} else if (orient==1) {
		orientstr="Landscape";
	} else  {
		err("Unsupported orientation, %d", media);
	}

	/* Set up identifying strings for media types */
	if (media==0) {
		mediastr="Letter";
		pagestr=letter;
		if (orient==0){
			pagedim[0] = letterdim[0];
			pagedim[1] = letterdim[1];
		} else {
			pagedim[0] = letterdim[1];
			pagedim[1] = letterdim[0];
		}
	} else if (media==1) {
		mediastr="Legal";
		pagestr=legal;
		if (orient==0){
			pagedim[0] = legaldim[0];
			pagedim[1] = legaldim[1];
		} else {
			pagedim[0] = legaldim[1];
			pagedim[1] = legaldim[0];
		}
	} else if (media==2) {
		mediastr="A4";
		pagestr=a4;
		if (orient==0){
			pagedim[0] = a4dim[0];
			pagedim[1] = a4dim[1];
		} else {
			pagedim[0] = a4dim[1];
			pagedim[1] = a4dim[0];
		}
	} else if (media==3) {
		mediastr="Tabloid";
		pagestr=tabloid;;
		if (orient==0){
			pagedim[0] = tabloiddim[0];
			pagedim[1] = tabloiddim[1];
		} else {
			pagedim[0] = tabloiddim[1];
			pagedim[1] = tabloiddim[0];
		}
	} else  {
		err("Unsupported media selection, %d", media);
	}


	/* Open tempfile */
	tmpfp = etmpfile();
	rewind(tmpfp);

	/* Read input line by line and capture BoundingBox info  */
	while (fgets(line,BUFSIZ,infp)!=NULL){ 

		/* If the line begins with a % */
		if (line[0] == '%'){

			/* if BoundingBox */
			if (strstr(line,"%%BoundingBox:")!=NULL) {
	
				/* if  BoundingBox: (atend) skip to next line */
				if (strstr(line,"atend")!=NULL)
					continue;
	
				/* capture BoundingBox values */
				if (sscanf(line,"%*s %d %d %d %d",
					&llx,&lly,&urx,&ury)==4) {
	
					/* integers read */

				} else if (sscanf(line,"%*s %f %f %f %f",
						&fllx,&flly,&furx,&fury)==4) {
					/* read floats and convert */
					llx = NINT(fllx);
					lly = NINT(flly);
					urx = NINT(furx);
					ury = NINT(fury);
				} else {
					err("Error reading BoundingBox!");
				}

			}
		}
	
		/* Write line to tmpfile */
		fputs(line,tmpfp);
	}
	/* Rewind tempfile */
	rewind(tmpfp);

	/* Compute PageBoundingBox dimensions */
	pllx = (pagedim[0] - urx + llx)/2.0;
	plly = (pagedim[1] - ury + lly)/2.0;
	purx = urx - llx + pllx;
	pury = ury - lly + plly;

	/* begin creating PostScript wrapper */
	pstitle();

	/* DocumentPapersizes */
	documentpapersizes(mediastr);

	/* Orientation */
	orientation(orientstr);

	/* End Prolog */
	endprolog();

	/* Setup page */
	setuppage(pagestr,mediastr,orient,manual,slotstr,traystr,pagedim,llx,lly,urx,ury,pllx,plly,purx,pury);

	/* Write contents of tmpfile to outfp */
	while (fgets(line,BUFSIZ,tmpfp)!=NULL){ 
		fputs(line,outfp);
	}

	/* Page Trailer */
	pagetrailer(pages,pagedim,orient,pllx,plly,purx,pury);

	return EXIT_SUCCESS;
}



void pstitle(void) 
/**********************************************************************
pstitle - begin title portion of PostScript wrapper
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout, "%%!PS-Adobe-2.0\n");
	fprintf(stdout, "%%%%Title:\n");
	fprintf(stdout, "%%%%Creator:\n");
	fprintf(stdout, "%%%%CreationDate\n");
	fprintf(stdout, "%%%%For: john\n");
	fprintf(stdout, "%%%%DocumentFonts: (atend)\n");
	fprintf(stdout, "%%%%Pages: (atend) 1\n");
	fprintf(stdout, "%%%%BoundingBox: (atend)\n");

}

void documentpapersizes(char *size)
/**********************************************************************
documentpapersizes 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout, "%%%%DocumentPaperSizes: %s\n",size);
}

void orientation(char *direction)
/**********************************************************************
orientation 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout, "%%%%Orientation: %s\n",direction);
}

void endprolog(void)
/**********************************************************************
endprolog 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout,"/__CWPbdef {\n");
	fprintf(stdout,"    1 index where {\n");
	fprintf(stdout,"        pop pop pop\n");
	fprintf(stdout,"    } {\n");
	fprintf(stdout,"        bind def\n");
	fprintf(stdout,"    } ifelse\n");
	fprintf(stdout,"} bind def /__CWPRectPath {\n");
	fprintf(stdout,"    4 2 roll moveto 1 index 0 rlineto 0 exch rlineto neg 0 rlineto closepath\n");
	fprintf(stdout,"} __CWPbdef /__CWPProcessRectArgs {\n");
	fprintf(stdout,"    1 index type /arraytype eq {\n");
	fprintf(stdout,"        exch 0 4 2 index length 1 sub {\n");
	fprintf(stdout,"            dup 3 add 1 exch {\n");
	fprintf(stdout,"                1 index exch get exch\n");
	fprintf(stdout,"            } for 5 1 roll 5 index exec\n");
	fprintf(stdout,"        } for pop pop\n");
	fprintf(stdout,"    } {\n");
	fprintf(stdout,"        exec\n");
	fprintf(stdout,"    } ifelse\n");
	fprintf(stdout,"} __CWPbdef /rectfill {\n");
	fprintf(stdout,"    gsave newpath {\n");
	fprintf(stdout,"        __CWPRectPath fill\n");
	fprintf(stdout,"    } __CWPProcessRectArgs grestore\n");
	fprintf(stdout,"} __CWPbdef /rectclip {\n");
	fprintf(stdout,"    newpath {\n");
	fprintf(stdout,"        __CWPRectPath\n");
	fprintf(stdout,"    } __CWPProcessRectArgs clip newpath\n");
	fprintf(stdout,"} __CWPbdef\n");
	fprintf(stdout,"%%%%EndComments\n");
	fprintf(stdout,"\n");
	fprintf(stdout,"gsave\n");
	fprintf(stdout,"-20 -28 translate\n");
	fprintf(stdout," /__CWPbasematrix matrix currentmatrix def\n");
	fprintf(stdout,"grestore\n");
	fprintf(stdout,"%%%%EndProlog\n");
}



void space(void)
/**********************************************************************
space 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout,"\n");
}

void grestore(void)
/**********************************************************************
grestore 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout,"grestore\n");
}

void showpage(void)
/**********************************************************************
showpage 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout,"showpage\n");
}
void gsave(void)
/**********************************************************************
gsave 
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	fprintf(stdout,"gsave\n");
}

void setuppage(char *pagestr,char *mediastr,int orient,int manual,
		char *slotstr,char *traystr, int *pagedim,int llx,int lly,int urx,int ury,
		float pllx,float plly,float purx,float pury)
/**********************************************************************
setuppage 
**********************************************************************
Input:

char *pagestr		PostScript string for given page size
char *mediastr		PostScript string for identifying print media
int orient		=0 Portrait  =1 Landscape
int manual		=0 not manual  =1 manual feed
char *slotstr		PostScript string for given input slot
char *traystr		PostScript string identifying input tray
int *pagedim		Page dimensions for given page size
int llx			BoundingBox lower left x
int lly			BoundingBox lower left y
int urx			BoundingBox upper right x
int ury			BoundingBox upper right y
float pllx		PageBoundingBox lower left x
float plly		PageBoundingBox lower left y
float purx		PageBoundingBox upper right x
float pury		PageBoundingBox upper right y

Output:
Prints Postscript Page setup information to standard out
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	int ipllx,iplly,ipurx,ipury;


	/* Begin Setup */
	fprintf(stdout,"%%%%BeginSetup\n");
		
	/* Manual feed */
	if (manual) {
		fprintf(stdout,"%%%%BeginFeature: *ManualFeed True\n");
		space();
		space();
		fprintf(stdout,"<</ManualFeed true>> setpagedevice");
		fprintf(stdout,"%%%%EndFeature\n");
	}

	/* Input slot and tray */
	fprintf(stdout,"%%%%BeginFeature: *InputSlot %s\n",slotstr);
	
	space();
	fprintf(stdout,"%s\n",traystr);
	fprintf(stdout,"%%%%EndFeature\n");

	/* Set up the page size/ page region */
	fprintf(stdout,"%%%%BeginFeature: *PageRegion %s\n",mediastr);

	space();
	fprintf(stdout,"%s\n",pagestr);
	fprintf(stdout,"%%%%EndFeature\n");

	fprintf(stdout,"%%%%Feature: *Resolution 600dpi\n");
	fprintf(stdout,"%%%%EndFeature\n");

	fprintf(stdout,"%%%%EndSetup\n");
	space();
	space();

	fprintf(stdout,"%%%%Page: 1 1\n");
	
	/* Shift PageBoundingBox */
	ipllx = (int) pllx; ipurx = pagedim[0] - ipllx;
	iplly = (int) plly; ipury = pagedim[1] - iplly;

	fprintf(stdout,"%%%%PageBoundingBox: %d %d %d %d\n",
			ipllx,iplly,ipurx,ipury);

	fprintf(stdout,"%%%%PageFonts: (atend)\n");
	fprintf(stdout,"%%%%BeginPageSetup\n");

	/* Input slot and tray */
	fprintf(stdout,"%%%%BeginFeature: *InputSlot %s\n",slotstr);
	
	space();
	fprintf(stdout,"%s\n",traystr);
	fprintf(stdout,"%%%%EndFeature\n");

	/* manual feed */
	if (manual) {
		fprintf(stdout,"%%%%BeginFeature: *ManualFeed True\n");
		space();
		space();
		fprintf(stdout,"<</ManualFeed true>> setpagedevice");
		fprintf(stdout,"%%%%EndFeature\n");
	}

	/* page size/region */
	fprintf(stdout,"%%%%BeginFeature: *PageRegion %s\n",mediastr);
	space();
	space();

	fprintf(stdout,"%s\n",pagestr);
	fprintf(stdout,"%%%%EndFeature\n");
	fprintf(stdout,"/__CWPsheetsavetoken save def\n");

	/* orientation */
	if (orient) fprintf(stdout,"-90 rotate\n");
	if (orient) fprintf(stdout,"%d 0 translate\n",-pagedim[0]);

	fprintf(stdout,"%3.1f %3.1f translate\n",pllx,plly);
	gsave();
	fprintf(stdout,"-20 -28 translate\n");
	fprintf(stdout," /__CWPbasematrix matrix currentmatrix def\n");
	grestore();
	gsave();
	fprintf(stdout,"0 0 %d %d rectclip\n", (urx-llx),(ury-lly));
	fprintf(stdout,"%d %d translate\n",-llx,-lly);
	fprintf(stdout,"0 0 translate\n");
	fprintf(stdout,"%%%%EndPageSetup\n");
	gsave();
	fprintf(stdout,"%d %d %d %d rectclip\n",
			llx,lly,(urx-llx),(ury-lly));
	fprintf(stdout,"gsave 1 setgray %d %d %d %d rectfill grestore\n",
			llx,lly,(urx-llx),(ury-lly));

	fprintf(stdout,"userdict /_CWPPreviewSaveObject0 systemdict /save get exec put\n");
	fprintf(stdout,"/showpage {\n");
	space();    
	fprintf(stdout,"} def\n");

	fprintf(stdout,"%%%%BeginFile:\n");
}
	

void pagetrailer(int pages,int *pagedim,int orient,float pllx,
			float plly,float purx,float pury)
/**********************************************************************
pagetrailer
**********************************************************************
Author: John Stockwell, CWP, June 1996
**********************************************************************/
{
	int ipllx,iplly,ipurx,ipury;

	/* Shift PageBoundingBox */
	ipllx = (int) pllx; ipurx = pagedim[0] - ipllx;
	iplly = (int) plly; ipury = pagedim[1] - iplly;

	fprintf(stdout,"%%%%EndFile\n");
	fprintf(stdout,"clear userdict /_CWPPreviewSaveObject0 known {\n");
	fprintf(stdout,"    _CWPPreviewSaveObject0 systemdict /restore get exec\n");
	fprintf(stdout,"} if\n");
	grestore();
	grestore();
	showpage();
	fprintf(stdout,"__CWPsheetsavetoken restore\n");
	fprintf(stdout,"%%%%PageTrailer\n");
	fprintf(stdout,"%%%%Trailer\n");
	fprintf(stdout,"%%%%Pages: 1 %d\n",pages);

	if (orient)
		fprintf(stdout,"%%%%BoundingBox:%d %d %d %d\n",ipllx,iplly,ipury,ipurx);
	else
		fprintf(stdout,"%%%%BoundingBox:%d %d %d %d\n",ipllx,iplly,ipurx,ipury);
}

