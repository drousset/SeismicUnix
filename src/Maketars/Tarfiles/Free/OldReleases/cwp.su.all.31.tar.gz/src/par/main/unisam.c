/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

/* UNISAM: $Revision: 1.8 $ ; $Date: 1997/02/14 17:16:06 $	*/

#include "par.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 									",
" UNISAM - UNIformly SAMple a function y(x) specified as x,y pairs	",
" 									",
" unisam xin= yin= nout= [optional parameters] >binaryfile		",
" 									",
" Required Parameters:							",
" xin		 array of x values (number of xin = number of yin)	",
" yin		 array of y values (number of yin = number of xin)	",
" nout		 number of y values output to binary file		",
" 									",
" Optional Parameters:							",
" dxout=1.0	 output x sampling interval				",
" fxout=0.0	 output first x						",
" method=linear  =linear for linear interpolation (continuous y)	",
"		 =mono for monotonic cubic interpolation (continuous y')",
"		 =akima for Akima's cubic interpolation (continuous y') ",
"		 =spline for cubic spline interpolation (continuous y'')",
" isint=,,,	 where these sine interpolations to apply		",
" amp=,,,	 amplitude of sine interpolations			",
" phase0=,,,	 starting phase (defaults: 0,0,0,...,0)			",
" totalphase=,,, total phase (default pi,pi,pi,...,pi.)			",
" nwidth=0       apply window smoothing if nwidth>0                     ",
" 									",
NULL};
/*
 * AUTHOR:  Dave Hale, Colorado School of Mines, 07/07/89
 *          Zhaobo Meng, Colorado School of Mines, 
 * 	    added sine interpolation and window smoothing, 09/16/96 
 *
 * Remarks: In interpolation, suppose you need 2 pieces of 
 * 	    sine interpolation before index 3 to 4, and index 20 to 21
 *	    then set: isint=3,20. The sine interpolations use a sine
 *	    function with starting phase being phase0, total phase 
 *	    being totalphase (i.e. ending phase being phase0+totalphase
 *	    for each interpolation).
 * 	    
 */
/**************** end self doc ********************************/

int
main(int argc, char **argv)
{
	int nin,nout,iout;
	float dxout,fxout,*xin,*yin,(*yind)[4],*xout,*yout;
	char *method="linear";
	FILE *outfp=stdout;

	/* added by Z. Meng */
	int nsint;	/* number of sine interpolations to apply */
	int *isint=NULL;	/* the indices where sine interpolations to apply */
	float *amp=NULL;	/* the amplitude of sine interpolations */   
	float *phase0=NULL;	/* initial phase for each interpolation */
	float *totalphase=NULL;	/* total phase for sine interpolation */
	int ix0,ix1;     /* indices for left and right sine int points */
	float denorm;    /* denominator used */
	int ix,is,ip;    /* work indices */
        int nwidth;      /* number of samples in input */
        float *yout0;
	float sum;

	/* hook up getpar */
	initargs(argc,argv);
	requestdoc(0);

	/* get parameters */
	xin = alloc1float(countparval("xin"));
	yin = alloc1float(countparval("xin"));
	if ((nin=getparfloat("xin",xin))==0)
		err("Must specify xin!");
	if (getparfloat("yin",yin)!=nin) 
		err("Number of yins must equal number of xins!");
	if (!getparint("nout",&nout))
		err("Must specify nout!");
	dxout = 1.0;  getparfloat("dxout",&dxout);
	fxout = 0.0;  getparfloat("fxout",&fxout);
	getparstring("method",&method);

	/* allocate space for output */
	xout = ealloc1float(nout);
	yout = ealloc1float(nout);

	/* compute uniformly sampled xs */
	for (iout=0; iout<nout; iout++)
		xout[iout] = fxout+iout*dxout;

	/* if linear interpolation or only one input sample */
	if (method[0]=='l' || nin==1) {
		intlin(nin,xin,yin,yin[0],yin[nin-1],nout,xout,yout);

	/* else, if monotonic interpolation */
	} else if (method[0]=='m') {
		yind = (float (*)[4])ealloc1float(nin*4);
		cmonot(nin,xin,yin,yind);
		intcub(0,nin,xin,yind,nout,xout,yout);

	/* else, if Akima interpolation */
	} else if (method[0]=='a') {
		yind = (float (*)[4])ealloc1float(nin*4);;
		cakima(nin,xin,yin,yind);
		intcub(0,nin,xin,yind,nout,xout,yout);

	/* else, if cubic spline interpolation */
	} else if (method[0]=='s') {
		yind = (float (*)[4])ealloc1float(nin*4);;
		csplin(nin,xin,yin,yind);
		intcub(0,nin,xin,yind,nout,xout,yout);

	/* else, if unknown method specified */
	} else {
		err("%s is an unknown interpolation method!\n",method);
	}

	/* added by Z. Meng */
	if (!(nsint=countparval("isint"))) nsint=0;
        if (nsint>0 && nsint<nin-1) {
		isint=alloc1int(nsint);
		amp=alloc1float(nsint);
		phase0=alloc1float(nsint);
		totalphase=alloc1float(nsint);
	
		if (!getparint("isint",isint))
			err("Must specify %d isint values",nsint);
		if (!getparfloat("amp",amp))
			err("Must specity %d amp values",nsint);

		if (!getparfloat("phase0",phase0))
			for (is=0;is<nsint;is++)
				phase0[is]=0.0;
	
		if (!getparfloat("totalphase",totalphase))
			for (is=0;is<nsint;is++)
				totalphase[is]=PI;
		for (is=0;is<nsint;is++)
			if (totalphase[is]==0.0) 
				totalphase[is]=PI;	
	}

        for (is=0;is<nsint;is++) {
                if (isint[is]+1>=nin-1) break;
		ix0=(xin[isint[is]]-fxout)/dxout;
		ix1=(xin[isint[is]+1]-fxout)/dxout;
                denorm=(xin[isint[is]+1]-xin[isint[is]])/totalphase[is];
                for (ix=ix0+1;ix<ix1;ix++)
                        yout[ix]+=amp[is]*
                        sin(phase0[is]+(dxout*ix-xin[isint[is]]+fxout)/denorm);
        }

        if (!getparint("nwidth",&nwidth)) nwidth=0;
        nwidth=nwidth/2*2+1;  /*make it odd*/
        if (nwidth>1) {
                yout0=alloc1float(nout);
                for (ix=nwidth/2;ix<nout-nwidth/2;ix++) {
                        sum=0;
                        for (ip=-nwidth/2;ip<=nwidth/2;ip++)
                                sum+=yout[ix+ip];
                        yout0[ix]=sum/nwidth;
                }
                for (ix=nwidth/2;ix<nout-nwidth/2;ix++)
                        yout[ix]=yout0[ix];
        }

	/* output */
	efwrite(yout,sizeof(float),nout,outfp);

	return EXIT_SUCCESS;
}
