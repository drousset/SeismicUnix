/* Copyright (c) Colorado School of Mines, 1997.*/
/* All rights reserved.                       */

#include "su.h"
#include "segy.h"

/*********************** self documentation *****************************/
char *sdoc[] = {
"                                                                       ",
" SUPANELRPT - Report statistics for trace panels                       ",
"                                                                       ",
" supanelrpt <stdin >stdout [optional parameters]			",
"                                                                       ",
" Required parameters:                                                  ",
"       (none)                                                          ",
"                                                                       ",
" Optional parameters (with default values):                            ",
"                                                                       ",
"	key=(none)	trace header field defining sorted order for    ",
"			panels.  When a keyword is supplied, a new panel",
"			begins whenever its value in the header changes.",
"	panelsz=24	maximum number of traces reported per panel.  If",
"			no key is given, this value is the size of each ",
"			panel.  0 => max is limited by memory size.     ",
"	count=10	max count of panels to report.                  ",
"			=0 for entire input.                            ",
"	skip=0		number of panels to skip before first report.   ",
"	incr=1		increment between reported panels.              ",
"	nt=(from header) number of samples per trace (must match data). ",
"	stats=0		report panel statistics: max,min,rms,mutes,etc. ",
"			=1 report amplitude ranks (expensive).          ",
"			=2 report both statistics and ranks.            ",
"	headers=1	print non-zero fields in first header of each   ",
"			reported panel.  0 => no header print.          ",
"                                                                       ",
" Note:                                                                 ",
"	Report goes to stdout.  There is no seismic output.             ",
"	Traces with the 'mark' field set are treated as dead.           ",
"                                                                       ",
NULL};

/* Credits:
 *      Cray Research: Ted Clee				June 1996
 *
 *
 * Trace header fields accessed: ns, trid, mark, (key)
 */
/**************** end self doc *******************************************/

#define  MAXTR	1024
#define  EPS	1.0e-30
#define  fabsf(x)	((x<0)?-x:x)

/* subroutine prototypes */
static void prt_ranks(int *rank, int nt, int fsize);
int cmp_indirect(int *r, int *s);

segy tr;
float *data;	/* trace data for ranking; global to use system qsort */


main(int argc, char **argv)
{
	int nt, panelsz, count, skip, incr, stats, headers;
	cwp_String key; /* trace hdr keyword defining panels    */

	Value val;	/* current trace keyword value	*/
	Value valp;	/* previous trace keyword value	*/
	int ipanel=-1;	/* panel counter		*/
	int nreport=0;	/* report counter		*/
	int igot=1;	/* flag for trace read OK	*/
	int new=1;	/* flag for new panel		*/
	int ixreport=0;	/* flag for reporting on current panel	*/
	int iptct=0;	/* trace count in current panel 	*/
	int *rank;	/* permuted indices for indirect sort	*/

        /* Initialize */
        initargs(argc, argv);
        requestdoc(1);

        /* Get nt from first trace */
        if (!gettr(&tr)) err("can't get first trace");
        if (!getparint("nt", &nt))  nt = (int) tr.ns;

        /* Get parameters */
	if (!getparstring("key", &key))  key = NULL;
	if (!getparint("panelsz", &panelsz))  panelsz = 24;
        if (!getparint("count", &count))  count = 10;
        if (!getparint("skip", &skip))  skip = 0;
        if (!getparint("incr", &incr))  incr = 1;
        if (!getparint("stats", &stats))  stats = 0;
        if (!getparint("headers", &headers))  headers = 1;

	if (key != NULL) gethdval( &tr, key, &val );
	if (stats > 0) {
		if (panelsz == 0) panelsz = MAXTR;
		data = ealloc1float( MAXTR*nt );
		rank = ealloc1int  ( MAXTR*nt );
	}
	if (panelsz <= 0) panelsz = 999999999;
	if (count <= 0) count = 999999999;

	/* Main loop over traces */
	do {
	    /*  Variables for panel  */
	    int	ndata, ndead, nlive, new, ixreport;
	    int itmin, itmax, ipmin, ipmax, mmin, mmax, pcount;
	    int i, mute, imin, imax, scount;
	    float samp=0., sumabs, sumsq, tmin, tmax;
	    float *tdata, pmin, pmax, pabs, psq;

	    /*  Read and count a trace  */
	    if (ipanel >= 0) {
		if ( igot = gettr(&tr) )  iptct++;
	    }

	    /*  New panel?  */
	    new = (ipanel==-1) || (!igot) ;
	    if (!new) {
		if (key==NULL) 
			new = (iptct > panelsz);
		else {
			gethdval( &tr, key, &val );
			new = (0 != valcmp(hdtype(key),val,valp));
		}
	    }

	    /*  Handle the panel change  */
	    if (new) {
		/*  Close out report on previous panel  */
		if (ixreport) {
		    double avg, rms;

		    nreport++;
		    avg = pabs/(pcount+EPS);
		    rms = sqrt(psq/(pcount+EPS));
		    printf( "%d live traces, %d dead traces. ",
				nlive, ndead);
		    printf( " Leading zero samples: min %d, max %d\n",
				mmin, mmax);
		    if (stats!=1) {
		        printf(
			"avg amp= % #9.4G  min= %#.4G at sample %d, trace %d\n",
				avg,pmin,itmin,ipmin);
		        printf(
			"rms amp= % #9.4G  max= %#.4G at sample %d, trace %d\n",
				rms,pmax,itmax,ipmax);
		    }
		    if (stats>0) prt_ranks( rank, ndata, FSIZE);
		}

		/*  Check for end  */
		if (!igot || nreport>=count)  break;

		/*  Indicate new panel  */
		ipanel++;
		iptct = 1;
		valp = val;
		ixreport = (ipanel>=skip) && ((ipanel-skip)%incr==0);
		if (ixreport) {
		    /*  Print for new panel  */
		    if (key==NULL) printf( "\npanel %d:\n",ipanel+1);
		    else {
			printf( "\npanel %d: %s= ",ipanel+1,key);
			printfval( hdtype(key), val);
			putchar( '\n' );
		    }
		    if (headers) printheader( &tr );
		    /*  Initialize stats for reported panel  */
		    pmin = pmax = 0.0;
		    ipmin = ipmax = 0;
		    itmin = itmax = 0;
		    ndead = nlive = 0;
		    mmin = nt;
		    mmax = -1;
		    pcount = 0;
		    pabs = psq = 0.0;
		    tdata = data;
		    ndata = 0;
		}
	    }

	    /*  Main trace processing  */
	    if (ixreport && iptct<=panelsz) {
		if (tr.trid==2 || tr.mark!=0) ndead++;
		else {		/*  Examine the trace  */
		    mute = -1;
		    sumabs = sumsq = 0.0;
		    scount = 0;
		    tmin = tmax = 0.0;

		    for (i=0; i<nt; i++) {
			samp = tr.data[i];
				/*  Skip mute (leading zeroes)  */
			if (mute==(i-1) && fabsf(samp)<EPS ) mute = i;
			else {
			    if (stats != 1) {	/*  Calculate trace stats */
			        scount++;
			        sumabs += fabsf(samp);
			        sumsq += samp*samp;
			        if      (samp<tmin) { tmin=samp; imin=i; }
			        else if (samp>tmax) { tmax=samp; imax=i; }
			    }
			}
		    }
		    if (++mute >= nt) ndead++;  /* whole trace was zero */
		    else {	/*  Update panel stats  */
			if (mmin>mute) mmin = mute;
			if (mmax<mute) mmax = mute;
			if (stats != 1) {
			    pcount += scount;
			    pabs += sumabs;
			    psq  += sumsq;
			    if (tmin<pmin)
				{ pmin=tmin; ipmin=iptct; itmin=imin; }
			    if (tmax>pmax)
				{ pmax=tmax; ipmax=iptct; itmax=imax; }
			}
			nlive++;
				/*  Save trace data for ranking  */
			if (stats>0) {
			    memcpy( (void *)tdata, (void *)tr.data, nt*FSIZE);
			    tdata += nt;
			    ndata += nt;
			}
		    }
		}	/*  trace exam  */
	    }
	} while (igot);
	
	free1(data);
	free1(rank);
	
        return EXIT_SUCCESS;
}

/* PRT_RANKS - fprint some sample ranks */
static void prt_ranks(int *rank, int nt, int fsize)
{
	int i, r[6] = {0,5,45,55,95,100};
	double d[6];
	
	for (i = 0; i < nt; ++i)  rank[i] = i;
	qsort(rank, nt, fsize, (int (*)()) cmp_indirect);
	
	for (i=0; i<6; i++) {
		r[i] = r[i]*.01*(nt-1);
		d[i] = data[ rank[r[i]] ];
	}

	printf( 
	    "  bottom     5%%       45%%       55%%       95%%       top\n");
	printf( 
	    " % #8.2E % #8.2E % #8.2E % #8.2E % #8.2E % #8.2E\n",
	    d[0], d[1], d[2], d[3], d[4], d[5]);

}


/* Comparison function for qsort */
int cmp_indirect(int *r, int *s)
{
	float diff = data[*r] - data[*s];

	if      (diff > 0.0)	return(1);
	else if (diff < 0.0)	return(-1);
	else  /* diff == 0 */	return(0);
}

