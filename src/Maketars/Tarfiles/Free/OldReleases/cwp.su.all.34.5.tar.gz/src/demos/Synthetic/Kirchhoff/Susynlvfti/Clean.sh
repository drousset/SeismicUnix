#! /bin/sh

rm *.eps junk*
