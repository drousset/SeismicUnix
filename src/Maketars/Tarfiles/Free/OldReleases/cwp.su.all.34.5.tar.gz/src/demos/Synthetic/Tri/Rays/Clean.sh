#! /bin/sh

rm *.eps *.data junk* outpar
