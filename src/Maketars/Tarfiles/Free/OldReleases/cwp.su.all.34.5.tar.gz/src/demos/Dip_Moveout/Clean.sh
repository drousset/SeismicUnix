#! /bin/sh

rm cmgsynhti *.eps dmocmghti
