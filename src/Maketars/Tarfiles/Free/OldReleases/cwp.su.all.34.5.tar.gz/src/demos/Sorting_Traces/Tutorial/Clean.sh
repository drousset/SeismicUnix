#! /bin/sh

indata=data.seis
outdata1=data.fullfold
outdata2=data.sortdown
outdata3=data.unsort
outdata4=data.recgather
outdata5=data.stack
outdata6=data.near
outdata7=data.far

rm -f $indata $outdata1 $outdata2 $outdata3\
	$outdata4 $outdata5 $outdata6 $outdata7

exit
