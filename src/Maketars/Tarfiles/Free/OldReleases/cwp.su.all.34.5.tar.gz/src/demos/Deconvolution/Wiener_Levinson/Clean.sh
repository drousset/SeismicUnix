#! /bin/sh
# Clean created data files

rm -f modeldata deconpanel *.eps junk* *.ps traces INSTALL

exit
