#! /bin/sh


rm *.grid *.su
