#! /bin/sh

rm *.v junk*
