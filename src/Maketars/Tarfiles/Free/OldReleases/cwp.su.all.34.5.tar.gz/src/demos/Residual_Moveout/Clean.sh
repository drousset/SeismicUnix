#! /bin/sh

rm  *data* *file* mpicks*

