#! /bin/sh

rm junk*
