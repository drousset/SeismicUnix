#! /bin/sh

rm -f  data3d.su temp

exit
