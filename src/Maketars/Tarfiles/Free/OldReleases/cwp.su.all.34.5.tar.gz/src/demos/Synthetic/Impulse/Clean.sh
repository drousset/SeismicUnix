#! /bin/sh
# Clean created data files

rm -f *.eps

exit
