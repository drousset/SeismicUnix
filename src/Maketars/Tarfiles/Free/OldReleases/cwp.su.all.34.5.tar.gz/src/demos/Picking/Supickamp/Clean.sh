#! /bin/sh
# set -x

# Clean-up shell for  supickamp demos
#    Andreas Rueger, Feb 18,1997


temp=pickdata.bin
mouse=window.data

rm $temp $mouse pick.info
