#! /bin/sh
# Clean created data files

cd Psmerge ; Clean.sh

exit
