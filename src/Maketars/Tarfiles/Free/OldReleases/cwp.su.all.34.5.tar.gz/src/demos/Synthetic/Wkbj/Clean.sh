#! /bin/sh
# Clean up residue from runs


rm -f sfile tfile afile bfile  data.v *.eps
