#! /bin/sh

rm -f Esd* *.data* error input* noise* p* rand* rand* rel* rtau* sig* stau*
