#! /bin/sh

rm junk*

exit 0
