#! /bin/sh

rm -f info* pressure* vertical* radial*
