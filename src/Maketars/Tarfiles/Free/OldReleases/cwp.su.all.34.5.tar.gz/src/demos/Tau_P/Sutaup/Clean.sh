#! /bin/sh

rm *.su junk*
