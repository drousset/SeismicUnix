#! /bin/sh

rm hold* *.ps *.eps record* divstack stack


