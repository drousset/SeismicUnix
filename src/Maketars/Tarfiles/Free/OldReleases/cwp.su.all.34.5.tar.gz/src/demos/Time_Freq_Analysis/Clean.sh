#! /bin/sh
# Clean created data files

rm -f vibrodata.* recon.* *.eps

exit 0
