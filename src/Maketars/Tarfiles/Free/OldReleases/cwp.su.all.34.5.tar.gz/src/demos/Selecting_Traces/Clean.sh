#! /bin/sh
# clean up files made by demo

rm -f modeldata tmp
rm -f *.eps

exit
