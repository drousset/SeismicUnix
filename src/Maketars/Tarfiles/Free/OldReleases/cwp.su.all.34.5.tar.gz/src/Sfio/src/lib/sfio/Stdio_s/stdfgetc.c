/* Copyright (c) Colorado School of Mines, 2000.*/
/* All rights reserved.                       */

#include	"sfhdr.h"
#include	"stdio.h"

#if __STD_C
int _stdfgetc(FILE* f)
#else
int _stdfgetc(f)
FILE*	f;
#endif
{
	return sfgetc(f);
}
