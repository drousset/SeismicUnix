/* Copyright (c) Colorado School of Mines, 2000.*/
/* All rights reserved.                       */

#include	"vthdr.h"

Vtextern_t	_Vtextern;
Vtonce_t	_Vtonce = VTONCE_INITDATA;
