/* Copyright (c) Colorado School of Mines, 2000.*/
/* All rights reserved.                       */

#include	"sfstdio.h"

/*	Get current stream position.
**	Written by Kiem-Phong Vo.
*/

#if __STD_C
int fgetpos(reg FILE* f, reg fpos_t* pos)
#else
int fgetpos(f, pos)
reg FILE*	f;
reg fpos_t*	pos;
#endif
{
	reg Sfio_t*	sf;

	if(!(sf = SFSTREAM(f)))
		return -1;
	return (*pos = (fpos_t)sfseek(sf, (Sfoff_t)0, SEEK_CUR|SF_SHARE)) >= 0 ? 0 : -1;
}
