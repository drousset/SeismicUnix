/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

/* SUMIGPREFD: $Vision: 1.00 $ ; $Date: 1998/05/04 18:16:33 $       */

#include "su.h"
#include "segy.h"
#include "header.h"
#include <signal.h>
/* #include <time.h> */


/*********************** self documentation ******************************/
char *sdoc[] = {
"                                                                       ",
"SUMIGPREFD --- The 2-D prestack common-shot 45-90 degree   		",
"                     finite-difference migration.       		",
"Usage:                                                                 ",
"sumigprefd <indata >outfile [parameters] 	                        ", 
"                                                                       ",
"Required Parameters:                                                   ",  
"                                                                       ",
"nxo=           number of total horizontal output samples               ",
"nxshot=        number of shot gathers to be migrated                   ",
"nz=            number of depth sapmles                                 ",
"dx=            horizontal sampling interval                            ",   
"dz=            depth sampling interval                                 ",
"vfile=         velocity profile, it must be binary format.             ",
"The structure of such a file is vfile[iz][ix], the x-direction is the  ",   
"fastest direction instead of z-direction, such a structure is quite    ",
"convenient for the downward continuation type migration algorithm.     ",
"Since most of the velocity file is in vfile[ix][iz] structure, you can ",
"use 'transp' in SU to transpose them into vfile[iz][ix] structure.     ",
"                                                                       ",  
"Optional Parameters:                                                   ",
"                                                                       ",
"dip=79       the maximum dip to migrate, it can be 45,65,79,80,87,89,90", 
"	      The computation cost is 45=65=79<80<87<89<90		",
"                                                                       ",
"Fmax=25      the peak frequency of Ricker wavelet used as source wavelet",
"                                                                       ",
"f1=5,f2=10,f3=40,f4=50         frequencies to build a Hamming window   ",
"                                                                       ",
"lpad=9999,rpad=9999            number of zero traces padded on both    ",
"sides of depth section to determine the migration aperature, the default", 
"values are using the full aperature.                                   ",
NULL};

/*
 * Credits: CWP, Baoniu Han, bhan@dix.mines.edu, April 19th, 1998
 *
 *
 * Trace header fields accessed: ns, dt, delrt, d2
 * Trace header fields modified: ns, dt, delrt
 */

/**************** end self doc *******************************************/

/* Prototypes for subroutines used internally */
float * ricker(float Freq,float dt,int *Npoint);

void retris(complex *data,complex *a,complex *c,complex *b,complex
                endl,complex endr, int nx, complex *d);

void fdmig( complex **cp, int nx, int nw, float *v,float fw,float
                dw,float dz,float dx,float dt,int dip);
segy tr;


/* static time_t t1,t2; */

int main (int argc, char **argv)
{
	int nt;			/* number of time samples */
	int nz;			/* number of migrated depth samples */
	int nx,nxshot,oldsx;	/* number of midpoints 	*/
	int iz,iw,ix,it;	/* loop counters 	*/
	int ntfft;		/* fft size		*/
	int nw,truenw;		/* number of wave numbers */	
	int dip=79;		/* dip angle	*/

	/*prestack goes here*/
	float sx,gxmin,gxmax; /*source and geophone location*/
	int isx,nxo,ifx=0;	/*index for source and geophone*/	
	int ix1,ix2,ix3,ixshot; /*dummy index*/
	int lpad,rpad; /*padding on both sides of the migrated section*/
	int flag=1; /*flag control for feet or meter*/

	float *wl,*wtmp;
        float Fmax=25;
	float f1,f2,f3,f4;
	int nf1,nf2,nf3,nf4;
	int ntw;

	float dt=0.004,dz;	/* time and depth sampling interval 	*/
	float dw;		/* frequency  sampling interval */
	float fw;		/* first frequency 		*/
	float w;		/* frequency		*/
	float dx;		/* spatial sampling interval	*/
	float **p,**cresult;	/* input, output data		*/
	float v1;		/*average velocity*/
	double kz2;	
	float **v,**vp;		/*pointer for the velocity profile*/
	complex cshift2;
	complex *wlsp,**cp,**cp1,**cq;	/*complex input,output*/
	char *vfile="";		/* name of file containing velocities */
	FILE *vfp;

	/* hook up getpar to handle the parameters */
	initargs(argc,argv);
	requestdoc(1);

        /* get optional parameters */
        if (!getparint("nz",&nz)) err("nz must be specified");
        if (!getparfloat("dz",&dz)) err("dz must be specified");
        if (!getparstring("vfile", &vfile)) err("vfile must be specified");
        if (!getparint("nxo",&nxo)) err("nxo must be specified");
        if (!getparint("nxshot",&nxshot)) err("nshot must be specified");
        if (!getparfloat("Fmax",&Fmax)) err("Fmax must be specified");  
        if (!getparfloat("f1",&f1)) f1 = 10.0;
        if (!getparfloat("f2",&f2)) f2 = 20.0;
        if (!getparfloat("f3",&f3)) f3 = 40.0;
        if (!getparfloat("f4",&f4)) f4 = 50.0;
        if (!getparint("lpad",&lpad)) lpad=9999;
        if (!getparint("rpad",&rpad)) rpad=9999;
        if (!getparint("flag",&flag)) flag=1;
        if (!getparint("dip",&dip)) dip=79;

	cresult = alloc2float(nz,nxo);
	vp=alloc2float(nxo,nz);

	/*load velicoty file*/
	vfp=efopen(vfile,"r");
	efread(vp[0],FSIZE,nz*nxo,vfp);
	efclose(vfp);

	for(ix=0;ix<nxo;ix++)
	for(iz=0;iz<nz;iz++)
	cresult[ix][iz]=0.0;
			

	/* get info from first trace */
loop:
/*	time(&t1); */

	if (!gettr(&tr))  err("can't get first trace");
	nt = tr.ns;

	/* let user give dt and/or dx from command line */
	if (!getparfloat("dt", &dt)) {
		if (tr.dt) { /* is dt field set? */
			dt = ((double) tr.dt)/1000000.0;
		} else { /* dt not set, assume 4 ms */
			dt = 0.004;
			warn("tr.dt not set, assuming dt=0.004");
		}
	}
	if (!getparfloat("dx",&dx)) {
		if (tr.d2) { /* is d2 field set? */
			dx = tr.d2;
		} else {
			dx = 1.0;
			warn("tr.d2 not set, assuming d2=1.0");
		}
	}

	sx=tr.sx;
	isx=sx/dx;
	gxmin=gxmax=tr.gx;
	oldsx=sx;
 
        /* determine frequency sampling interval*/
        ntfft = npfar(nt);
        nw = ntfft/2+1;
        dw = 2.0*PI/(ntfft*dt);

        /*compute the index of the frequency to be migrated*/
        fw=2.0*PI*f1;
        nf1=fw/dw+0.5;
                 
        fw=2.0*PI*f2;
        nf2=fw/dw+0.5;

        fw=2.0*PI*f3;
        nf3=fw/dw+0.5;

        fw=2.0*PI*f4;
        nf4=fw/dw+0.5;  

        /*the number of frequency to migrated*/
        truenw=nf4-nf1+1;
        fw=0.0+nf1*dw;
        warn("nf1=%d nf2=%d nf3=%d nf4=%d nw=%d",nf1,nf2,nf3,nf4,truenw);

        /* allocate space */
        wl=alloc1float(ntfft);
        wlsp=alloc1complex(nw);

        /*generate the Ricker wavelet*/
        wtmp=ricker(Fmax,dt,&ntw);

        for(it=0;it<ntfft;it++)
        wl[it]=0.0;  
        
        for(it=0;it<ntw;it++)
        wl[it]=wtmp[it];
        free1float( wtmp);

        pfarc(-1,ntfft,wl,wlsp);

        /* allocate space */
        p = alloc2float(ntfft,nxo);
        cq = alloc2complex(nw,nxo);
	

        for (ix=0; ix<nxo; ix++)
                for (it=0; it<ntfft; it++)
                        p[ix][it] = 0.0;


        /*read in a single shot gather*/
        ix=tr.gx/dx;
        memcpy( (void *) p[ix], (const void *) tr.data,nt*FSIZE);

	nx = 0;

        while(gettr(&tr)){
                        int igx;

                        if(tr.sx!=oldsx){ fseek(stdin,(long)(-240-nt*4),SEEK_CUR); break;}
                        igx=tr.gx/dx;
                        memcpy( (void *) p[igx], (const void *) tr.data,nt*FSIZE);

                        if(gxmin>tr.gx)gxmin=tr.gx;
                        if(gxmax<tr.gx)gxmax=tr.gx;
                        nx++;
                        oldsx=tr.sx;
                        }

        warn("sx %f , gxmin %f  gxmax %f",sx,gxmin,gxmax);

        /*transform the shot gather from time to frequency domain*/
        pfa2rc(1,1,ntfft,nxo,p[0],cq[0]);


        /*compute the most left and right index for the migrated section*/
        ix1=sx/dx;
        ix2=gxmin/dx;
        ix3=gxmax/dx;

        if(ix1>=ix3)ix3=ix1;
        if(ix1<=ix2)ix2=ix1;

        ix2-=lpad;
        ix3+=rpad;
        if(ix2<0)ix2=0;
        if(ix3>nxo-1)ix3=nxo-1;

        /*the total traces to be migrated*/
        nx=ix3-ix2+1;
	nw=truenw;

        /*allocate space for velocity profile within the aperature*/
        v=alloc2float(nx,nz);   
        
        for(iz=0;iz<nz;iz++)
        for(ix=0;ix<nx;ix++){
        v[iz][ix]=vp[iz][ix+ix2];
        }


        /*allocate space*/
        cp = alloc2complex(nx,nw);
        cp1 = alloc2complex(nx,nw);

        /*transpose the frequency domain data from data[ix][iw] to data[iw][ix] and
        apply a Hamming at the same time*/

        for (ix=0; ix<nx; ix++)
        for (iw=0; iw<nw; iw++){

        float tmpp=0.0,tmppp=0.0;

	if(iw>=(nf1-nf1)&&iw<=(nf2-nf1)){
	tmpp=PI/(nf2-nf1);tmppp=tmpp*(iw-nf1)-PI;tmpp=0.54+0.46*cos(tmppp);
        cp[iw][ix]=crmul(cq[ix+ix2][iw+nf1],tmpp);}
        else{
	if(iw>=(nf3-nf1)&&iw<=(nf4-nf1)){
	tmpp=PI/(nf4-nf3);tmppp=tmpp*(iw-nf3);tmpp=0.54+0.46*cos(tmppp);
        cp[iw][ix]=crmul(cq[ix+ix2][iw+nf1],tmpp);}
        else{
	cp[iw][ix]=cq[ix+ix2][iw+nf1];}
        }
	cp1[iw][ix]=cmplx(0.0,0.0);
	}

        ix=sx/dx-ifx;
	ixshot=ix;
        warn("ix %d",ix);

        for(iw=0;iw<nw;iw++){
        cp1[iw][ix-ix2]=wlsp[iw+nf1];
        }

                        
        free2float(p);
        free2complex(cq);
        free1float(wl);
        free1complex(wlsp);


        /*if the horizontal spacing interval is in feet, convert it to meter*/
        if(!flag)
        dx*=0.3048;


	/* loops over depth */
	for(iz=0;iz<nz;++iz){

        /*the imaging condition*/
        for(ix=0;ix<nx;ix++){
        for(iw=0,w=fw;iw<nw;w+=dw,iw++){   
                complex tmp;
                float ratio=10.0;
                
                if(fabs(ix+ix2-ixshot)*dx<ratio*iz*dz)
                tmp=cmul(cp[iw][ix],cp1[iw][ix]);
                else tmp=cmplx(0.0,0.0);  
                cresult[ix+ix2][iz]+=tmp.r/ntfft;
        }
        }

/* anothe imaging condition, slightly different from the above one, but quite
slow*/
        
/*
        for(iw=0,w=fw;iw<nw;w+=dw,iw++){
                float kk=0.0;
                complex tmp;
                float ratio=1.5; 
                if(dip<80)ratio=1.5;
                else ratio=1.5;
        
                for(ix=0;ix<nx;ix++){     
                kk+=(pow(cp1[iw][ix].i,2.0)+pow(cp1[iw][ix].r,2.0))/nx;
                }
         
                for(ix=0;ix<nx;ix++){
                tmp=cmul(cp[iw][ix],cp1[iw][ix]);

                if(fabs(ix-ixshot)*dx<ratio*iz*dz||ixshot-ix<0 )

                tmp=crmul(tmp,1.0/(kk+1.0e-10));
  
                else tmp=cmplx(0.0,0.0);
                
                cresult[ix+ix2][iz]+=tmp.r/ntfft;
        
                }
                }
*/      
                
                /*get the average velocity*/ 
                v1=0.0;
                for(ix=0;ix<nx;++ix)
                {v1+=v[iz][ix]/nx;}

                /*compute time-invariant wavefield*/
                for(ix=0;ix<nx;++ix)
                for(iw=0,w=fw;iw<nw;w+=dw,++iw) {
                        kz2=-(1.0/v1)*w*dz;
                        cshift2=cmplx(cos(kz2),sin(kz2));
                        cp[iw][ix]=cmul(cp[iw][ix],cshift2);
                        cp1[iw][ix]=cmul(cp1[iw][ix],cshift2);
                }

                /*wave-propagation using finite-difference method*/
                fdmig( cp, nx, nw,v[iz],fw,dw,dz,dx,dt,dip);
                fdmig( cp1,nx, nw,v[iz],fw,dw,dz,dx,dt,dip);

                /*apply thin lens term here*/
                for(ix=0;ix<nx;++ix)
                for(iw=0,w=fw;iw<nw;w+=dw,++iw){
                        kz2=-(1.0/v[iz][ix]-1.0/v1)*w*dz;
                        cshift2=cmplx(cos(kz2),sin(kz2));
                        cp[iw][ix]=cmul(cp[iw][ix],cshift2);
                        cp1[iw][ix]=cmul(cp1[iw][ix],cshift2);
                }

}

free2complex(cp);
free2complex(cp1);
free2float(v);

nxshot--;

/* time(&t2);
warn("\n %d nxshot has been finished in %f seconds",nxshot,difftime(t2,t1));
*/

if(nxshot)goto loop;


	/* restore header fields and write output */
	for(ix=0; ix<nxo; ix++){
                tr.ns = nz ;
                tr.dt = dz*1000000.0 ;
                tr.d2 = dx;
                tr.offset = 0; 
                tr.cdp = tr.tracl = ix;
		memcpy( (void *) tr.data, (const void *) cresult[ix],nz*FSIZE);
		puttr(&tr);
	}
	

	return EXIT_SUCCESS;	

}



float * ricker(float Freq,float dt,int *Npoint)
{
int i;/* they are the dummy counter*/
float Bpar,t,u,*Amp;
int Np1,N;
        
if(Freq==0.0)Freq=30.0;
if(dt==0.0)dt=0.004;
Bpar=sqrt(6.0)/(PI*Freq);
N=ceil(1.35*Bpar/dt);
Np1=N;
*Npoint=2*N+1;
         
Amp=alloc1float(*Npoint);
        
Amp[Np1]=1.0;
  
for(i=1;i<=N;i++)
{
t=dt*(float)i;
u=2.0*sqrt(6.0)*t/Bpar;
Amp[Np1+i]=Amp[Np1-i]=0.5*(2.0-u*u)*exp(-u*u/4.0);
}

return Amp;

}

void fdmig( complex **cp, int nx, int nw, float *v,float fw,float
        dw,float dz,float dx,float dt,int dip)
{
	int iw,ix,step=1;
	float *s1,*s2,w,coefa[5],coefb[5],v1,vn,trick=0.1;
	complex cp2,cp3,cpnm1,cpnm2;
        complex a1,a2,b1,b2;
        complex endl,endr;
        complex *data,*d,*a,*b,*c;

        s1=alloc1float(nx);
        s2=alloc1float(nx);

        data=alloc1complex(nx);
        d=alloc1complex(nx);
        a=alloc1complex(nx);
        b=alloc1complex(nx);
        c=alloc1complex(nx);

        if(dip==45){
        coefa[0]=0.5;coefb[0]=0.25; 
        step=1;
        }
        
        if(dip==65){
        coefa[0]=0.478242060;coefb[0]=0.376369527;
        step=1;
        }
        
        if(dip==79){
        coefa[0]=coefb[0]=0.4575;
        step=1;
        }

        if(dip==80){
        coefa[1]=0.040315157;coefb[1]=0.873981642;
        coefa[0]=0.457289566;coefb[0]=0.222691983;
        step=2;
        }
        
        if(dip==87){
        coefa[2]=0.00421042;coefb[2]=0.972926132;
        coefa[1]=0.081312882;coefb[1]=0.744418059;
        coefa[0]=0.414236605;coefb[0]=0.150843924;
        step=3;
        }
         
        if(dip==89){
        coefa[3]=0.000523275;coefb[3]=0.994065088;
        coefa[2]=0.014853510;coefb[2]=0.919432661;
        coefa[1]=0.117592008;coefb[1]=0.614520676;
        coefa[0]=0.367013245;coefb[0]=0.105756624;
        step=4;
        }

        if(dip==90){
        coefa[4]=0.000153427;coefb[4]=0.997370236;
        coefa[3]=0.004172967;coefb[3]=0.964827992;
        coefa[2]=0.033860918;coefb[2]=0.824918565;
        coefa[1]=0.143798076;coefb[1]=0.483340757;
        coefa[0]=0.318013812;coefb[0]=0.073588213;
        step=5;
	}

        v1=v[0];vn=v[nx-1];

loop:
         
step--;

        for(iw=0,w=fw;iw<nw;iw++,w+=dw){

                if(fabs(w)<=1.0e-10)w=1.0e-10/dt; 

                for(ix=0;ix<nx;ix++){
                        s1[ix]=(v[ix]*v[ix])*coefb[step]/(dx*dx*w*w)+trick;
                        s2[ix]=-v[ix]*dz*coefa[step]/(w*dx*dx)*0.5;
		}

                for(ix=0;ix<nx;ix++){
                        data[ix]=cp[iw][ix];
                }

                cp2=data[1];
                cp3=data[2];
                cpnm1=data[nx-2];
                cpnm2=data[nx-3];
                a1=crmul(cmul(cp2,conjg(cp3)),2.0);
                b1=cadd(cmul(cp2,conjg(cp2)),cmul(cp3,conjg(cp3)));

                if(b1.r==0.0 && b1.i==0.0)
                        a1=cexp(cmplx(0.0,-w*dx*0.5/v1));
                else
                        a1=cdiv(a1,b1);

                if(a1.i>0.0)a1=cexp(cmplx(0.0,-w*dx*0.5/v1));

                a2=crmul(cmul(cpnm1,conjg(cpnm2)),2.0);
                b2=cadd(cmul(cpnm1,conjg(cpnm1)),cmul(cpnm2,conjg(cpnm2)));

                if(b2.r==0.0 && b2.i==0.0)
                        a2=cexp(cmplx(0.0,-w*dx*0.5/vn));
                else
                        a2=cdiv(a2,b2);

                if(a2.i>0.0)a2=cexp(cmplx(0.0,-w*dx*0.5/vn));


                for(ix=0;ix<nx;ix++){
                        a[ix]=cmplx(s1[ix],s2[ix]);
                        b[ix]=cmplx(1.0-2.0*s1[ix],-2.0*s2[ix]);
                }

                for(ix=1;ix<nx-1;ix++){

		d[ix]=cadd(cadd(cmul(data[ix+1],a[ix+1]),cmul(data[ix-1],a[ix-1])),
		cmul(data[ix],b[ix]));
                }

                d[0]=cadd(cmul(cadd(b[0],cmul(a[0],a1)),data[0]),cmul(data[1],a[1]));

		d[nx-1]=cadd(cmul(cadd(b[nx-1],cmul(a[nx-1],a2)),data[nx-1]),
		cmul(data[nx-2],a[nx-2]));

                for(ix=0;ix<nx;ix++){
                        data[ix]=cmplx(s1[ix],-s2[ix]);
                        b[ix]=cmplx(1.0-2.0*s1[ix],2.0*s2[ix]);
                }
                endl=cadd(b[0],cmul(data[0],a1));
                endr=cadd(b[nx-1],cmul(data[nx-1],a2));

                
                for(ix=1;ix<nx-1;ix++){
                        a[ix]=data[ix+1];
                        c[ix]=data[ix-1];
                }
                a[0]=data[1];
                c[nx-1]=data[nx-2];
                        
                retris(data,a,c,b,endl,endr,nx,d);

                for(ix=0;ix<nx;ix++){
                        cp[iw][ix]=data[ix];
                }

        }

if(step) goto loop;

        free1complex(data);
        free1complex(d);
        free1complex(b);
        free1complex(c);
        free1complex(a);
        free1float(s1);
        free1float(s2);
                
        return;
}
                 

void retris(complex *data,complex *a,complex *c, complex *b,
                complex endl,complex endr, int nx, complex *d)
{
                 
        int ix;
        complex *e,den;
        complex *f;

        e=alloc1complex(nx);
        f=alloc1complex(nx);
        e[0]=cdiv(cneg(a[0]),endl);
        f[0]=cdiv(d[0],endl);

        for(ix=1;ix<nx-1;++ix){
                den=cadd(b[ix],cmul(c[ix],e[ix-1]));
                e[ix]=cdiv(cneg(a[ix]),den);
                f[ix]=cdiv(csub(d[ix],cmul(f[ix-1],c[ix])),den);
        }
                 

	data[nx-1]=cdiv(csub(d[nx-1],cmul(f[nx-2],c[nx-2])),cadd(endr,cmul(c[nx-2],e[nx-2])));
                
        for(ix=nx-2;ix>-1;--ix)
        data[ix]=cadd(cmul(data[ix+1],e[ix]),f[ix]);

        free1complex(e);
        free1complex(f);
        return;  
}
         

