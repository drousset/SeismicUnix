/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

/* SUCONV: $Revision: 1.12 $ ; $Date: 1996/09/05 19:24:26 $		*/

#include "su.h"
#include "segy.h"
#include "header.h"

/*********************** self documentation ******************************/
char *sdoc[] = {
" 									",
" SUCONV - convolution with user-supplied filter			",
" 									",
" suconv <stdin >stdout  filter= [optional parameters]			",
" 									",
" Required parameters: ONE of						",
" sufile=		file containing SU trace to use as filter	",
" filter=		user-supplied convolution filter (ascii)	",
" 									",
" Optional parameters:							",
" none 									",
" 									",
" Trace header fields accessed: ns					",
" Trace header fields modified: ns					",
" 									",
" Notes: It is quietly assumed that the time sampling interval on the	",
" single trace and the output traces is the same as that on the traces	",
" in the input file.  The sufile may actually have more than one trace,	",
" but only the first trace is used.					",
" 									",
" Examples:								",
"	suplane | suwind min=12 max=12 >TRACE				",
"	suconv<DATA sufile=TRACE | ...					",
" Here, the su data file, \"DATA\", is convolved trace by trace with the",
" the single su trace, \"TRACE\".					",
" 									",
"	suconv<DATA filter=1,2,1 | ...					",
" Here, the su data file, \"DATA\", is convolved trace by trace with the",
" the filter shown.							",
" 									",
NULL};

/* Credits:
 *	CWP: Jack K. Cohen, Michel Dietrich
 *
 *  CAVEATS: no space-variable or time-variable capacity.
 *     The more than one trace allowed in sufile is the
 *     beginning of a hook to handle the spatially variant case.
 *
 * Trace header fields accessed: ns
 * Trace header fields modified: ns
 */
/**************** end self doc *******************************************/

segy intrace, outtrace, sutrace;

int
main(int argc, char **argv)
{
	int nt;			/* number of points on input traces	*/
	int ntout;		/* number of points on output traces	*/
	float *filter;		/* filter coefficients			*/
	int nfilter;		/* length of input wavelet in samples	*/
	cwp_String sufile;	/* name of file containing one SU trace */
	FILE *fp;		/* ... its file pointer			*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get info from first trace */ 
	if (!gettr(&intrace) ) err("can't get first trace");
	nt = intrace.ns;


	/* Get parameters and set up filter array */
	if (!getparstring("sufile", &sufile)) {
		if (!(nfilter = countparval("filter")))
			err("must specify filter= desired filter");
		filter = ealloc1float(nfilter);	getparfloat("filter", filter);
	} else {
		fp = efopen(sufile, "r");
		fgettr(fp, &sutrace);
		nfilter = sutrace.ns;
		filter = ealloc1float(nfilter);
		memcpy((void *) filter,
			(const void *) sutrace.data, nfilter*FSIZE);
	}

	/* Set output trace length */
	ntout = nt + nfilter - 1;


	/* Main loop over traces */
	do {
		/* Convolve filter with trace */
		conv(nfilter, 0, filter,
		     nt, 0, intrace.data, 
                     ntout, 0, outtrace.data);        


		/* Output filtered trace */
		memcpy((void *) &outtrace, (const void *) &intrace, HDRBYTES);
		outtrace.ns = ntout; 
		puttr(&outtrace);

	} while (gettr(&intrace));


	return EXIT_SUCCESS;
}
