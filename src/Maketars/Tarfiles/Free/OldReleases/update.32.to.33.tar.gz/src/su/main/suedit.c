/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

/* SUEDIT: $Revision: 1.31 $; $Date: 1999/04/05 17:09:07 $	*/

#include "su.h"
#include "segy.h"
#include "header.h"
#include <errno.h>
extern int errno;

/*********************** self documentation ******************************/
char *sdoc[] = {
" 									",
" SUEDIT - examine segy diskfiles and edit headers			",
" 									",
" suedit diskfile  (open for possible header modification if writable)	",
" suedit <diskfile  (open read only)					",
" 							        	",
" The following commands are recognized:				",
" number	read in that trace and print nonzero header words	",
" <CR>		go to trace one step away (step is initially -1)	",
" +		read in next trace (step is set to +1)			",
" -		read in previous trace (step is set to -1)		",
" dN		advance N traces (step is set to N)			",
" %		print some percentiles of the trace data		",
" r		print some ranks (rank[j] = jth smallest datum) 	",
" p [n1 [n2]]  	tab plot sample n1 to n2 on current trace		",
" ! key=val  	change a value in a field (e.g. ! tracr=101)		",
" ?		print help file						",
" q		quit							",
" 									",
" NOTE: sample numbers are 1-based (first sample is 1).			",
" 									",
NULL};

/* Credits:
 *	SEP: Einar Kjartansson, Shuki Ronen, Stew Levin
 *	CWP: Jack K. Cohen
 *
 * Trace header fields accessed: ns
 */
/**************** end self doc ***********************************/


segy tr;		/* a segy trace structure		*/
FILE *tty;		/* /dev/tty is used to read user input	*/
char userin[BUFSIZ];	/* buffer user requests			*/
int nt;			/* number of sample points on traces	*/
FILE *infp;		/* file pointer for trace file		*/

/* tabulate the help message as an array of strings */
char *help[] = {
"					",
" n		read in trace #n	",
" <CR>		step			",
" +		next trace;   step -> +1",
" -		prev trace;   step -> -1",
" dN		adv N traces; step -> N	",
" %		percentiles		",
" r		ranks			",
" p [n1 [n2]]  	tabplot			",
" ! key=val  	modify field		",
" ?		print this file		",
" q		quit			",
"					",
NULL};

/* define a pointer to the help message array */
char **helpptr=help ;

#define SCREENFUL	19	/* default number of points in tab plot */

/* subroutine prototypes */
void editkey(void);
int cmp_indirect(const void *, const void *);
void userwait(void);

int
main(int argc, char **argv)
{
	int step = -1;		/* step +1/-1 for traversing data	*/
	int itr;		/* trace number (zero based)		*/
	int ntr;		/* number of traces in data set		*/
	int *rank;		/* permuted indices for indirect sort	*/
	int i;			/* counter				*/
	int iq;			/* index of qth quantile (100qth %tile)	*/
	cwp_Bool write_ok=cwp_false;/* is file writable?		*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	if (argc > 2)  err("only one filename argument is allowed");

	tty = efopen("/dev/tty", "r");

	/* Open file and print editing warnings if appropriate */
	if (!isatty(STDIN)) {	/* stdin was redirected to file */
		infp = stdin;/* note that write_ok was initialized as false */
		warn("! examine only (no header editing from STDIN)\n");

	} else {  	/* file is given by argument */

		/* First try for read and write */
		if (0 == (access(argv[1], READ_OK | WRITE_OK))) {
			infp = efopen(argv[1], "r+");
			write_ok = cwp_true;

		/* Then for just read */
		} else if (0 == (access(argv[1], READ_OK))) {
			infp = efopen(argv[1], "r");
			write_ok = cwp_false;
			warn("! %s is readonly (no header editing)\n",
								argv[1]);
		/* Admit defeat */
		} else {
			err("can't open %s for reading", argv[1]);
		}
	}

	/* Get information from first trace */
	ntr = fgettra(infp, &tr, 0);
	nt = tr.ns;

	/* Set up array for indirect sort requested by 'r' and '%' keys */
	rank = ealloc1int(nt);
	for (i = 0; i < nt; ++i)  rank[i] = i;

	printf("%d traces in input file\n", ntr);

	/* Start from last trace */
	itr = ntr - 1;
	fgettra(infp, &tr, itr);
	printheader(&tr);
	printf("> ");
	efflush(stdout);

	/* Get user directives and do requested tasks */
	while (NULL != fgets(userin, BUFSIZ, tty)) {
		switch(*userin) {
		case '0': /* check if digit */
		case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8':
		case '9': /* end check if digit */
			itr = eatoi(userin) - 1;
			if (itr < 0 || itr > ntr - 1) {
			 	warn("no such trace");
				itr = ntr - 1;
			}
			fgettra(infp, &tr, itr);
			printheader(&tr);
		break;
		case 'q':
			return EXIT_SUCCESS;
		case 'p':
			{ static int p1, p2;
			  /* Get user inputs (avoid running off end of data) */
			  switch(sscanf(userin + 1, "%d %d", &p1, &p2)) {
			  case 2:	/* user specified final position */
				if (p2 < p1) {
					warn("need p1=%d < p2=%d", p1, p2);
					return EXIT_FAILURE;
				}
				p2 = MIN(p2, nt);
			  break;
			  default:
				p2 = MIN(p1 + SCREENFUL, nt);
			  break;
			  }
			  if (p1 >= nt || p1 <= 0) p1 = 1;
			  tabplot(&tr, p1-1, p2-1); /* 1-base -> 0-base */
			  p1 = p2;
			}
		break;
		case '+':
			++itr;
			if (itr > ntr - 1) {
				step = -1;
			    	itr = ntr - 1;
				printf("\nBounced off end of data:\n\n");
			}
			fgettra(infp, &tr, itr);
			printheader(&tr);
			step = 1;
		break;
		case '-':
			itr--;
			if (itr < 0) {
				step = 1;
				itr = 0;
				printf("\nBounced off end of data:\n\n");
			}
			fgettra(infp, &tr, itr);
			printheader(&tr);
			step = -1;
		break;
		case '\n':
			itr += step;
			if (itr > ntr - 1) {
				step *= -1;
			    	itr = ntr - 1;
				printf("\nBounced off end of data:\n\n");
			}
			if (itr < 0) {
				step *= -1;
				itr = 0;
				printf("\nBounced off end of data:\n\n");
			}
			fgettra(infp, &tr, itr);
			printheader(&tr);
		break;
		case 'd':
			step = eatoi(userin + 1);
			itr += step;
			if (itr > ntr - 1) {
				step *= -1;
			    	itr = ntr - 1;
				printf("\nBounced off end of data:\n\n");
			}
			if (itr < 0) {
				step *= -1;
				itr = 0;
				printf("\nBounced off end of data:\n\n");
			}
			fgettra(infp, &tr, itr);
			printheader(&tr);
		break;
		case 'r':
			/* sort: rank[] holds rank of datum in tr */
			qsort(rank, nt, FSIZE, cmp_indirect);

			/* Could make table of desired i's and loop */
			i = 0;
			printf(" rank[%d] = %8.2e", i+1, tr.data[rank[i]]);
			i = nt / 20;
			printf(" rank[%d] = %8.2e", i+1, tr.data[rank[i]]);
			i = nt/2 - i;
			printf(" rank[%d] = %8.2e", i+1, tr.data[rank[i]]);
			printf("\n");
			i = nt - 1 - i;
			printf(" rank[%d] = %8.2e", i+1, tr.data[rank[i]]);
			i = nt - 1 - nt/20;
			printf(" rank[%d] = %8.2e", i+1, tr.data[rank[i]]);
			i = nt - 1;
			printf(" rank[%d] = %8.2e", i+1, tr.data[rank[i]]);
			printf("\nmin is at sample %d,  max at %d\n",
					rank[0] + 1, rank[nt-1] + 1);
		break;
		case '%':
			/* sort: rank[] holds rank of datum in tr */
			qsort(rank, nt, FSIZE, cmp_indirect);

			/* round to qth quantile (100 qth percentile) */
			/* thus (q*nt - 1) + .5 (-1 for zero basing) */
			i = 1; iq = (int) (0.01*nt - 0.5);
			printf(" %dst percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			i = 5; iq = (int) (0.05*nt - 0.5);
			printf(" %dth percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			i = 25; iq = (int) (0.25*nt - 0.5);
			printf("%dth percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			i = 50; iq = (int) (0.50*nt - 0.5);
			printf("%dth percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			i = 75; iq = (int) (0.75*nt - 0.5);
			printf("%dth percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			i = 95; iq = (int) (0.95*nt - 0.5);
			printf("%dth percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			i = 99; iq = (int) (0.99*nt - 0.5);
			printf("%dth percentile is %8.2e\n",
					i+1, tr.data[rank[iq]]);
			printf("min at sample %d equals %8.2e\n",
					rank[0] + 1, tr.data[rank[0]]);
			printf("max at sample %d equals %8.2e\n",
					rank[nt-1] + 1, tr.data[rank[nt-1]]);
		break;
		case '!':
			if (write_ok) {
				editkey();
			} else {
				warn("file not writable");
			}
		break;
		case '?':
			while (*helpptr) fprintf(stderr,"%s\n", *helpptr++);
			helpptr = help;
		break;
		default:
			warn("bad key %s\n", userin);
				while(*helpptr)
					fprintf(stderr,"%s\n", *helpptr++);
			helpptr = help;

		break;
		}
		printf("> ");
		efflush(stdout);
	}

	return EXIT_SUCCESS;
}



/* Modify a header field value */
void editkey(void)
{
	cwp_String keyword;	/* buffer and then header key word	*/
	cwp_String keyval;	/* header key value in ascii		*/
	cwp_String ptr;		/* pointer to isolate key word		*/
	cwp_String type;	/* type of key word			*/
	long nsegy;		/* length of trace in bytes		*/
	int databytes;		/* length of data in bytes		*/
	Value val;		/* numerical value of key word		*/

	/* char userin[] is "!    keyword  = keyval" */

	/* Strip the '!' and any leading spaces from buffer */
	for (keyword = userin + 1; isspace(*keyword); keyword++);

	/* Set keyval to start of val */
 	if (NULL == (keyval = strchr(keyword, '=') + 1)) {
		printf("command error: format is \"! key=val\"\n");
		return;
	}

	/* Null terminate keyword (back up over = and any spaces) */
	for (ptr = keyval - 2; isspace(*ptr); ptr--);
	(*(ptr + 1)) = '\0';

	/* Convert ascii keyval string to numeric val value */
	type = hdtype(keyword);
	errno = 0;
	atoval(type, keyval, &val);
	if (errno) {
	    warn("failed to convert %s to numeric, field not changed", keyval);
	}

	/* Insert value into header */
	puthdval(&tr, keyword, &val);

	/* Write back the trace with the new value */
	databytes = nt * FSIZE;
	nsegy = (long) (databytes + HDRBYTES);
	efseek(infp, -nsegy, SEEK_CUR);
	efwrite(&tr, 1, HDRBYTES, infp);

	/* Restore file pointer */
	efseek(infp, databytes, SEEK_CUR);

	/* Show the user the new header value */
	printheader(&tr);

	return;
}


/* Comparison function for qsort */
int cmp_indirect(const void *r, const void *s)
{
        const int *ir;
	const int *is;
	float diff;
	ir = (const int *) r; is = (const int *) s;
	diff = tr.data[*ir] - tr.data[*is];

	if      (diff > 0)	return(1);
	else if (diff < 0)	return(-1);
	else  /* diff == 0 */	return(0);
}


/* userwait - prompt and wait for user signal to continue */
void userwait(void)
{
	/* Note: leading newline helps some devices switch to ascii */
	fprintf(stderr, "\npress return key to continue\n");
	getc(tty);

	return;
}
