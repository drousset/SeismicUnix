/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SUPEF: $Revision: 1.34 $ ; $Date: 1999/04/29 14:00:59 $		*/

#include "su.h"
#include "segy.h"
#include "header.h"

/*********************** self documentation ******************************/
char *sdoc[] = {
" 									",
" SUPEF - Wiener predictive error filtering				",
" 									",
" supef <stdin >stdout  [optional parameters]				",
" 									",
" Required parameters:							",
" 	dt is mandatory if not set in header		 		",
" 									",
" Optional parameters:							",
"	minlag=dt		first lag of prediction filter (sec)	",
"	maxlag=last		lag default is (tmax-tmin)/20		",
"	pnoise=0.001		relative additive noise level		",
"	mincorr=tmin		start of autocorrelation window (sec)	",
"	maxcorr=tmax		end of autocorrelation window (sec)	",
"	showwiener=0		=1 to show Wiener filter on each trace	",
"	mix=1,...	 	array of weights (floats) for moving	",
"				average of the autocorrelations		",
" 									",
" Trace header fields accessed: ns, dt					",
" Trace header fields modified: none					",
" 									",
" 	To get the Wiener filters into an ascii file:			",
" 	... | supef ... showwiener=1 2>file | ...   (sh or ksh)		",
" 	(... | supef ... showwiener=1 | ...) >&file  (csh)		",
" 									",
NULL};

/* Credits:
 *	CWP: Shuki Ronen, Jack K. Cohen, Ken Larner
 *      CWP: John Stockwell, added mixing feature (April 1998)
 *
 *	A. Ziolkowski, "Deconvolution", for value of maxlag default:
 *		page 91: imaxlag < nt/10.  I took nt/20.
 *
 * Notes:
 *	The prediction error filter is 1,0,0...,0,-wiener[0], ...,
 *	so no point in explicitly forming it.
 *
 *	If imaxlag < 2*iminlag - 1, then we don't need to compute the
 *	autocorrelation for lags:
 *		imaxlag-iminlag+1, ..., iminlag-1
 *	It doesn't seem worth the duplicated code to implement this.
 *
 * Trace header fields accessed: ns
 */
/**************** end self doc *******************************************/


#define PNOISE	0.001

/* default weighting values */
#define VAL0    1.0
#define VAL1    1.0
#define VAL2    1.0
#define VAL3    1.0
#define VAL4    1.0
#define VAL5    1.0


segy intrace, outtrace;

int
main(int argc, char **argv)
{
	int nt;			/* number of points on trace		*/
	int i,ilag;		/* counters				*/

	float dt;		/* time sample interval (sec)		*/
	float *wiener;		/* Wiener error filter coefficients	*/
	float *spiker;		/* spiking decon filter			*/

	float pnoise;		/* pef additive noise level		*/

	float minlag;		/* start of error filter (sec)		*/
	int iminlag;		/* ... in samples			*/
	float maxlag;		/* end of error filter (sec)		*/
	int imaxlag;		/* ... in samples			*/
	int nlag;		/* length of error filter in samples	*/
	int ncorr;		/* length of corr window in samples	*/
	int lcorr;		/* length of autocorr in samples	*/

	float *crosscorr;	/* right hand side of Wiener eqs	*/
	float *autocorr;	/* vector of autocorrelations		*/

	float mincorr;		/* start time of correlation window	*/
	int imincorr;		/* .. in samples			*/
	float maxcorr;		/* end time of correlation window	*/
	int imaxcorr;		/* .. in samples			*/
	int showwiener;		/* flag to display pred. error filter	*/
	
	size_t lagbytes;	/* bytes in wiener and spiker filters	*/
	size_t maxlagbytes;	/* bytes in autocorrelation		*/
	
	int imix;		/* mixing counter			*/
	int nmix;		/* number of traces to average over	*/
	size_t mixbytes;	/* number of bytes = maxlagbytes*nmix	*/ 
	float *mix;		/* array of averaging weights		*/
	float **mixacorr;	/* mixing array				*/
	float *temp	;	/* temporary array			*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get info from first trace */ 
	if (!gettr(&intrace)) err("can't get first trace");
	nt = intrace.ns;
	dt = ((double) intrace.dt)/1000000.0;
	if (!dt) MUSTGETPARFLOAT ("dt", &dt);


	/* Get parameters */
	if (!getparint("showwiener",  &showwiener))	showwiener = 0;
	if (!getparfloat("pnoise",  &pnoise))	pnoise = PNOISE;

	/* .. minlag and maxlag */
	if (getparfloat("minlag", &minlag))	iminlag = NINT(minlag/dt);
	else					iminlag = 1;
	if (iminlag < 1) err("minlag=%g too small", minlag);

	if (getparfloat("maxlag", &maxlag))	imaxlag = NINT(maxlag/dt);
	else					imaxlag = NINT(0.05 * nt);
	if (imaxlag >= nt) err("maxlag=%g too large", maxlag);
	
	if (iminlag >= imaxlag)
		err("minlag=%g, maxlag=%g", minlag, maxlag);
	
	/* .. mincorr and maxcorr */
	if (getparfloat("mincorr", &mincorr))	imincorr = NINT(mincorr/dt);
	else					imincorr = 0;
	if (imincorr < 0) err("mincorr=%g too small", mincorr);
	
	if (getparfloat("maxcorr", &maxcorr))	imaxcorr = NINT(maxcorr/dt);
	else					imaxcorr = nt;
	if (imaxcorr > nt) err("maxcorr=%g too large", maxcorr);

	if (imincorr >= imaxcorr)
		err("mincorr=%g, maxcorr=%g", mincorr, maxcorr);
	
	/*... Get mix weighting values values */
	if ((nmix = countparval("mix"))!=0) {
		mix = ealloc1float(nmix);
		getparfloat("mix",mix);
		
	} else { /* else use default values */
		nmix = 1;
		mix = ealloc1float(nmix);

		mix[0] = VAL0;
	}

	/* Divide mixing weight by number of traces to mix over */
	for (imix = 0; imix < nmix; ++imix)
		mix[imix]=mix[imix]/((float) nmix);


	/* compute filter sizes and correlation number */
	nlag  = imaxlag - iminlag + 1;
	ncorr = imaxcorr - imincorr + 1;
	lcorr = imaxlag + 1;

	/* Compute byte sizes in wiener/spiker and autocorr */
	lagbytes = FSIZE*nlag;
	maxlagbytes = FSIZE*lcorr;
	mixbytes = maxlagbytes*nmix;

	/* Allocate memory */
	wiener	 = ealloc1float(nlag);
	spiker	 = ealloc1float(nlag);
	autocorr = ealloc1float(lcorr);
	temp = ealloc1float(lcorr);
	mixacorr = ealloc2float(lcorr,nmix);

	/* Set pointer to "cross" correlation */
	crosscorr = autocorr + iminlag;

	/* Zero out mixing array */
	memset((void *) mixacorr[0], (int) '\0', mixbytes);

	/* Main loop over traces */
	do {
		static int itr = 0;
		++itr;

		/* zero out filter vectors */
		memset((void *) wiener, (int) '\0', lagbytes);
		memset((void *) spiker, (int) '\0', lagbytes);
		memset((void *) autocorr, (int) '\0', maxlagbytes);
		memset((void *) temp, (int) '\0', maxlagbytes);

		/* Form autocorrelation vector */
		xcor(ncorr, imincorr, intrace.data,
		     ncorr, imincorr, intrace.data,
		     lcorr, 0, autocorr);


		/* Leave trace alone if autocorr[0] vanishes */
		if (autocorr[0] == 0.0) {
			puttr(&intrace);
			if (showwiener)
				warn("NO Wiener filter, trace: %d", itr);

			continue;
		}


		/* Whiten */
		autocorr[0] *= 1.0 + pnoise;

                /* Read autocorr into first column of mixacorr[][] */
                memcpy( (void *) mixacorr[0], 
				(const void *) autocorr, maxlagbytes);

                /* Loop over values of the autocorrelation array */
                for (ilag = 0; ilag < lcorr; ++ilag) {

                        /* Weighted moving average (mix) */
                        for(imix=0; imix<nmix; ++imix)
                                temp[ilag]+=mixacorr[imix][ilag]*mix[imix];

                        /* put mixed data back in seismic trace */
                        autocorr[ilag] = temp[ilag]; 

                }

                /* Bump columns of mixacorr[][] over by 1 */
                /* to make space for autocorr from next trace */
                for (imix=nmix-1; 0<imix; --imix)
                        for (ilag=0; ilag<lcorr; ++ilag) 
                                mixacorr[imix][ilag] = mixacorr[imix-1][ilag];


		/* Get inverse filter by Wiener-Levinson */
		stoepf(nlag, autocorr, crosscorr, wiener, spiker);
		

		/* Convolve pefilter with trace - don't do zero multiplies */
		for (i = 0; i < nt; ++i) {
			register int j;
			register int n = MIN(i, imaxlag); 
			register float sum = intrace.data[i];

			for (j = iminlag; j <= n; ++j)
				sum -= wiener[j-iminlag] * intrace.data[i-j];

			outtrace.data[i] = sum;
		}


		/* Output filtered trace */
		memcpy( (void *) &outtrace, (const void *) &intrace, HDRBYTES);
		puttr(&outtrace);


		/* Show pefilter on request */
		if (showwiener) {
			register int i;
			warn("Wiener filter, trace: %d", itr);
			for (i = 0; i < imaxlag; ++i)
				fprintf(stderr, "%10g%c", wiener[i],
					(i%6==5 || i==nlag-1) ? '\n' : ' ');
		}
		
	} while (gettr(&intrace));


	return EXIT_SUCCESS;
}
