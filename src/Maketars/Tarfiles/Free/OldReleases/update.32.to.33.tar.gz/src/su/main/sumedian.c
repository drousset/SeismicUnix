/* Copyright (c) Colorado School of Mines, 1999.*/
/* All rights reserved.                       */

/* SUMEDIAN: $Revision: 1.10 $ ; $Date: 1999/06/22 19:14:06 $	*/

#include "su.h"
#include "segy.h"
#include "header.h"
#include <signal.h>

/*********************** self documentation **********************/
char *sdoc[] = {
" 	   								",
" SUMEDIAN - MEDIAN filter about a user-defined polygonal curve with	",
"	   the distance along the curve specified by key header word 	",
" 	   								",
" sumedian <stdin >stdout xshift= tshift= [optional parameters]		",
" 									",
" Required parameters:							",
" xshift=		array of position values as specified by	",
" 			the `key' parameter				",
" tshift=		array of corresponding time values (sec)	",
"  ... or input via files:						",
" nshift=		number of x,t values defining median times	",
" xfile=		file containing position values as specified by	",
" 			the `key' parameter				",
" tfile=		file containing corresponding time values (sec)	",
" 									",
" Optional parameters:							",
" key=tracl		Key header word specifying trace number 	",
" 				=offset  use trace offset instead	",
" 									",
" mix=.6,1,1,1,.6	array of weights for mix (weighted moving average)",
" 									",
" verbose=0	verbose = 1 echoes information				",
"									",
" tmpdir= 	 if non-empty, use the value as a directory path	",
"		 prefix for storing temporary files; else if the	",
"	         the CWP_TMPDIR environment variable is set use		",
"	         its value for the path; else use tmpfile()		",
" 									",
" Notes: 								",
" Median filtering is a process for suppressing a particular moveout on ",
" seismic sections. Median filtering has an advantage over traditional  ",
" dip filtering in that events with an arbitrary moveout may be suppressed",
"									",
" The process consists of 3 steps. In the first step,			",
" a copy of the data panel is shifted so that the polygon in x,t specifying",
" moveout is flattened to horizontal. (The x,t pairs are specified either",
" by the vector xshift,tshift or by the values in the datafiles xfile,tfile.)",
" The second step in the process is to perform a mix (weighted moving   ",
" average) over the shifted panel to emphasize events with the specified",
" moveout and destroy events with other moveouts . The panel is then	",
" shifted back to its original moveout and is then subtracted from the	",
" original data, eliminating all events with the user-specified moveout.",
" 									",
" The values of tshift are linearly interpolated for traces falling between",
" given xshift values. The tshift interpolant is extrapolated to the left",
" by the smallest time sample on the trace and to the right by the last",
" value given in the tshift array. 					",
" 									",
" The files tfile and xfile are files of binary (C-style) floats.	",
" 									",
" The number of values defined by mix=val1,val2,... determines the number",
" of traces to be averaged, the values determine the weights.		",
" 									",
" Caveat:								",
" The median filter may perform poorly on the edges of a section.	",
" Choosing larger beginning and ending mix values may help, but may also",
" but may also introduce additional artifacts.				",
" 									",
NULL};

/* Credits:
 *
 * CWP: John Stockwell, based in part on sumute, sureduce, sumix
 *
 * Trace header fields accessed: ns, dt, delrt, key=keyword
 *
 */
/**************** end self doc ***********************************/

/* default weighting values */
#define VAL0	0.6
#define VAL1	1.0
#define VAL2	1.0
#define VAL3	1.0
#define VAL4	0.6

static void closefiles(void);

/* Globals (so can trap signal) defining temporary disk files */
char tracefile[BUFSIZ];	/* filename for the file of traces	*/
char headerfile[BUFSIZ];/* filename for the file of headers	*/
FILE *tracefp;		/* fp for trace storage file		*/
FILE *headerfp;		/* fp for header storage file		*/

segy tr;

int
main(int argc, char **argv)
{
	char *key;		/* header key word from segy.h		*/
	char *type;		/* ... its type				*/
	int index;		/* ... its index			*/
	Value val;		/* ... its value			*/
	float fval;		/* ... its value cast to float		*/

	float *xshift;		/* array of key shift curve values	*/
	float *tshift;		/* ...		shift curve time values */

	int nxshift;		/* number of key shift values		*/
	int ntshift;		/* ...		shift time values 	*/

	int nxtshift;		/* number of shift values 		*/

	int it;			/* sample counter			*/
	int itr;		/* trace counter			*/
	int nt;			/* number of time samples 		*/
	int ntr=0;		/* number of traces			*/
	int *inshift;		/* array of time shift values		*/

	float dt;		/* time sampling interval		*/

	cwp_String xfile="";	/* file containing positions by key	*/
	FILE *xfilep;		/* ... its file pointer			*/
	cwp_String tfile="";	/* file containing times	 	*/
	FILE *tfilep;		/* ... its file pointer			*/

	int verbose;		/* flag for printing information	*/
	char *tmpdir;	/* directory path for tmp files			*/
	cwp_Bool istmpdir=cwp_false;/* true for user-given path		*/

	int nmix;		/* number of traces to mix over		*/
	int imix;		/* mixing counter			*/
	float *mix;		/* array of mix values			*/
	int shiftmin=0;		/* minimum time shift (in samples)	*/
	int shiftmax=0;		/* maximum time shift (in samples)	*/
	int ntdshift;		/* nt + shiftmax			*/

	size_t mixbytes;	/* size of mixing array			*/
	size_t databytes;	/* size of data array			*/
	size_t shiftbytes;	/* size of data array			*/
	float *temp;		/* temporary array			*/
	float *dtemp;		/* temporary array			*/
	float **data;		/* mixing array 			*/
	

	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);

	/* Get parameters */
	if (!(getparstring("xfile",&xfile) && getparstring("tfile",&tfile))) {
		if (!(nxshift = countparval("xshift")))
			err("must give xshift= vector");
		if (!(ntshift = countparval("tshift")))
			err("must give tshift= vector");
		if (nxshift != ntshift)
			err("lengths of xshift, tshift must be the same");
		xshift = ealloc1float(nxshift);	getparfloat("xshift", xshift);
		tshift = ealloc1float(nxshift);	getparfloat("tshift", tshift);
	} else {
		MUSTGETPARINT("nshift",&nxtshift);
		nxshift = nxtshift;
		xshift = ealloc1float(nxtshift);
		tshift = ealloc1float(nxtshift);

		if((xfilep=fopen(xfile,"r"))==NULL)
			err("cannot open xfile=%s\n",xfile);
		if (fread(xshift,sizeof(float),nxtshift,xfilep)!=nxtshift)
			err("error reading xfile=%s\n",xfile);
		fclose(xfilep);

		if((tfilep=fopen(tfile,"r"))==NULL)
			err("cannot open tfile=%s\n",tfile);
		if (fread(tshift,sizeof(float),nxtshift,tfilep)!=nxtshift)
			err("error reading tfile=%s\n",tfile);
		fclose(tfilep);
	}
	if (!getparstring("key", &key))		key = "tracl";

	/* Get key type and index */
	type = hdtype(key);
	index = getindex(key);   

	/* Get mix weighting values values */
	if ((nmix = countparval("mix"))!=0) {
		mix = ealloc1float(nmix);
		getparfloat("mix",mix);
		
	} else {
		nmix = 5;
		mix = ealloc1float(nmix);

		mix[0] = VAL0;
		mix[1] = VAL1;
		mix[2] = VAL2;
		mix[3] = VAL3;
		mix[4] = VAL4;
	}
	
	if (!getparint("verbose", &verbose))	verbose = 0;

	/* Look for user-supplied tmpdir */
	if (!getparstring("tmpdir",&tmpdir) &&
	    !(tmpdir = getenv("CWP_TMPDIR"))) tmpdir="";
	if (!STREQ(tmpdir, "") && access(tmpdir, WRITE_OK))
		err("you can't write in %s (or it doesn't exist)", tmpdir);


	/* Divide mixing weight by number of traces to mix */
	for (imix = 0; imix < nmix; ++imix)
		mix[imix]=mix[imix]/((float) nmix);

	/* Get info from first trace */
	if (!gettr(&tr)) err("can't read first trace");
	if (!tr.dt) err("dt header field must be set");
	dt   = ((double) tr.dt)/1000000.0;
	nt = (int) tr.ns;
	databytes = FSIZE*nt;

	/* Tempfiles */
	if (STREQ(tmpdir,"")) {
		tracefp = etmpfile();
		headerfp = etmpfile();
		if (verbose) warn("using tmpfile() call");
	} else { /* user-supplied tmpdir */
		char directory[BUFSIZ];
		strcpy(directory, tmpdir);
		strcpy(tracefile, temporary_filename(directory));
		strcpy(headerfile, temporary_filename(directory));
		/* Trap signals so can remove temp files */
		signal(SIGINT,  (void (*) (int)) closefiles);
		signal(SIGQUIT, (void (*) (int)) closefiles);
		signal(SIGHUP,  (void (*) (int)) closefiles);
		signal(SIGTERM, (void (*) (int)) closefiles);
		tracefp = efopen(tracefile, "w+");
		headerfp = efopen(headerfile, "w+");
      		istmpdir=cwp_true;		
		if (verbose) warn("putting temporary files in %s", directory);
	}

	/* Loop over traces, reading data while getting a count */
	do {
		++ntr;

		efwrite(&tr, 1, HDRBYTES, headerfp);
		efwrite(tr.data, 1, databytes, tracefp);   

	} while (gettr(&tr));
	rewind(headerfp);
	rewind(tracefp);
	
	/* Allocate space for inshift vector */
	inshift = ealloc1int(ntr);

	/* Loop over headers */
 	for (itr=0; itr<ntr; ++itr) {
		float tmin=tr.delrt/1000.0;
		float t;

		/* Read header values */
		efread(&tr, 1, HDRBYTES, headerfp);

		/* Get value of key and convert to float */
		gethval(&tr, index, &val);
		fval = vtof(type,val);

		/* Linearly interpolate between (xshift,tshift) values */
		intlin(nxshift,xshift,tshift,tmin,tshift[nxshift-1],1,&fval,&t); 
		inshift[itr]=NINT((t - tmin)/dt);
		
		/* Find minimum and maximum shifts */
		if (itr==0) {
			 shiftmax=inshift[0];
			 shiftmin=inshift[0];
		} else {
			shiftmax = MAX(inshift[itr],shiftmax);
			shiftmin = MIN(inshift[itr],shiftmin);
		}
	}
	rewind(headerfp);
	rewind(tracefp);

	/* Compute databyes per trace and bytes in mixing panel */
	ntdshift = nt + shiftmax;
	shiftbytes = FSIZE*ntdshift;
	mixbytes = shiftbytes*nmix;

	/* Allocate space and zero  data array */
	data = ealloc2float(ntdshift,nmix);
	temp = ealloc1float(ntdshift);
	dtemp = ealloc1float(nt);
	memset( (void *) data[0], '\0', mixbytes);

	/* Loop over traces performing median filtering  */
 	for (itr=0; itr<ntr; ++itr) {

		/* paste header and data on output trace */
		efread(&tr, 1, HDRBYTES, headerfp);
		efread(tr.data, 1, databytes, tracefp);

		/* read data portion of trace into first column of array */
		for(it=0; it<ntdshift; ++it)
			data[0][it + shiftmax - inshift[itr]] = tr.data[it];

		/* Zero out temp and dtemp */
		memset((void *) temp, (int) '\0', shiftbytes);
		memset((void *) dtemp, (int) '\0', databytes);

		/* Loop over time samples */
		for (it=0; it<nt; ++it) {

			/* Weighted moving average (mix) */
			for(imix=0; imix<nmix; ++imix)
				temp[it]+=data[imix][it]*mix[imix];

			/* put mixed data into dtemp */
			if ((it - shiftmax + inshift[itr])>=0)
				dtemp[it - shiftmax + inshift[itr]] = temp[it];

		}
		/* Subtract dtemp from original data */
		for (it=0; it<nt; ++it)
			tr.data[it] = tr.data[it] - dtemp[it];

		/* Bump columns of data[][] over by 1 */
		/* to make space for data from next trace */
		for (imix=nmix-1; 0<imix; --imix)
			for (it=0; it<nt; ++it)
				data[imix][it] = data[imix-1][it];

		/* Write output trace */
		tr.ns = nt;
		puttr(&tr);
	}

	/* Clean up */
	efclose(headerfp);
	if (istmpdir) eremove(headerfile);
	efclose(tracefp);
	if (istmpdir) eremove(tracefile);

	return EXIT_SUCCESS;
}

/* for graceful interrupt termination */
static void closefiles(void)
{
	efclose(headerfp);
	efclose(tracefp);
	eremove(headerfile);
	eremove(tracefile);
	exit(EXIT_FAILURE);
}
