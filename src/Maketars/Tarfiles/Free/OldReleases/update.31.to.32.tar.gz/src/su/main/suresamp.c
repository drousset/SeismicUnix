/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SURESAMP: $Revision: 1.10 $ ; $Date: 1997/10/20 15:30:28 $	*/

#include "su.h"
#include "segy.h"
#include "header.h"

/*********************** self documentation **********************/
char *sdoc[] = {
"								",
" SURESAMP - Resample in time					",
"								",
" suresamp <stdin >stdout  [optional parameters]		",
"								",
" Required parameters:						",
"	none							",
"								",
" Optional Parameters:						",
"	nt=tr.ns	    number of time samples on output	",
"	dt=tr.dt/10^6	    time sampling interval on output	",
"	tmin=tr.delrt/10^3  first time sample on output		",
"								",
" Example 1: (assume original data had dt=.004 nt=256)		",
" 	sufilter <data f=40,50 amps=1.,0. | 			",
" 	suresamp nt=128 dt=.008 | ...		 		",
" Note the typical anti-alias filtering before sub-sampling.	",
" Example 2: (assume original data had dt=.004 nt=256)		",
" 	suresamp <data nt=512 dt=.002 | ...	 		",
NULL};

/* Credits:
 *	CWP: Dave (resamp algorithm), Jack (SU adaptation)
 *
 * Trace header fields accessed:  ns, dt, delrt
 * Trace header fields modified:  ns, dt, delrt(only, when set tmin)
 */
/************************ end self doc ***************************/


segy intrace, outtrace;

int
main(int argc, char **argv)
{
	int nt;		/* number of samples on output trace	*/
	int nt_in;	/* ... on input trace			*/
	float dt;	/* sample rate on output trace		*/
	int idt;	/* ... as integer			*/
	float dt_in;	/* ... on input trace			*/
	float tmin;	/* first time sample on output trace	*/
	float tmin_in;	/* ... on input trace			*/
	float *t;	/* array of output times		*/
	
	int	tmin_is_set = 0;
	
	/* Hook up getpar */
	initargs(argc, argv);
	requestdoc(1);

	/* Get information from first trace */
	if (!gettr(&intrace)) err("can't get first trace");
	nt_in   = intrace.ns;
	dt_in   = ((double) intrace.dt)/1000000.0;
	
	/* Get parameters */
	if (!getparint("nt", &nt))	 nt = nt_in;
	CHECK_NT("nt",nt);
	
	if (!getparfloat("dt", &dt))	 dt = dt_in;
	idt = NINT(dt * 1000000.0);
	
	if (getparfloat("tmin", &tmin))
		tmin_is_set = 1;
	
	/* Allocate vector of output times */
	t = ealloc1float(nt);

	/* Loop on traces */	
	do {
		tmin_in = intrace.delrt/1000.0;
		if (tmin_is_set == 0)
			tmin = tmin_in;
			
		/* Compute output times */
		{ register int itime;
		  register float tvalue;
		  for (itime=0,tvalue=tmin; itime<nt; itime++,tvalue+=dt)
			t[itime] = tvalue;
		}
	
		/* copy and adjust header */
		memcpy(&outtrace, &intrace, HDRBYTES);
		outtrace.ns    = nt;
		outtrace.dt    = idt;
		if (tmin_is_set == 1)
			outtrace.delrt = NINT(tmin * 1000.0);
		
		/* sinc interpolate new data */
		ints8r(nt_in, dt_in, tmin_in, intrace.data, 
				0.0, 0.0, nt, t, outtrace.data);
		
		puttr(&outtrace);
	} while (gettr(&intrace));


	return EXIT_SUCCESS;
}
