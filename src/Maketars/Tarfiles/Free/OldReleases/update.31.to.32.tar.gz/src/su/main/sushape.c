/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SUSHAPE: $Revision: 1.11 $ ; $Date: 1997/07/28 22:36:46 $		*/

#include "su.h"
#include "segy.h"
#include "header.h"

/*********************** self documentation ******************************/
char *sdoc[] = {
" 									",
" SUSHAPE - Wiener shaping filter					",
" 									",
" sushape <stdin >stdout  d= [optional parameters]			",
" 									",
" Required parameters:							",
" w=vector of input wavelet to be shaped				",
" d=vector of desired output wavelet					",
" dt=tr.dt     (if dt header field is not set, then dt is a mandatory	",
" 									",
" Optional parameters:							",
" nshape=trace		length of shaping filter			",
" pnoise=0.001		relative additive noise level			",
" showshaper=0		=1 to show shaping filter 			",
" 									",
" 	To get the shaping filters into an ascii file:			",
" 	... | sushape ... showwshaper=1 2>file | ...   (sh or ksh)	",
" 	(... | sushape ... showshaper=1 | ...) >&file  (csh)		",
" 									",
NULL};

/* Credits:
 *	CWP: Jack K. Cohen
 *
 * Trace header fields accessed: ns, dt */
/**************** end self doc *******************************************/


#define PNOISE	0.001


segy intrace, outtrace;

int
main(int argc, char **argv)
{
	int nt;			/* number of points on trace		*/
	float dt;		/* time sample interval (sec)		*/
	float *shaper;		/* shaping filter coefficients		*/
	float *spiker;		/* spiking decon filter (not used)	*/
	float *w;		/* input wavelet			*/
	int nw;			/* length of input wavelet in samples	*/
	float *d;		/* desired output wavelet		*/
	int nd;			/* length of desired wavelet in samples	*/
	int nshape;		/* length of shaping filter in samples	*/
	float pnoise;		/* pef additive noise level		*/
	float *crosscorr;	/* right hand side of Wiener eqs	*/
	float *autocorr;	/* vector of autocorrelations		*/
	int showshaper;		/* flag to display shaping filter	*/
	float f_zero=0.0;	/* zero valued item for comparison	*/



	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get info from first trace */ 
	if (!gettr(&intrace)) err("can't get first trace");
	nt = intrace.ns;
	dt = ((double) intrace.dt)/1000000.0;
	if (!dt) MUSTGETPARFLOAT ("dt", &dt);


	/* Get parameters */
	if (!getparint("showshaper",  &showshaper))	showshaper = 0;
	if (!getparint("nshape",  &nshape))		nshape = nt;
	if (!getparfloat("pnoise",  &pnoise))	pnoise = PNOISE;
	if (!(nw = countparval("w")))  err("must specify w= desired wavelet");
	w = ealloc1float(nw);	getparfloat("w", w);

	if (!(nd = countparval("d")))  err("must specify d= desired wavelet");
	d = ealloc1float(nd);	getparfloat("d", d);


	/* Get shaping filter by Wiener-Levinson */
	shaper	  = ealloc1float(nshape);
	spiker 	  = ealloc1float(nshape);	/* not used */
	crosscorr = ealloc1float(nshape);
	autocorr  = ealloc1float(nshape);
	xcor(nw, 0, w, nw, 0, w, nshape, 0, autocorr);  /* for matrix */
	xcor(nw, 0, w, nd, 0, d, nshape, 0, crosscorr); /* right hand side */
	if (CLOSETO(autocorr[0],f_zero))  err("can't shape with zero wavelet");
	autocorr[0] *= (1.0 + pnoise);			/* whiten */
	stoepf(nshape, autocorr, crosscorr, shaper, spiker);
		

	/* Show shaper on request */
	if (showshaper) {
		register int i;
		warn("Shaping filter:");
		for (i = 0; i < nshape; ++i)
			fprintf(stderr, "%10g%c", shaper[i],
				(i%6==5 || i==nshape-1) ? '\n' : ' ');
	}



	/* Main loop over traces */
	do {
		/* Center and convolve shaping filter with trace */
		conv(nshape, (nw-nd)/2, shaper,
		     nt, 0, intrace.data, 
                     nt, 0, outtrace.data);        


		/* Output filtered trace */
		memcpy( (void *) &outtrace, (const void *) &intrace, HDRBYTES);
		puttr(&outtrace);

	} while (gettr(&intrace));


	return EXIT_SUCCESS;
}
