/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SUATTRIBUTES:  $Revision: 1.24 $ ; $Date: 1998/01/08 18:42:05 $	*/

#include "su.h"
#include "segy.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 									",
" SUATTRIBUTES - trace ATTRIBUTES instantanteous amplitude, phase,	",
" 		 or frequency						",
" 									",
" suattributes <stdin >stdout mode=amp					",
" 									",
" Required parameters:							",
" 	none								",
" 									",
" Optional parameter:							",
" 	mode=amp	output flag 					",
" 	       		=amp envelope traces				",
" 	       		=phase phase traces				",
" 	       		=freq frequency traces				",
"	unwrap=		default unwrap=0 for mode=phase			",
" 			default unwrap=1 for mode=freq			",
" 			dphase_min=PI/unwrap				",
" 									",
" Notes:								",
" This program performs complex trace attribute analysis, a la Taner,	",
" Kohler, and Sheriff, 1979.						",
" 									",
" The unwrap parameter is active only for mode=freq and mode=phase. The	",
" quantity dphase_min is the minimum change in the phase angle taken to be",
" the result of phase wrapping, rather than natural phase variation in the",
" data. Setting unwrap=0 turns off phase-unwrapping altogether. Choosing",
" unwrap > 1 makes the unwrapping function more sensitive to phase changes.",
" Setting unwrap > 1 may be necessary to resolve higher frequencies in	",
" data (or sample data more finely). The phase unwrapping is crude. The ",
" differentiation needed to compute the instantaneous frequency		",
" freq(t)= d(phase)/dt is a simple centered difference.			",
"	 					       			",
" Examples:								",
" suvibro f1=10 f2=50 t1=0 t2=0 tv=1 | suattributes mode=amp | ...	",
" suvibro f1=10 f2=50 t1=0 t2=0 tv=1 | suattributes mode=phase | ...	",
" suvibro f1=10 f2=50 t1=0 t2=0 tv=1 | suattributes mode=freq | ...	",
" suplane | suattributes mode=... | supswigb |...       		",
"	 					       			",
NULL};

/* Credits:
 *	CWP: Jack Cohen
 *      CWP: John Stockwell (added freq and unwrap features)
 *
 * Algorithm:
 *	c(t) = hilbert_tranform_kernel(t) convolved with data(t)  
 *
 *  amp(t) = sqrt( c.re^2(t) + c.im^2(t))
 *  phase(t) = arctan( c.im(t)/c.re(t))
 *  freq(t) = d(phase)/dt
 *
 * Reference: Taner, M. T., Koehler, A. F., and  Sheriff R. E.
 * "Complex seismic trace analysis", Geophysics,  vol.44, p. 1041-1063, 1979
 *
 * Trace header fields accessed: ns, trid
 * Trace header fields modified: d1, trid
 */

/**************** end self doc ********************************/

#define	AMP		 1
#define	ARG		 2
#define	FREQ		 3


/* function prototype of functions used internally */
void unwrap_phase(int n, float unwrap, float *phase);
void differentiate(int n, float h, float *f);

segy tr;

int
main(int argc, char **argv)
{
	cwp_String mode;	/* display: real, imag, amp, arg	*/
	int imode=AMP;		/* integer abbrev. for mode in switch	*/
	register complex *ct;	/* complex trace			*/
	int nt;			/* number of points on input trace	*/
	float dt;		/* sample spacing			*/
	float *data;		/* array of data from each trace	*/
	float *hdata;		/* array of Hilbert transformed data	*/
	float unwrap;		/* PI/unwrap=min dphase assumed to by wrap*/
	cwp_Bool seismic;	/* is this seismic data?		*/
	
	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);

	/* Get info from first trace */
	if (!gettr(&tr)) err("can't get first trace");
	nt = tr.ns;
	dt = ((double) tr.dt)/1000000.0;

	/* check to see if data type is seismic */
	seismic = ISSEISMIC(tr.trid);

	if (!seismic)
		err("input is not seismic data, trid=%d", tr.trid);

	/* Get mode; note that imode is initialized to AMP */
	if (!getparstring("mode", &mode))	mode = "amp";

	if      (STREQ(mode, "phase"))  imode = ARG;
	else if (STREQ(mode, "freq"))	imode = FREQ;
	else if (!STREQ(mode, "amp"))
		err("unknown mode=\"%s\", see self-doc", mode);

	/* getpar value of unwrap */
	switch(imode) {
	case FREQ:
		if (!getparfloat("unwrap", &unwrap))	unwrap=1; 
	break;
	case ARG:
		if (!getparfloat("unwrap", &unwrap))	unwrap=0; 
	break;
	}

	/* allocate space for data and hilbert transformed data, cmplx trace */
	data = ealloc1float(nt);
	hdata = ealloc1float(nt);
	ct = ealloc1complex(nt);


	/* Loop over traces */
	do {
		register int i;

		/* Get data from trace */
		for (i = 0; i < nt; ++i)  data[i] = tr.data[i];

		
		/* construct quadrature trace with hilbert transform */
		hilbert(nt, data, hdata);

		/* build the complex trace */
		for (i = 0; i < nt; ++i)  ct[i] = cmplx(data[i],hdata[i]);

		/* Form absolute value, phase, or frequency */
		switch(imode) {
		case AMP:
			for (i = 0; i < nt; ++i) {
				float re = ct[i].r;
				float im = ct[i].i;
				tr.data[i] = sqrt(re*re + im*im);
			}

			/* set trace id */
			tr.trid = ENVELOPE;
		break;
		case ARG:
		{
			float *phase = ealloc1float(nt);

			for (i = 0; i < nt; ++i) {
				float re = ct[i].r;
				float im = ct[i].i;
				if (re*re+im*im)  phase[i] = atan2(im, re);
				else              phase[i] = 0.0;
			}

			/* phase unwrapping */
			/* default unwrap=0 for this mode */
			if (unwrap!=0) unwrap_phase(nt, unwrap, phase);

			/* write phase values to tr.data */
			for (i = 0; i < nt; ++i) tr.data[i] = phase[i];
			
			/* set trace id */
			tr.trid = INSTPHASE;
		}
		break;
		case FREQ:
		{
			float *phase = ealloc1float(nt);
			float	fnyq = 0.5 / dt;

			for (i = 0; i < nt; ++i) {
				float re = ct[i].r;
				float im = ct[i].i;
				if (re*re+im*im) {
					phase[i] = atan2(im, re);
				} else {
					phase[i] = 0.0;
				}
				
			}

			/* unwrap the phase */
			if (unwrap!=0) unwrap_phase(nt, unwrap, phase);

			/* compute freq(t)=dphase/dt */
			differentiate(nt, 2.0*PI*dt, phase);
			
			/* correct values greater nyquist frequency */
			for (i=0 ; i < nt; ++i)	{
				if (phase[i] > fnyq)	
					phase[i] = 2 * fnyq - phase[i];
			}
                                         
			/* write freq(t) values to tr.data */
			for (i=0 ; i < nt; ++i) tr.data[i] = phase[i];
			
			/* set trace id */
			tr.trid = INSTFREQ;
		}
		break;
		default:
			err("%s: mysterious mode=\"%s\"", __LINE__, mode);
		}


		tr.d1 = dt;   /* for graphics */
		puttr(&tr);

	} while (gettr(&tr));


	return EXIT_SUCCESS;
}


void differentiate(int n, float h, float *f)
/************************************************************************
differentiate - compute the 1st derivative of a function f[]
************************************************************************
Input:
n		number of samples
h		sample rate
f		array[n] of input values

Output:
f		array[n], the derivative of f
************************************************************************
Notes:
This is a simple 2 point centered-difference differentiator.
The derivatives at the endpoints are computed via 2 point leading and
lagging differences. 
************************************************************************
Author: John Stockwell, CWP, 1994
************************************************************************/
{
	int i;	
	float *temp;
	float h2=2*h;

	/* allocate space in temporary vector */
	temp = ealloc1float(n);

	/* do first as a leading difference */
	temp[0] = (f[1] - f[0])/h;

	/* do the middle values as a centered difference */
	for (i=1; i<n-1; ++i) temp[i] = (f[i+1] - f[i-1])/h2;

	/* do last value as a lagging difference */
	temp[n-1] = (f[n-1] - f[n-2])/h;

	for (i=0 ; i < n ; ++i) f[i] = temp[i];

	free1float(temp);
}

void unwrap_phase(int n, float w, float *phase)
/************************************************************************
unwrap_phase - unwrap the phase
*************************************************************************
Input:
n		number of samples
w		unwrapping flag; returns an error if w=0
phase		array[n] of input phase values

Output:
phase		array[n] of output phase values
*************************************************************************
Notes:
The phase is assumed to be continuously increasing. The strategy is
to look at the change in phase (dphase) with each time step. If it is larger
than PI/w, then use the previous value of dphase. No attempt is
made at smoothing the dphase curve.
*************************************************************************
Author: John Stockwell, CWP, 1994
************************************************************************/
{
	int i;
	float pibyw=0.0;
	float *dphase;
	float *temp;

	/* prevent division by zero in PI/w */
	if (w==0)  err("wrapping parameter is zero");
	else       pibyw = PI/w;

	/* allocate space */
	dphase = ealloc1float(n);
	temp = ealloc1float(n);

	/* initialize */
	temp[0]=phase[0];

	/* compute unwrapped phase at each time step */
	for (i = 1; i < n; ++i) {

		/* compute jump in phase */
		dphase[i] = ABS(phase[i] - phase[i-1]);

		/* if dphase >= PI/w, use previous dphase value */
		if (ABS(dphase[i] - dphase[i-1]) >= pibyw )
			dphase[i] = dphase[i-1];

		/* sum up values in temporary vector */
		temp[i] = temp[i-1] + dphase[i];
	}

	/* assign values of temporary vector to phase[i] */
	for (i=0; i<n; ++i) phase[i] = temp[i];

	/* free space */
	free1float(temp);
	free1float(dphase);
}		
