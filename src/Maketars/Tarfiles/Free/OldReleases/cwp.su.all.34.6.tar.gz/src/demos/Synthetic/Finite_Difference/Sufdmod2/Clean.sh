#! /bin/sh
# Clean.sh created data files

rm -f *.out junk* *.eps *.ps density* velocity* 

exit
