#! /bin/sh
# Clean created data files

rm -f data.su *.eps oz*

exit
