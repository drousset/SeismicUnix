#! /bin/sh
# Clean created data files

rm -f suplane.data *.eps

exit
