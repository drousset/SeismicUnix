#! /bin/sh

rm *mod* *out* *.su* tmp *.ps
