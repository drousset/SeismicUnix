#! /bin/sh
# Clean.sh up residue from runs


rm -f *data *file* *.eps 
