#! /bin/sh

rm junk* *.eps
