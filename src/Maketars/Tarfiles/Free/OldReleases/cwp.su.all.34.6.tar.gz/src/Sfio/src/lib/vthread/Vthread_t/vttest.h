/* Copyright (c) Colorado School of Mines, 2001.*/
/* All rights reserved.                       */

#include	"terror.h"
#include	<vthread.h>
