#! /bin/sh
set -v

rm -f *.dat junk* *.ps *.log
exit 0
