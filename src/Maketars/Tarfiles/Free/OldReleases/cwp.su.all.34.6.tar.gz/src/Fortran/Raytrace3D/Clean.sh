#! /bin/sh
# clean up

rm *.a

cd ./Demo
Clean.sh

exit 0


