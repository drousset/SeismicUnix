#! /bin/sh
# clean up

cd ./Demo
Clean.sh

exit 0


