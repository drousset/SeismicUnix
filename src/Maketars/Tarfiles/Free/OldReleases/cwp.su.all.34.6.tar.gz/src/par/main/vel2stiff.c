/* Copyright (c) Colorado School of Mines, 2001.*/
/* All rights reserved.                       */

/* VEL2STIFF	version 1.0 Date: 8/3 1999				*/

#include "par.h"

/*********************** self documentation ******************************/
char *sdoc[] = {
" 									",
" VEL2STIFF - Transforms VELocities, densities, and Thomsen parameters	",
"		to elastic STIFFnesses 					",
" 									",
" vel2stiff  nx=  nz=  vpfile= vsfile= rhofile=  epsfile= 		",
"		deltafile= gammafile=  c11_file= c13_file= c33_file= 	",
"		c44_file=[] c66_file=[]					",
" 									",
" Required parameters:							",
" vpfile=	file with P-wave velocities				",
" vsfile=	file with S-wave velocities				",
" rhofile=	file with densities					",
"									",
" Optional Parameters:							",
" epsfile=	file with Thomsen epsilon				",
" deltafile=	file with Thomsen delta				 	",
" gammafile=	file with Thomsen gamma				 	",
"									",
" nx=101	number of x samples (2nd dimension)			",
" nz=101	number of z samples (1st dimension)			",
" 									",
" Notes: 								",
" Transforms velocities, density and Thomsen parameters			",
" epsilon,delta and gamma into elastic stiffness coefficients.		",
" If only P-wave, S-wave velocities and density is given as input,	",
" the model is assumed to be isotropic.					",
" If files containing Thomsen parameters are given, the model will be	",
" assumed to have VTI symmetry.		 				",
" 									",
" 									",
NULL};

/*
 *  Coded:
 *  CWP: Sverre Brandsberg-Dahl 1999
 *
 */
/**************** end self doc *******************************************/

int
main(int argc, char **argv)
{
	int nx,nz,ix,iz,verbose;
	float b,c;
	float **c11,**c13,**c33,**c44,**c66,**vp,**vs,**rho,
		**eps, **delta, **gamma;


	/* input files */
	char *vpfile="",  *vsfile="", *rhofile="", *epsfile="",
		*deltafile="", *gammafile="";
	FILE *vpfp,*vsfp,*rhofp,*epsfp,*deltafp,*gammafp;


	/* output files */
	char *c11_file, *c13_file, *c33_file, *c44_file, *c66_file;
	FILE *c11fp=NULL, *c13fp=NULL, *c33fp=NULL, *c44fp=NULL, *c66fp=NULL;


	/* hook up getpar */
	initargs(argc, argv);
	requestdoc(1);


	/* get required parameters */
	MUSTGETPARSTRING("vpfile",  &vpfile );
	MUSTGETPARSTRING("vsfile",  &vsfile );
	MUSTGETPARSTRING("rhofile", &rhofile);


	/* get parameters */
	if (!getparint("nx",	&nx))	nx = 101;
	if (!getparint("nz",	&nz))	nz = 101;
	if (!getparint("verbose", &verbose)) verbose = 1;
	getparstring("epsfile",  &epsfile);
	getparstring("deltafile",&deltafile);
	getparstring("gammafile",&gammafile);


	/* allocate space */
	vp	= alloc2float(nz,nx);
	vs	= alloc2float(nz,nx);
	rho	= alloc2float(nz,nx);
	eps	= alloc2float(nz,nx);
	delta  = alloc2float(nz,nx);
	gamma  = alloc2float(nz,nx);
	c11	= alloc2float(nz,nx);
	c13	= alloc2float(nz,nx);
	c33	= alloc2float(nz,nx);
	c44	= alloc2float(nz,nx);
	c66	= alloc2float(nz,nx);


	/* read mandatory input files */
	vpfp = efopen(vpfile,"r");
	if (efread(*vp, sizeof(float), nz*nx, vpfp)!=nz*nx)
	  err("error reading vpfile=%s!\n",vpfile);

	vsfp = efopen(vsfile,"r");
	if (efread(*vs, sizeof(float), nz*nx, vsfp)!=nz*nx)
	  err("error reading vsfile=%s!\n",vsfile);

	rhofp = efopen(rhofile,"r");
	if (efread(*rho, sizeof(float), nz*nx, rhofp)!=nz*nx)
	  err("error reading rhofile=%s!\n",rhofile);

	fclose(vpfp);
	fclose(vsfp);
	fclose(rhofp);


	/* optional files if aniostropic model */
	/* see if there is an input file for epsilon */
	if (*epsfile!='\0') {
	  if((epsfp=fopen(epsfile,"r"))==NULL)
		err("cannot open epsfile=%s",epsfile);
	  if (fread(eps[0],sizeof(float),nx*nz,epsfp)!=nx*nz)
		err("error reading epsilonfile=%s",epsfile);
	  fclose(epsfp);
	} else {
		if(verbose)
		  warn("No input file for epsilon, setting epsilon to zero!!!");

		/* set epsilon to zero */
		memset((void *) eps[0], (int) '\0' , nx*nz*FSIZE);
	}


	/* see if there is an input file for delta */
	if (*deltafile!='\0') {
	  if((deltafp=fopen(deltafile,"r"))==NULL)
		err("cannot open deltafile=%s",deltafile);
	  if (fread(delta[0],sizeof(float),nx*nz,deltafp)!=nx*nz)
		err("error reading deltafile=%s",deltafile);
	  fclose(deltafp);
	} else {
	  if(verbose) warn("No input file for delta, setting delta to zero!!!");

		/* Setting delta to zero */
		memset((void *) delta[0], (int) '\0' , nx*nz*FSIZE);
	}


	/* see if there is an input file for gamma */
	if (*gammafile!='\0') {
	  if((gammafp=fopen(gammafile,"r"))==NULL)
		err("cannot open gammafile=%s",gammafile);
	  if (fread(gamma[0],sizeof(float),nx*nz,gammafp)!=nx*nz)
		err("error reading gammafile=%s",gammafile);
	  fclose(gammafp);
	} else {
	  if(verbose) warn("No input file for gamma, setting gamma to zero!!!");
		/* Setting gamma to zero */
		memset((void *) gamma[0], (int) '\0' , nx*nz*FSIZE);
	}


	/* open output file: */
	if( !getparstring("c11_file",&c11_file)) c11_file = "c11_file";
	c11fp = fopen(c11_file,"w");
	if( !getparstring("c13_file",&c13_file)) c13_file = "c13_file";
	c13fp = fopen(c13_file,"w");
	if( !getparstring("c33_file",&c33_file)) c33_file = "c33_file";
	c33fp = fopen(c33_file,"w");
	if( !getparstring("c44_file",&c44_file)) c44_file = "c44_file";
	c44fp = fopen(c44_file,"w");
	if( !getparstring("c66_file",&c66_file)) c66_file = "c66_file";
	c66fp = fopen(c66_file,"w");


	/* loop over gridpoints and do calculations */
	for(ix=0; ix<nx; ++ix){
	  for(iz=0; iz<nz; ++iz){
		c33[ix][iz] = vp[ix][iz]*vp[ix][iz]*rho[ix][iz];
		c44[ix][iz] = vs[ix][iz]*vs[ix][iz]*rho[ix][iz];
		c11[ix][iz] = c33[ix][iz]*(1+2*eps[ix][iz]);
		c66[ix][iz] = c44[ix][iz]*(1+2*gamma[ix][iz]);
		c = c33[ix][iz]*(2*c44[ix][iz]*(1+delta[ix][iz])-
				c33[ix][iz]*(1+2*delta[ix][iz]));
		b = 2*c44[ix][iz];
		c13[ix][iz] = (-b+sqrt(b*b-4*c))/2;
	  }
	}


	/* write the output files to disk */
	efwrite(*c11,sizeof(float),nz*nx,c11fp);
	efwrite(*c13,sizeof(float),nz*nx,c13fp);
	efwrite(*c33,sizeof(float),nz*nx,c33fp);
	efwrite(*c44,sizeof(float),nz*nx,c44fp);
	efwrite(*c66,sizeof(float),nz*nx,c66fp);
		if(verbose){
	  warn("Output file for c11 parameter plane : %s ",c11_file);
	  warn("Output file for c13 parameter plane : %s ",c13_file);
	  warn("Output file for c33 parameter plane : %s ",c33_file);
	  warn("Output file for c44 parameter plane : %s ",c44_file);
	  warn("Output file for c66 parameter plane : %s ",c66_file);
	}


	/* free workspace */
	free2float(vp);
	free2float(vs);
	free2float(rho);
	free2float(eps);
	free2float(delta);
	free2float(gamma);
	free2float(c11);
	free2float(c13);
	free2float(c33);
	free2float(c44);
	free2float(c66);

	return EXIT_SUCCESS;	
}
