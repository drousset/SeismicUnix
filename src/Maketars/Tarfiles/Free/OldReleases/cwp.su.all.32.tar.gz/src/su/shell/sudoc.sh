#! /bin/sh
# /*********************** self documentation **********************/
# SUDOC - get DOC listing for code
#
# Usage: sudoc name
#
# Note: Use this shell script to get selfdoc information for
# codes labeled with and asterisk (*) or pound sign (#) in suname list      
# /**************** end self doc ********************************/
#set -x


# $Source: /usr/local/cwp/src/su/shell/RCS/sudoc.sh,v $
# $Revision: 1.12 $ ; $Date: 1998/03/31 19:08:31 $

# test for CWPROOT
if test "${CWPROOT}" = ""
then
	echo "The environment variable \"CWPROOT\" "
	echo "is not set in the user's working shell environment."
	echo "To set this variable in C-shell, use the command: "
	echo "  setenv  CWPROOT  /your/cwp/root/path"
	echo "To set this variable in Bourne or Korn-shell, use the command:"
	echo "  export  CWPROOT=/your/cwp/root/path" ; exit 1

fi


################################################################################
# test for CWPSRC, use value if set, define as $CWPROOT if not set
# (CWPSRC allows one set of source code and documentation for multiple machines)
################################################################################
if test "${CWPSRC}" = ""
then
CWPSRC=$CWPROOT
fi

ROOT=${CWPROOT}
SRC=${CWPSRC}/src
BIN=$ROOT/bin
STRIP=$SRC/doc/Stripped

PATH=/bin:/usr/bin:/usr/ucb:$BIN


# test to see if user has a preferred PAGER
if test "$PAGER" = ""
	then
		PAGE_PROGRAM=more
	else
		PAGE_PROGRAM=$PAGER
	fi


case $# in
1) #OK

	cd ${STRIP}

	NAME=`echo $1 | tr [A-Z] [a-z]`

	SHELLS="cwp/shell par/shell psplot/shell su/shell "

	LIBS=" cwp/lib par/lib psplot/lib xplot/lib tri/lib Xtcwp/lib  \
                Xmcwp/lib su/lib "

	MAINS="cwp/main par/main psplot/main xplot/main \
	        Xtcwp/main Xmcwp/main su/graphics/psplot su/main \
                su/graphics/psplot su/graphics/xplot tri/main \
                tri/graphics/psplot "

	EXISTS=no
	# loop through file extension types 
	for i in $SHELLS $LIBS $MAINS
	do
		EXTENSION=`echo $i | sed 's/\//\./g'`
		if [ -f "$STRIP/$NAME.$EXTENSION" ]
		then
			echo "In $CWPROOT/src/$i: "
			$PAGE_PROGRAM ${STRIP}/$NAME.$EXTENSION
			EXISTS=yes
		fi
	done

	if [ "$EXISTS" = "no" ]
	then 
		echo "There is no entry in the docs for \"$1\"" 2>&1 ; exit 1
	fi
;;
*) # echo usage message
	echo "Usage:  sudoc program_name"
esac

exit 0

