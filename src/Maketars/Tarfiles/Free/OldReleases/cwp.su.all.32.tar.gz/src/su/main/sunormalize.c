/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SUNORMALIZE: $Revision: 1.7 $ ; $Date: 1996/03/26 20:57:27 $	*/

#include "su.h"
#include "segy.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 	   							",
" SUNORMALIZE - Trace balancing by rms, max, or median		", 
" 	   							",
"   sunormalize <stdin >stdout t0=0 t1=TMAX norm=rms		",
" 								",
" Required parameters:						",
"	dt=tr.dt	if not set in header, dt is mandatory	",
"	ns=tr.ns	if not set in header, ns is mandatory	",
"								",
" Optional parameters:						",
"	norm=rms	Type of norm rms, max, med  		",	
"	t0=0.0		Strartimg time for Window  		",	
"	t1=TMAX		Ending time for Window     		",	
"								",
NULL};

/*
 * Author: Ramone Carbonell, Inst. Earth Sciences-CSIC Barcelona, Spain.
 * April 1998
 *
 * Trace header fields accessed: ns, dt
 * Trace header fields modified: none
 */
/**************** end self doc ***********************************/

/* Definitions */
#define NORM_RMS 0
#define NORM_MAX 1
#define NORM_MED 2


/* Prototypes for subroutines used internally */
int vrmedian(float *x,float *r,float *y,int *n);
void rmvesq(float *r,float *rsq,int *n);
void maxmgv(float *r,float *rmx,int *n);

segy tr;

int
main(int argc, char **argv)
{
	int ns;			/* number of samples		*/
	int it0;		/* first sample of time window	*/
	int it1;		/* last sample of time window	*/

	int n;			/* size of temporary arrays 	*/
	int i;			/* counter			*/
	int itmp;		/* temporary variable		*/

	float dt;		/* time sampling interval	*/
	float t0;		/* first time of time window	*/
	float t1;		/* ending time of time window	*/

	float rms;		/* rms 				*/
	float *tmp;		/* temporary array		*/
	float *z;		/* array			*/

        cwp_String norm="rms";	/* name of normalization	*/
	int inorm=NORM_RMS;	/* integer representing norm	*/

	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);

	/* Get parameters */
	if (!fgettr(stdin, &tr)) err("can't read first trace");
	if (!tr.dt) MUSTGETPARFLOAT("dt", &dt);
	if (!tr.ns) MUSTGETPARINT("ns", &ns);
	ns = (int) tr.ns;
	dt = ((double) tr.dt)/1000000.0;	
	if (!getparfloat("t0", &t0))	 t0=0;
	if (!getparfloat("t1", &t1))	 t1=ns*dt;

	/* Define integerized times */
        it0=t0/dt;
        it1=t1/dt;
        n=it1-it0; 

	/* Allocate space for temporary arrays */
        tmp=ealloc1float(n);
        z= ealloc1float(n);

	/* get norm type */
        getparstring("norm", &norm);
        if      (STREQ(norm, "max"))    inorm = NORM_MAX;
        else if (STREQ(norm, "med"))    inorm = NORM_MED;
        else if (!STREQ(norm, "rms"))
                err("unknown operation=\"%s\", see self-doc", norm);

	/* Loop over traces */
	do {
		switch(inorm) { /* beginning of cases */
		case NORM_RMS:
		{
                	rmvesq(&tr.data[it0],&rms,&n); 
                	if (rms==0.0) rms=1.;
			for (i=0;i<ns;i++) tr.data[i]=tr.data[i]/rms;
		}
		break;	
		case NORM_MED:
		{
                	memcpy((void *) z,(const void *) &tr.data[it0],
						n*sizeof(float));
                	itmp=vrmedian(z,&rms,tmp,&n); 
                	if (rms==0.0) rms=1.;
			for (i=0;i<ns;i++) tr.data[i]=tr.data[i]/rms;
		}
		break;	
		case NORM_MAX:
		{
                	maxmgv(&tr.data[it0],&rms,&n); 
              		if (rms==0.0) rms=1.;
			for (i=0;i<ns;i++) tr.data[i]=tr.data[i]/rms;
		}
		break;
		default:  /* defensive programming */
                        err("mysterious operation=\"%s\"", norm);
                } /* end of cases */
		
		puttr(&tr);
	} while (gettr(&tr));
        	
	return EXIT_SUCCESS;
}

int vrmedian(float *x,float *r,float *y,int *n)
/* vrmedian -- compute the median */
{
    int  two=2;
    div_t dv;

    dv=div(*n,two);

    qksort(*n,x);
    if ( dv.rem) *r=x[dv.quot];
    if (!dv.rem) *r=(x[dv.quot]+x[dv.quot+1])/2.;
    return EXIT_SUCCESS;
}

void maxmgv(float *r,float *rmx,int *n)
/* find the maximum */
{
   int  j;
 
   *rmx=(fabs)(*(r));
   for (j=0;j<(*n);j++) {
       if ( (fabs)(*(r+j)) > (*rmx) ) (*rmx)=(fabs)(*(r+j));
   }
}

 
void rmvesq(float *r,float *rsq,int *n)
/* compute RMS */
{
   int  j;
 
   for (j=0;j<(*n);j++) {
       (*rsq)=(*(r+j))*(*(r+j));
   }
   *rsq=(sqrt(*rsq))/(*n);
}
