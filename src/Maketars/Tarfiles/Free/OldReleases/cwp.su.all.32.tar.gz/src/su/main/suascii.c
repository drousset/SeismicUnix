/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SUASCII: $Revision: 1.11 $ ; $Date: 1996/09/05 19:01:06 $	*/

#include "su.h"
#include "segy.h"

/*********************** self documentation **********************/
char *sdoc[] = {
" 								",
" SUASCII - print non zero header values and data		",
" 								",
" suascii <stdin >ascii_file					",
" 								",
" Optional parameter:						",
"	bare=0		print headers and data			",
"			bare=1 print only data 			",
"			bare=2 print headers only		",
" 								",
" Notes: suwind/suus provide trace selection and/or subsampling.",
"	 with bare=1 traces are separated by a blank line.	",
" 						        	",
NULL};

/* Credits:
 *	CWP: Jack
 *
 * Trace header field accessed: ns
 */
/**************** end self doc ***********************************/


segy tr;

int
main(int argc, char **argv)
{
	int bare;

	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get parameter */
	if (!getparint("bare", &bare))	bare=0;

	/* Loop over traces converting to ascii */
	while (gettr(&tr)) {
		register int i;

		if ( bare==0 || bare==2 )  printheader(&tr);

		if (bare==0 || bare==1) {
			for (i = 0; i < (int) tr.ns; ++i) {
				if (bare==0)  printf("%5d ", i+1);
				printf("%11.4e\n", tr.data[i]);
			}
			putchar('\n');
		}

	}


	return EXIT_SUCCESS;
}
