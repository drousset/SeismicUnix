/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SEGYWRITE: $Revision: 1.40 $ ; $Date: 1998/03/26 22:47:49 $    */

#ifdef SUXDR

#include "su_xdr.h"
#include "tapesegy.h"
#include "bheader.h"

/*********************** self documentation **********************/
char *sdoc[] = {
"                                                                       ",
" SEGYWRITE - write an SEG-Y tape                                       ",
"                                                                       ",
" segywrite <stdin                                                      ",
"                                                                       ",
" Required parameters:                                                  ",
"       tape=           tape device or disk filename to use             ",
"                                                                       ",
" Optional parameter:                                                   ",
"       verbose=0       silent operation                                ",
"                       =1 ; echo every 'vblock' traces                 ",
"       vblock=50       echo every 'vblock' traces under verbose option ",
"       buff=1          for buffered device (9-track reel tape drive)   ",
"                       =0 possibly useful for 8mm EXABYTE drive	",
"	conv=1		=0 don't convert to IBM format			",
"       hfile=header    ebcdic card image header file                   ",
"       bfile=binary    binary header file                              ",
"       trmin=1         first trace to write                            ",
"       trmax=INT_MAX   last trace to write                             ",
"       endian=1        =0 for little-endian machines (PC's, DEC,etc...)",
"       errmax=0        allowable number of consecutive tape IO errors  ",
"                                                                       ",
" Note: The header files may be created with  'segyhdrs'.               ",
"                                                                       ",
"                                                                       ",
" Note: For buff=1 (default) tape is accessed with 'write', for buff=0  ",
"       tape is accessed with fwrite. Try the default setting of buff=1 ",
"       for all tape types.                                             ",
" Caveat: may be slow on an 8mm streaming (EXABYTE) tapedrive           ",
" Warning: segyread or segywrite to 8mm tape is fragile. Allow time     ",
"          between successive reads and writes.                         ",
" Precaution: make sure tapedrive is set to read/write variable blocksize",
"          tapefiles.                                                   ",
"                                                                       ",
" For more information, type:   sudoc <segywrite>                       ",
NULL};

/*
 * Warning: may return the error message "efclose: fclose failed"
 *       intermittently when segyreading/segywriting to 8mm EXABYTE tape,
 *       even if actual segyread/segywrite is successful. However, this
 *       may indicate that your tape drive has been set to a fixed block
 *       size. Tape drives should be set to variable block size before reading
 *       or writing tapes in the SEG-Y format.
 */

/* Credits:
 *      SEP: Einar Kjartansson
 *      CWP: Jack, Brian, Chris
 *         : John Stockwell (added EXABYTE functionality)
 * Notes:
 *      Brian's subroutine, float_to_ibm, for converting IEEE floating
 *      point to IBM floating point is NOT portable and must be
 *      altered for non-IEEE machines.  See the subroutine notes below.
 *
 *      On machines where shorts are not 2 bytes and/or ints are not 
 *      4 bytes, routines to convert SEGY 16 bit and 32 bit integers 
 *      will be required.
 *
 *      The program, segyhdrs, can be used to make the ascii and binary
 *      files required by this code.
 */

/**************** end self doc ***********************************/
/*
 * Revised:  7/5/95  Stewart A. Levin   (Mobil)
 *         Use xdr routines for portability.
 *         Add CRAY support for floating point conversions.
 * Revised:  4/4/96  Stewart A. Levin   (Mobil)
 *         Direct ascii to ebcdic conversion
 */

/* subroutine prototypes */
#if defined(_CRAYMPP)
typedef short fourbyte;
#else
typedef int fourbyte;
#endif
static void float_to_ibm(fourbyte *from, fourbyte *to, int n, int endian);
static void zebc(char *input,char *output, int nchar);

static segy tr;
static bhed bh;

int
main(int argc, char **argv)
{
        cwp_String tape;        /* name of raw tape device              */
        cwp_String hfile;       /* name of ebcdic header file           */
        cwp_String bfile;       /* name of binary header file           */

        FILE *tapefp;           /* file pointer for tape                */
        FILE *headerfp;         /* file pointer for hfile               */
        FILE *binaryfp;         /* file pointer for bfile               */

        int tapefd;             /* file discriptor for tape buff=0      */

        int i,j;                /* counter                              */
        int ns;                 /* number of data samples               */
        size_t nsegy;           /* size of whole trace in bytes         */
        int itr;                /* current trace number                 */
        int trmax;              /* last trace to write                  */
        int trmin;              /* first trace to write                 */
        int verbose;            /* echo every ...                       */
        int vblock;             /* ... vblock traces with verbose=1     */
        int buff;               /* buffered or unbuffered device        */
        int endian;             /* =0 little endian; =1 big endian      */
        int conv;               /* =1 IBM format =0 don't convert	*/
        int errmax;             /* max consecutive tape io errors       */
        int errcount = 0;       /* counter for tape io errors           */
#if defined(CRAY)
#if defined(_CRAYMPP)
	fourbyte imone = -1;	/* constant for Fortran linkage		*/
        fourbyte fns;           /* for Fortran CRAYMPP linkage          */
#else
	int ier;		/* CRAY ibmfloat error flag		*/
	fourbyte ione = 1;	/* constant for Fortran linkage		*/
#endif
#endif
        char ebcbuf[EBCBYTES+1];  /* ebcdic data buffer                 */
	char bhbuf[BNYBYTES];   /* binary reel header buffer		*/
	char *trbuf;            /* output trace buffer 			*/
	XDR  bhed_xdr, bhbuf_xdr; /* for handling binary reel header    */
	XDR  trhd_xdr;
	unsigned int trstart;   /* "offset" of trhd stream buffer 	*/


        /* Initialize */
        initargs(argc, argv);
        requestdoc(1);


        /* Get parameters */
        MUSTGETPARSTRING("tape", &tape);
        if (!getparstring("hfile", &hfile))     hfile = "header";
        if (!getparstring("bfile", &bfile))     bfile = "binary";
        if (!getparint   ("trmin", &trmin))     trmin = 1;
        if (!getparint   ("trmax", &trmax))     trmax = INT_MAX;
        if (!getparint   ("verbose", &verbose)) verbose = 0;
        if (!getparint   ("vblock", &vblock))   vblock = 50;
        if (!getparint   ("buff", &buff))       buff = 1;
        if (!getparint   ("conv", &conv))       conv = 1;
        if (!getparint   ("endian", &endian))   endian = 1;
        if (!getparint   ("errmax", &errmax))   errmax = 0;
        
        /* Check parameters */
        if (trmin < 1 || trmax < 1 || trmax < trmin)
                err("bad trmin/trmax values, trmin = %d, trmax = %d",
                        trmin, trmax);

        /* Get first trace early to be sure that binary file is ready */
        gettr(&tr);

        /* Open files - first the tape */
        if (buff) tapefd = eopen(tape, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        else tapefp = efopen(tape, "w");
        if (verbose) warn("tape opened successfully ");

        /* Open ascii header file */
	headerfp = efopen(hfile, "r");

        if (verbose) warn("header file opened successfully");

        /* - binary header file */
        binaryfp = efopen(bfile, "r");
	xdrstdio_create(&bhed_xdr,binaryfp,XDR_DECODE);
	xdrmem_create(&bhbuf_xdr,bhbuf,BNYBYTES,XDR_ENCODE);

        if (verbose) warn("binary file opened successfully");

        /* Read ascii header into buffer and blank newlines & nulls */
	memset(&(ebcbuf[0]),' ',EBCBYTES);
	for(i = 0; i<EBCBYTES; i += 80) {
		fgets(&(ebcbuf[i]),81, headerfp);
                j = (int) strlen(&(ebcbuf[i]));
		ebcbuf[i+j] = ' ';
		j--;
		if(ebcbuf[j] == '\n') ebcbuf[j] = ' ';
	}
	/* Convert to EBCDIC */
        zebc(&(ebcbuf[0]),&(ebcbuf[0]),EBCBYTES);

        efclose(headerfp);
        if (verbose) warn("header file closed successfully");

        /* Write ebcdic stream to tape */
        if (buff) {
                if (EBCBYTES != write(tapefd, ebcbuf, EBCBYTES)) {
                        if (verbose)
                                warn("tape write error on ebcdic header");
                        if (++errcount > errmax)
                                err("exceeded maximum io errors");
                } else { /* Reset counter on successful tape IO */
                        errcount = 0;
                }
        } else {
                 fwrite(ebcbuf, 1, EBCBYTES, tapefp);
                 if (ferror(tapefp)) {
                        if (verbose)
                                warn("tape write error on ebcdic header");
                        if (++errcount > errmax)
                                err("exceeded maximum io errors");
                        clearerr(tapefp);
                } else { /* Reset counter on successful tape IO */
                        errcount = 0;
                }
        }

        /* Read binary file into bh structure */
	xdrbhdrsub(&bhed_xdr, &bh);

	/* update requisite field */
        bh.format = 1;  /* indicate SEG-Y data  */
        bh.ntrpr  = 1;  /* one trace per record */

        /* Compute trace size (can't use HDRBYTES here!) */
        ns = bh.hns;
        if (!ns) err("bh.hns not set in binary header");
        nsegy = ns*4 + SEGY_HDRBYTES;

        /* Convert from ints/shorts to bytes */
        xdrbhdrsub(&bhbuf_xdr,&bh);

        /* Write binary structure to tape */
        if (buff) {
                if (BNYBYTES != write(tapefd, bhbuf, BNYBYTES)) {
                        if (verbose)
                                warn("tape write error on binary header");
                        if (++errcount > errmax)
                                err("exceeded maximum io errors");
                } else { /* Reset counter on successful tape IO */
                        errcount = 0;
                }
        } else {
                 fwrite(bhbuf, 1, BNYBYTES, tapefp);
                 if (ferror(tapefp)) {
                        if (verbose)
                                warn("tape write error on binary header");
                        if (++errcount > errmax)
                                err("exceeded maximum io errors");
                        clearerr(tapefp);
                } else { /* Reset counter on successful tape IO */
                        errcount = 0;
                }
        }


        /* Copy traces from stdin to tape */
	trbuf = (char *) alloc1(nsegy, sizeof(char));
	xdrmem_create(&trhd_xdr,trbuf,(unsigned int) nsegy,XDR_ENCODE);
	trstart = xdr_getpos(&trhd_xdr);

        itr = 0;
        do {

                /* Set/check trace header words */
                tr.tracr = ++itr;
                if (tr.ns != ns)
                        err("conflict: tr.ns = %d, bh.ns = %d: trace %d",
                                        tr.ns, ns, itr);

                /* Convert and write desired traces */
                if (itr >= trmin) {

         		/* convert trace header to SEGY standard */       
			if(FALSE == xdr_setpos(&trhd_xdr,trstart)) 
			    err("%s: trouble \"seeking\" start of trace",
				__FILE__);
			xdrhdrsub(&trhd_xdr,&tr);

                        /* Convert internal floats to IBM floats */
			if (conv) {
#if defined(CRAY)
#if defined(_CRAYMPP)
			    float_to_ibm((fourbyte *) (&(tr.data[0])),
					 (fourbyte *) (&(tr.data[0])),
					 ns, endian);
/* Stew's Fortran routine...
                            fns = ns;
                            IBMFLT(tr.data,tr.data,&fns,&imone);
*/
#else /* !_CRAYMPP */
			    USSCTI(tr.data,tr.data,&ione,&ns,&ier);
#endif /* _CRAYMPP */
#else /* !CRAY */
			    float_to_ibm((fourbyte *) (&(tr.data[0])),
					 (fourbyte *) (&(tr.data[0])),
					 ns, endian);
#endif /* !CRAY */
			    memcpy(trbuf+SEGY_HDRBYTES,(char *) tr.data,
				ns*4*sizeof(char));
			} else {
			    xdr_vector(&trhd_xdr,(char *) tr.data,
				ns, sizeof(float), xdr_float);
			}
                        
                        /* Write the trace to tape */
                        if (buff) {
                            if (nsegy !=
                               write(tapefd, trbuf, nsegy)){
                                if (verbose)
                                    warn("tape write error on trace %d", itr);
                                if (++errcount > errmax)
                                    err("exceeded maximum io errors");
                            } else { /* Reset counter on successful tape IO */
                                errcount = 0;
                            }
                        } else {
                            fwrite(trbuf,sizeof(char),nsegy,tapefp);
                            if (ferror(tapefp)) {
                                if (verbose)
                                    warn("tape write error on trace %d", itr);
                                if (++errcount > errmax)
                                    err("exceeded maximum io errors");
                                    clearerr(tapefp);
                            } else { /* Reset counter on successful tape IO */
                                errcount = 0;
                            }
                        }

                        /* Echo under verbose option */
                        if (verbose && itr % vblock == 0)
                                warn(" %d traces written to tape", itr);
                }
        } while (gettr(&tr) && itr < trmax);


        /* Clean up */
        (buff) ?  eclose(tapefd) :
                  efclose(tapefp);
        if (verbose) warn("tape closed successfully");

        xdr_destroy(&trhd_xdr);
	xdr_destroy(&bhed_xdr);
	xdr_destroy(&bhbuf_xdr);
        efclose(binaryfp);
        if (verbose) warn("binary file closed successfully");

        return EXIT_SUCCESS;
}

/* Assumes fourbyte == 4 byte integer */
static void float_to_ibm(fourbyte *from, fourbyte *to, int n, int endian)
/**********************************************************************
 float_to_ibm - convert between 32 bit IBM and IEEE floating numbers
*********************************************************************** 
Input:
from       input vector
n          number of floats in vectors
endian     =0 for little endian machine, =1 for big endian machines

Output:
to         output vector, can be same as input vector

*********************************************************************** 
Notes:
Up to 3 bits lost on IEEE -> IBM

IBM -> IEEE may overflow or underflow, taken care of by 
substituting large number or zero

Only integer shifting and masking are used.
*********************************************************************** 
Credits:     CWP: Brian Sumner
***********************************************************************/
{
    register fourbyte fconv, fmant, t;
    register int i;

    for (i=0;i<n;++i) {
        fconv = from[i];
        if (fconv) {
            fmant = (0x007fffff & fconv) | 0x00800000;
            t = (fourbyte) ((0x7f800000 & fconv) >> 23) - 126;
            while (t & 0x3) { ++t; fmant >>= 1; }
            fconv = (0x80000000 & fconv) | (((t>>2) + 64) << 24) | fmant;
        }
        if(endian==0)
                fconv = (fconv<<24) | ((fconv>>24)&0xff) |
                        ((fconv&0xff00)<<8) | ((fconv&0xff0000)>>8);

        to[i] = fconv;
    }
    return;
}
void zebc(char *input,char *output, int nchar)
/*************************************************************************
zasc -- convert strings from ASCII to EBCDIC

char *input    input string of ASCII characters
char *output   output string of EBCDIC characters (may be same as input)
int nchar      number of characters to convert
**************************************************************************/
{
  static unsigned char const ascii_to_ebcdic[] =
  {
  0, 01, 02, 03, 067, 055, 056, 057,
  026, 05, 045, 013, 014, 015, 016, 017,
  020, 021, 022, 023, 074, 075, 062, 046,
  030, 031, 077, 047, 034, 035, 036, 037,
  0100, 0117, 0177, 0173, 0133, 0154, 0120, 0175,
  0115, 0135, 0134, 0116, 0153, 0140, 0113, 0141,
  0360, 0361, 0362, 0363, 0364, 0365, 0366, 0367,
  0370, 0371, 0172, 0136, 0114, 0176, 0156, 0157,
  0174, 0301, 0302, 0303, 0304, 0305, 0306, 0307,
  0310, 0311, 0321, 0322, 0323, 0324, 0325, 0326,
  0327, 0330, 0331, 0342, 0343, 0344, 0345, 0346,
  0347, 0350, 0351, 0112, 0340, 0132, 0137, 0155,
  0171, 0201, 0202, 0203, 0204, 0205, 0206, 0207,
  0210, 0211, 0221, 0222, 0223, 0224, 0225, 0226,
  0227, 0230, 0231, 0242, 0243, 0244, 0245, 0246,
  0247, 0250, 0251, 0300, 0152, 0320, 0241, 07,
  040, 041, 042, 043, 044, 025, 06, 027,
  050, 051, 052, 053, 054, 011, 012, 033,
  060, 061, 032, 063, 064, 065, 066, 010,
  070, 071, 072, 073, 04, 024, 076, 0341,
  0101, 0102, 0103, 0104, 0105, 0106, 0107, 0110,
  0111, 0121, 0122, 0123, 0124, 0125, 0126, 0127,
  0130, 0131, 0142, 0143, 0144, 0145, 0146, 0147,
  0150, 0151, 0160, 0161, 0162, 0163, 0164, 0165,
  0166, 0167, 0170, 0200, 0212, 0213, 0214, 0215,
  0216, 0217, 0220, 0232, 0233, 0234, 0235, 0236,
  0237, 0240, 0252, 0253, 0254, 0255, 0256, 0257,
  0260, 0261, 0262, 0263, 0264, 0265, 0266, 0267,
  0270, 0271, 0272, 0273, 0274, 0275, 0276, 0277,
  0312, 0313, 0314, 0315, 0316, 0317, 0332, 0333,
  0334, 0335, 0336, 0337, 0352, 0353, 0354, 0355,
  0356, 0357, 0372, 0373, 0374, 0375, 0376, 0377
  };
  int i;
  for(i=0;i<nchar;i++) {
      output[i]=ascii_to_ebcdic[input[i]];
  }
  return;
}
#else

/* SEGYWRITE: $Revision: 1.40 $ ; $Date: 1998/03/26 22:47:49 $    */

#include "su.h"
#include "segy.h"
#include "tapesegy.h"
#include "tapebhdr.h"
#include "bheader.h"

/*********************** self documentation **********************/
char *sdoc[] = {
"									",
" SEGYWRITE - write an SEG-Y tape					",
"									",
" segywrite <stdin tape=						",
"									",
" Required parameters:							",
"	tape=		tape device to use (see sudoc segyread)		",
"									",
" Optional parameter:							",
"	verbose=0	silent operation				",
"			=1 ; echo every 'vblock' traces			",
"	vblock=50	echo every 'vblock' traces under verbose option ",
"	buff=1		for buffered device (9-track reel tape drive)	",
"			=0 possibly useful for 8mm EXABYTE drive	",
"	conv=1		=0 don't convert to IBM format			",
"	hfile=header	ebcdic card image header file			",
"	bfile=binary	binary header file				",
"	trmin=1 first trace to write					",
"	trmax=INT_MAX  last trace to write			       ",
"	endian=1	=0 for little-endian machines (PC's, DEC,etc...)",
"	errmax=0	allowable number of consecutive tape IO errors	",
"									",
" Note: The header files may be created with  'segyhdrs'.		",
"									",
"									",
" Note: For buff=1 (default) tape is accessed with 'write', for buff=0	",
"	tape is accessed with fwrite. Try the default setting of buff=1 ",
"	for all tape types.						",
" Caveat: may be slow on an 8mm streaming (EXABYTE) tapedrive		",
" Warning: segyread or segywrite to 8mm tape is fragile. Allow time	",
"	   between successive reads and writes.				",
" Precaution: make sure tapedrive is set to read/write variable blocksize",
"	   tapefiles.							",
"									",
" For more information, type:	sudoc <segywrite>			",
NULL};

/*
 * Warning: may return the error message "efclose: fclose failed"
 *	 intermittently when segyreading/segywriting to 8mm EXABYTE tape,
 *	 even if actual segyread/segywrite is successful. However, this
 *	 may indicate that your tape drive has been set to a fixed block
 *	 size. Tape drives should be set to variable block size before reading
 *	 or writing tapes in the SEG-Y format.
 */

/* Credits:
 *	SEP: Einar Kjartansson
 *	CWP: Jack, Brian, Chris
 *	   : John Stockwell (added EXABYTE functionality)
 * Notes:
 *	Brian's subroutine, float_to_ibm, for converting IEEE floating
 *	point to IBM floating point is NOT portable and must be
 *	altered for non-IEEE machines.	See the subroutine notes below.
 *
 *	On machines where shorts are not 2 bytes and/or ints are not 
 *	4 bytes, routines to convert SEGY 16 bit and 32 bit integers 
 *	will be required.
 *
 *	The program, segyhdrs, can be used to make the ascii and binary
 *	files required by this code.
 */

/**************** end self doc ***********************************/

/* subroutine prototypes */
static void float_to_ibm(int from[], int to[], int n, int endian);
static void bhed_to_tapebhed(const bhed *bhptr, tapebhed *tapebhptr); 
static void
	segy_to_tapesegy(const segy *trptr, tapesegy *tapetrptr, size_t nsegy); 

tapesegy tapetr;
tapebhed tapebh;
segy tr;
bhed bh;

int
main(int argc, char **argv)
{
	cwp_String tape;	/* name of raw tape device		*/
	cwp_String hfile;	/* name of ebcdic header file		*/
	cwp_String bfile;	/* name of binary header file		*/

	FILE *pipefp;		/* file pointer for popen read		*/
	FILE *tapefp=NULL;	/* file pointer for tape		*/
	FILE *binaryfp;		/* file pointer for bfile		*/

	int tapefd=0;		/* file descriptor for tape buff=0	*/

	int i;			/* counter				*/
	int ns;			/* number of data samples		*/
	size_t nsegy;		/* size of whole trace in bytes		*/
	int itr;		/* current trace number			*/
	int trmax;		/* last trace to write			*/
	int trmin;		/* first trace to write			*/
	int verbose;		/* echo every ...			*/
	int vblock;		/* ... vblock traces with verbose=1	*/
	int buff;		/* buffered or unbuffered device	*/
	int endian;		/* =0 little endian; =1 big endian	*/
	int conv;		/* =1 IBM format =0 don't convert	*/
	int errmax;		/* max consecutive tape io errors	*/
	int errcount = 0;	/* counter for tape io errors		*/
	char cmdbuf[BUFSIZ];	/* dd command buffer			*/
	char ebcbuf[EBCBYTES];	/* ebcdic data buffer			*/


	/* Initialize */
	initargs(argc, argv);
	requestdoc(1);


	/* Get parameters */
	MUSTGETPARSTRING("tape", &tape);
	if (!getparstring("hfile", &hfile))	hfile = "header";
	if (!getparstring("bfile", &bfile))	bfile = "binary";
	if (!getparint	 ("trmin", &trmin))	trmin = 1;
	if (!getparint	 ("trmax", &trmax))	trmax = INT_MAX;
	if (!getparint	 ("verbose", &verbose)) verbose = 0;
	if (!getparint	 ("vblock", &vblock))	vblock = 50;
	if (!getparint	 ("buff", &buff))	buff = 1;
	if (!getparint	 ("conv", &conv))	conv = 1;
	if (!getparint	 ("endian", &endian))	endian = 1;
	if (!getparint	 ("errmax", &errmax))	errmax = 0;
	
	/* Check parameters */
	if (trmin < 1 || trmax < 1 || trmax < trmin)
		err("bad trmin/trmax values, trmin = %d, trmax = %d",
			trmin, trmax);

	/* Get first trace early to be sure that binary file is ready */
	gettr(&tr);

	/* Open files - first the tape */
	if (buff) tapefd = eopen(tape, O_WRONLY | O_CREAT | O_TRUNC, 0666);
	else tapefp = efopen(tape, "w");
	if (verbose) warn("tape opened successfully ");

	/* - binary header file */
	binaryfp = efopen(bfile, "r");
	if (verbose) warn("binary file opened successfully");

	/* Open pipe to use dd to convert ascii to ebcdic */
	sprintf(cmdbuf, "dd if=%s conv=ebcdic cbs=80 obs=3200", hfile);
	pipefp = epopen(cmdbuf, "r");

	/* Read ebcdic stream from pipe into buffer */
	efread(ebcbuf, 1, EBCBYTES, pipefp);

	/* Write ebcdic stream to tape */
	if (buff) {
		if (EBCBYTES != write(tapefd, ebcbuf, EBCBYTES)) {
			if (verbose)
				warn("tape write error on ebcdic header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	} else {
		 fwrite(ebcbuf, 1, EBCBYTES, tapefp);
		 if (ferror(tapefp)) {
			if (verbose)
				warn("tape write error on ebcdic header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
			clearerr(tapefp);
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	}

	/* Read binary file into bh structure */
	efread((char *) &bh, 1, BNYBYTES, binaryfp);
	bh.format = 1;	/* indicate SEG-Y data	*/

	if (bh.ntrpr == 0) bh.ntrpr  = 1;	/* one trace per record */

	/* Compute trace size (can't use HDRBYTES here!) */
	ns = bh.hns;
	if (!ns) err("bh.hns not set in binary header");
	nsegy = ns*4 + SEGY_HDRBYTES;

	/* if little endian (endian=0) swap bytes of binary header */
	if (endian==0) for (i = 0; i < BHED_NKEYS; ++i) swapbhval(&bh,i);

	/* Convert from ints/shorts to bytes */
	bhed_to_tapebhed(&bh, &tapebh);

	/* Write binary structure to tape */
	if (buff) {
		if (BNYBYTES != write(tapefd, (char *) &tapebh, BNYBYTES)) {
			if (verbose)
				warn("tape write error on binary header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	} else {
		 fwrite((char *) &tapebh, 1, BNYBYTES, tapefp);
		 if (ferror(tapefp)) {
			if (verbose)
				warn("tape write error on binary header");
			if (++errcount > errmax)
				err("exceeded maximum io errors");
			clearerr(tapefp);
		} else { /* Reset counter on successful tape IO */
			errcount = 0;
		}
	}


	/* Copy traces from stdin to tape */
	itr = 0;
	do {

		/* Set/check trace header words */
		tr.tracr = ++itr;
		if (tr.ns != ns)
			err("conflict: tr.ns = %d, bh.ns = %d: trace %d",
					tr.ns, ns, itr);

		/* Convert and write desired traces */
		if (itr >= trmin) {

		
			/* Convert internal floats to IBM floats */
			if (conv)
				float_to_ibm((int *) tr.data, (int *) tr.data,
								ns, endian);

		       /* handle no ibm conversion for little endian case */
		       if (conv==0 && endian==0)
				for (i = 0; i < ns ; ++i)
					swap_float_4(&tr.data[i]);
			
			/* if little endian, swap bytes in header */
			if (endian==0)
			    for (i = 0; i < SEGY_NKEYS; ++i) swaphval(&tr,i);

			/* Convert from ints/shorts to bytes */
			segy_to_tapesegy(&tr, &tapetr, nsegy);

			/* Write the trace to tape */
			if (buff) {
			    if (nsegy !=
			       write(tapefd, (char *) &tapetr, nsegy)){
				if (verbose)
				    warn("tape write error on trace %d", itr);
				if (++errcount > errmax)
				    err("exceeded maximum io errors");
			    } else { /* Reset counter on successful tape IO */
				errcount = 0;
			    }
			} else {
			    fwrite((char *)&tapetr,1,nsegy,tapefp);
			    if (ferror(tapefp)) {
				if (verbose)
				    warn("tape write error on trace %d", itr);
				if (++errcount > errmax)
				    err("exceeded maximum io errors");
				    clearerr(tapefp);
			    } else { /* Reset counter on successful tape IO */
				errcount = 0;
			    }
			}

			/* Echo under verbose option */
			if (verbose && itr % vblock == 0)
				warn(" %d traces written to tape", itr);
		}
	} while (gettr(&tr) && itr < trmax);


	/* Clean up */
	(buff) ?  eclose(tapefd) :
		  efclose(tapefp);
	if (verbose) warn("tape closed successfully");

	efclose(binaryfp);
	if (verbose) warn("binary file closed successfully");

	epclose(pipefp);

	return EXIT_SUCCESS;
}

/* Assumes sizeof(int) == 4 */
static void float_to_ibm(int from[], int to[], int n, int endian)
/**********************************************************************
 float_to_ibm - convert between 32 bit IBM and IEEE floating numbers
*********************************************************************** 
Input:
from	   input vector
n	   number of floats in vectors
endian	   =0 for little endian machine, =1 for big endian machines

Output:
to	   output vector, can be same as input vector

*********************************************************************** 
Notes:
Up to 3 bits lost on IEEE -> IBM

IBM -> IEEE may overflow or underflow, taken care of by 
substituting large number or zero

Only integer shifting and masking are used.
*********************************************************************** 
Credits:     CWP: Brian Sumner
***********************************************************************/
{
    register int fconv, fmant, i, t;

    for (i=0;i<n;++i) {
	fconv = from[i];
	if (fconv) {
	    fmant = (0x007fffff & fconv) | 0x00800000;
	    t = (int) ((0x7f800000 & fconv) >> 23) - 126;
	    while (t & 0x3) { ++t; fmant >>= 1; }
	    fconv = (0x80000000 & fconv) | (((t>>2) + 64) << 24) | fmant;
	}
	if(endian==0)
		fconv = (fconv<<24) | ((fconv>>24)&0xff) |
			((fconv&0xff00)<<8) | ((fconv&0xff0000)>>8);

	to[i] = fconv;
    }
    return;
}


static void bhed_to_tapebhed(const bhed *bhptr, tapebhed *tapebhptr)
/***************************************************************************
bhed_tape_bhed -- converts the binary tape header in the machine's short
and int types to, respectively, the seg-y standard 2 byte and 4 byte integer
types.
****************************************************************************
Input:
bhptr		pointer to binary header vector

Output:
tapebhptr	pointer to tape binary header vector
****************************************************************************
Notes:
The present implementation assumes that these types are actually the "right"
size (respectively 2 and 4 bytes), so this routine is only a placeholder for
the conversions that would be need554 SECURITY ALERT: extra data in qf: 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          <Pine.LNX.3.96.980723112803.2714L-100000@wenzel.Mines.EDU>
HMIME-Version: 1.0
HContent-Type: TEXT/PLAIN; charset=US-ASCII
.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           