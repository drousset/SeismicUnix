/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

/* SEGDREAD: $Revision: 1.7 $ ; $Date: 1998/01/20 21:25:51 $     */

#include "su.h"
#include "segy.h"
#include "segd.h"
#include <memory.h>

#define REC_L (20 + 4*SU_NFLTS) /* record size: 20 + 10*(SU_NFLTS)/4 bytes */
#define BCD_FF 255          /* value of FF in bcd */
#define BCD_FFFF 16665      /* value of FFFF in bcd */

/*********************** self documentation **********************/
char *sdoc[] = {
"                                                                      ",
" SEGDREAD - read an SEG-D tape                                        ",
"                                                                      ",
" segdread > stdout tape=                                              ",
"                                                                      ",
"                                                                      ",
" Required parameters:                                                 ",
"       tape=           input tape device                              ",
"                                                                      ",
" Optional parameters:                                                 ",
"       buff=1          for buffered device (9-track reel tape drive)  ",
"                       =0 possibly useful for 8mm EXABYTE drives      ",
"       verbose=0       silent operation                               ",
"                       = 1 ; echo every 'vblock' traces               ",
"                       = 2 ; echo informations about blocks           ",
"       vblock=50       echo every 'vblock' traces under verbose option",
"       ptmin=1         first shot to read                             ",
"       ptmax=INT_MAX   last shot to read                              ",
"       gain=0          no application of gain                         ",
"       aux=0           no recovery of auxiliary traces                ",
"       errmax=0        allowable number of consecutive tape IO errors ",
"                                                                      ",
"  Notes: I have not tested if this program works for segd disk files  ",
"                                                                      ",
"         type:   sudoc segdread   for further information             ",
NULL};

/* Credits:
 *  for version 1:
 *    IPRA, Pau, France: Dominique Rousset, rousset@iprrs1.univ-pau.fr
 *  for version 2.2:
 *    EOST, Strasbourg, France: Celine Girard
 *  for versions 2.*:
 *    EOST, Strasbourg, France: Marc Schaming, mschaming@eost.u-strasbg.fr
 *
 *  For any problems, send message to mschaming@eost.u-strasbg.fr
 *--------------------------------------------------------------------
 * SEGDREAD: Version 2.1, 10/10/94
 *           Version 2.2, 17/08/95
 *           Version 2.3,  04/1997 Thu Apr 10 11:55:45 DFT 1997
 *--------------------------------------------------------------------
 * Rainer Herbst: Added - F8048 SEG-D format support  9 Jan 1998
 * Caveat: seems to work only on HP systems at the moment.
 */
/**************** end self doc ***********************************/

/* subroutine prototypes */
static int bcd (unsigned char *ptr, int begin, int n) ;            
static void F8015_to_float (short from[], float to[], int len);
static void F8048_to_float (short from[], float to[], int len);
void info_gh1(general_header_1 * gh1) ;
void info_gh2(general_header_2 * gh2) ;
void info_ghn(general_header_n * ghn) ;
void info_gn_sn358(gen_head_sn358 * gh358);
void info_csh(channel_set_header * csh) ;
void info_ssh(sample_skew * ssh) ;
void info_ech(extended_header * ech);
void info_exh(external_header * exh);
void info_dth(dem_trace_header * dth);
void info_gt(general_trailer * gt);

segy tr;

int
main(int argc, char **argv)
{
 general_header_1   segd_general_header_1;
 general_header_2   segd_general_header_2;
 general_header_n   segd_general_header_n;
 gen_head_sn358     segd_gen_head_sn358;
 channel_set_header segd_channel_set_header;
 sample_skew        segd_sample_skew;
 extended_header    segd_extended_header;
 external_header    segd_external_header;
 general_trailer    segd_general_trailer;
 dem_trace_header   segd_dem_trace_header;
 trace_header_ext   segd_trace_header_ext;

 channel_set_header **csd = NULL;
			/* array[n_str][n_cs] of channel_set_header */

 char *tape=NULL;        /* name of raw tape device */
 int tapefd=0;           /* file descriptor for tape */
 FILE *tapefp=NULL;      /* file pointer for tape */

 short scan_type;        /* scan type number */
 short chan_set;         /* channel set number */

 register int i, j;
 register int i_scan, i_cs, i_tr;
 int i_ss;
 int nread;              /* bytes read */
 int ns;                 /* number of data samples */
 int n_gh;        	 /* number of additional blocks in general header */
 int n_str;              /* number of scan types per record */
 int n_cs;               /* number of channel sets per scan type */ 
 int n_sk;               /* number of 32 byte field for sample skew */
 int n_ec;               /* extended header length */
 int n_ex;                                /* external header length */
 int n_gt=0;                   /* number of blocks of general trailer */
 int n_chan;                            /* total number of channels */
 int itr;                                   /* current trace number */
 int ipt;                                    /* current shot number */
 int ptmin;                                  /* first trace to read */
 int ptmax;                                   /* last trace to read */
 int verbose;                   /* echo every ...                   */
 int vblock;                    /* ... vblock traces with verbose=1 */
 int buff;                   /* flag for buffered/unbuffered device */
 int gain;                                /* flag for applying gain */
 int aux;                      /* flag for keeping auxiliary traces */
 int errmax;                      /* max consecutive tape io errors */
 int errcount = 0;                    /* counter for tape io errors */

 float  mp;                                   /* descaling exponent */  
 float **mmp = NULL;    /* array[n_cs][n_str] for escaling exponent */

 char *bloc1;                              /* pointer on data block */
 

 /* Initialize */
 initargs(argc, argv);
 requestdoc(0); /* stdin not used */

 /* Make sure stdout is a file or pipe */
 switch(filestat(STDOUT)) {
 case TTY:
 	err("stdout can't be tty");
 break;
 case DIRECTORY:
 	err("stdout must be a file, not a directory");
 break;
 case BADFILETYPE:
 	err("stdout is illegal filetype");
 break;
 default: /* Others OK */
 break;
 }

 /* Set filenames */
 MUSTGETPARSTRING("tape",  &tape);

 /* Set parameters */
 if (!getparint("ptmin", &ptmin))        ptmin = 1;
 if (!getparint("ptmax", &ptmax))        ptmax = INT_MAX;
 if (!getparint("verbose", &verbose))    verbose = 0;
 if (verbose==2) {ptmax=ptmin; warn("ptmax set to ptmin for verbose=2");}
 if (!getparint("vblock", &vblock))      vblock = 50;
 if (!getparint("buff", &buff))          buff = 1;
 if (!getparint("gain", &gain))          gain = 0;
 if (!getparint("aux", &aux))            aux = 0;
 if (!getparint("errmax", &errmax))      errmax = 0;

 /* Allocate space for the record block */
 if ((bloc1 = alloc1(REC_L, sizeof(char))) == NULL) err("error at bloc1 allocation");
 if ((unsigned long) bloc1 % 2)
	warn("there may be a problem since bloc1 is not on a short boundary (%ul)",(unsigned long) bloc1);

 /* Open the tape */
 if (buff) tapefd = eopen(tape, O_RDONLY, 0444);
 else      tapefp = efopen(tape, "r");
 if (verbose) warn("tape opened successfully");

 /* Read the traces */
 ipt = 0;    /*current shot number */
 itr = 0;    /*current trace number */
 while (ipt < ptmax) {

 	/************************
 	* Read the Header Block *
 	************************/
 
 	if (buff) {
 		if (-1 == (nread = (int) read(tapefd, (void *) bloc1, (size_t) REC_L))){
 			if (verbose)
 				warn("tape read error on header block from shot %d", (ipt+1));
 			if (++errcount > errmax)
 				err("exceeded maximum io errors");
 		} else { /* Reset counter on successful tape IO */
 			errcount = 0;
 		}
 	} else {
 		nread = (int) fread(bloc1, 1, REC_L, tapefp);
 		if (ferror(tapefp)) {
 			if (verbose)
 				warn("tape read error on header block from shot %d", (ipt+1));
 			if (++errcount > errmax)
 				err("exceeded maximum io errors");
 			clearerr(tapefp);
 		} else { /* Reset counter on successful tape IO */
 			errcount = 0;
 		}
 	}
 	if (!nread) break; /* middle exit loop instead of mile-long while */

 	/* General Header #1 */

 	(void) memcpy (&segd_general_header_1, bloc1, 32);
 	bloc1 += 32;
 	tr.fldr =   bcd ((unsigned char *) &segd_general_header_1.f, 0, 4);
 	tr.year =   1900 + bcd ((unsigned char *) &segd_general_header_1.yr, 0, 2);
 	n_gh =      segd_general_header_1.gh_dy1 >> 4;
 	tr.day =    bcd ((unsigned char *) &segd_general_header_1.gh_dy1, 1, 3);
 	tr.hour =   bcd ((unsigned char *) &segd_general_header_1.h, 0, 2);
 	tr.minute = bcd ((unsigned char *) &segd_general_header_1.mi, 0, 2);
 	tr.sec =    bcd ((unsigned char *) &segd_general_header_1.se, 0, 2);
 	tr.dt =     (segd_general_header_1.i*1000) >> 4;
 	n_str =     bcd ((unsigned char *) &segd_general_header_1.str, 0, 2);
 	n_cs =      bcd ((unsigned char *) &segd_general_header_1.cs, 0, 2);
 	n_sk =      bcd ((unsigned char *) &segd_general_header_1.sk, 0, 2);
 	n_ec =      bcd ((unsigned char *) &segd_general_header_1.ec, 0, 2);
 	n_ex =      bcd ((unsigned char *) &segd_general_header_1.ex, 0, 2);

 	if (verbose==2) info_gh1(&segd_general_header_1);

 	/* Additional general headers */

 	if((n_gh == 2) && (segd_general_header_1.m[0] == 0x13)) { /* Special case for Sercel SN358 */
 		(void) memcpy (&segd_gen_head_sn358, bloc1, 64);
 		bloc1 += 64;
 		if (verbose==2) info_gn_sn358(&segd_gen_head_sn358);
 	}
 	else {
 		for (i = 0; i < n_gh; i++) {
 			if (i == 0) {

 				/* General header #2 */

 				(void) memcpy (&segd_general_header_2, bloc1, 32);
 				if (tr.fldr == BCD_FFFF) tr.fldr = 65536 * segd_general_header_2.ef[0] +
					256 * segd_general_header_2.ef[1] + segd_general_header_2.ef[2];
 				if (n_cs == BCD_FF) n_cs = 256 * segd_general_header_2.en[0] + segd_general_header_2.en[1];
 				if (n_ec == BCD_FF) n_ec = 256 * segd_general_header_2.ecx[0] + segd_general_header_2.ecx[1];
 				if (n_ex == BCD_FF) n_ex = 256 * segd_general_header_2.eh[0] + segd_general_header_2.eh[1];
 				n_gt = segd_general_header_2.gt;
 				if (verbose==2) info_gh2(&segd_general_header_2);
 			}
 			else {

 				/* General header #n */

 				(void) memcpy (&segd_general_header_n, bloc1, 32);
 				if (verbose==2) info_ghn(&segd_general_header_n);
 			}
 			bloc1 += 32;
 	 	}
 	}

 	/* Verify the length of the first record */ 
 	if (nread != ((1 + n_gh + n_str * (n_cs + n_sk) + n_ec + n_ex) * 32))
 		err("Error with length of first record\n"
 			"\t... first record = %d bytes differs from ((1 + n_gh + n_str * (n_cs + n_sk) + n_ec + n_ex) * 32)\n"
 			"\t    with n_gh=%d, n_str=%d, n_cs=%d, n_sk=%d, n_ec=%d, n_ex=%d\n",
 			nread, n_gh, n_str, n_cs, n_sk, n_ec, n_ex);

 	/* Allocate space for array csd */
	if (csd == NULL)
 		if ((csd = (channel_set_header **) alloc2 ((size_t) n_cs, (size_t) n_str, (size_t) sizeof(channel_set_header))) == NULL)
 			err("error at csd allocation");

 	/* if gain allocate space for mmp array */
 	if (gain && (mmp == NULL)) 
 		if ((mmp = (float **) alloc2float ((size_t) n_cs, (size_t) n_str)) == NULL)
 			err("error at mmp allocation");

 	/* For each scan type */

 	n_chan = 0;
 	for (i_scan = 0; i_scan < n_str; i_scan ++) {

 		/* For each channel set */

 		for (i_cs = 0; i_cs < n_cs; i_cs ++) {
 			(void) memcpy (&csd[i_scan][i_cs], bloc1, 32);
 			segd_channel_set_header = csd[i_scan][i_cs];
 			bloc1 += 32;
 			n_chan += bcd((unsigned char*) &segd_channel_set_header.cs, 0, 4);
 			if (gain) {
 				mp = ((float) ((segd_channel_set_header.mp[1] & 0x7f) << 8 | segd_channel_set_header.mp[0])) / 1024.;
 				if (segd_channel_set_header.mp[1] >> 7) mp *= -1.;
 				mmp[i_scan][i_cs] = pow ((double) 2., (double) mp);

 				/* For the seismic traces */
 				if (verbose && segd_channel_set_header.c == 0x10)
 					warn("Multiplier value for channel set %d of scan type %d is : %7.3e", i_cs, i_scan, mmp[i_scan][i_cs]);
 			}
 			if (verbose==2) info_csh(&segd_channel_set_header);
 		}

 		/* Sample skew header */
 		for (i_ss = 0; i_ss < n_sk; i_ss ++) {
 			(void) memcpy (&segd_sample_skew, bloc1, 32);
 			bloc1 += 32;
 			if (verbose==2) info_ssh(&segd_sample_skew);
 		}
 	}

 	/* Extended Header */
 	for (j = 0; j < n_ec; j ++) {
 		(void) memcpy (&segd_extended_header, bloc1, 32);
 		bloc1 += 32;
		/* Local decoding */
 		/* (void) sscanf(&segd_extended_header[11], "%2hd:%2hd:%2hd", &tr.hour, &tr.minute, &tr.sec); */
 		if (verbose==2) info_ech(&segd_extended_header);
 	}

 	/* External Header */
 	for (j = 0; j < n_ex; j ++) {
 		(void) memcpy (&segd_external_header, bloc1, 32);
 		bloc1 += 32;
 		if (verbose==2) info_exh(&segd_external_header);
 	}
 	if (verbose==2) warn ("there are %d channels", n_chan);

 	/*************************
 	* Read the n_chan traces *
 	*************************/

 	for (i_tr=0; i_tr<n_chan; i_tr++) {

 		if (buff) {
 			if (-1 == (nread = (int) read(tapefd, (void *) bloc1, (size_t) REC_L))){
 				if (verbose)
 					warn("tape read error on trace %d", itr);
 				if (++errcount > errmax)
 					err("exceeded maximum io errors");
 			} else { /* Reset counter on successful tape IO */
 				errcount = 0;
 			}
 		} else {
 			nread = (int) fread(bloc1, 1, REC_L, tapefp);
 			if (ferror(tapefp)) {
 				if (verbose)
 					warn("tape read error on trace %d", itr);
 				if (++errcount > errmax)
 					err("exceeded maximum io errors");
 				clearerr(tapefp);
 			} else { /* Reset counter on successful tape IO */
 				errcount = 0;
 			}
 		}

 		if (!nread) break; /* middle exit loop instead of mile-long while */

 		if (ipt >= ptmin-1) {
 			if (!(segd_general_header_1.y & 0x8000)) { /* multiplexed data */
				/* decode data regarding the format */
 				switch (segd_general_header_1.y) { 
 					case 0x0015:                           /* 20 bit binary multiplexed */
 						err("Format 0015 (20 bit binary multiplexed) not yet implemented"); break;
 					case 0x0022:                        /* 8 bit quaternary multiplexed */
 						err("Format 0022 (8 bit quaternary multiplexed) not yet implemented"); break;
 					case 0x0024:                       /* 16 bit quaternary multiplexed */
 						err("Format 0024 (16 bit quaternary multiplexed) not yet implemented"); break;
 					case 0x0036:           /* 24 bit 2's compliment integer multiplexed */
 						err("Format 0036 (24 bit 2's compliment integer multiplexed) not yet implemented"); break;
 					case 0x0038:           /* 32 bit 2's compliment integer multiplexed */
 						err("Format 0038 (32 bit 2's compliment integer multiplexed) not yet implemented"); break;
 					case 0x0042:                       /* 8 bit hexadecimal multiplexed */
 						err("Format 0042 (8 bit hexadecimal multiplexed) not yet implemented"); break;
 					case 0x0044:                      /* 16 bit hexadecimal multiplexed */
 						err("Format 0044 (16 bit hexadecimal multiplexed) not yet implemented"); break;
 					case 0x0048:                      /* 32 bit hexadecimal multiplexed */
 						err("Format 0048 (32 bit hexadecimal multiplexed) not yet implemented"); break;
 					case 0x0058:                             /* 32 bit IEEE multiplexed */
 						err("Format 0058 (32 bit IEEE multiplexed) not yet implemented"); break;
 					case 0x0200:                                             /* illegal */
 						err("Format 0200 illegal, do not use"); break;
 					case 0x0000:                                             /* illegal */
 						err("Format 0000 illegal, do not use"); break;
 					default:
 						err("Data format code: %04x not recognized",segd_general_header_1.y);
 				}
 			}
 			else { /* demultiplexed data */
 				(void) memcpy (&segd_dem_trace_header, bloc1, 20);
				bloc1 += 20;
 				if (verbose==2) info_dth(&segd_dem_trace_header);
 				scan_type = bcd ((unsigned char *) &segd_dem_trace_header.st, 0, 2) -1;
 				chan_set = bcd ((unsigned char *) &segd_dem_trace_header.cn, 0, 2) -1;
				for (i=0; i < segd_dem_trace_header.the; i++) { /* read the trace header extension blocks */
					(void) memcpy (&segd_trace_header_ext, bloc1, 32);
					bloc1 += 32;
				warn ("segd_dem_trace_header.the = %d", segd_dem_trace_header.the);
				}

 				/* if aux = 0, skip auxiliary channels */
 				if (aux==0 && csd[scan_type][chan_set].c != 0x10) continue;

  				/* set trace identification code from channel type */
 				switch (csd[scan_type][chan_set].c) {
 					case 0xc0: tr.trid = TDUMMY; break; /* Auxiliary data trailer */
 					case 0x90: tr.trid = TDUMMY; break; /* Signature, filtered */
 					case 0x80: tr.trid = TDUMMY; break; /* Signature, unfiltered */
 					case 0x70: tr.trid = TDUMMY; break; /* Other */
 					case 0x60: tr.trid = TDUMMY; break; /* External data */
 					case 0x50: tr.trid = TIMING; break; /* timing traces */
 					case 0x40: tr.trid = WBREAK; break; /* Water break traces */
 					case 0x30: tr.trid = UPHOLE; break; /* Uphole traces */
 					case 0x20: tr.trid = TBREAK; break; /* Time break traces*/
 					case 0x10: tr.trid = TREAL;  break; /* Real time traces*/
 					case 0x00: tr.trid = TDUMMY; break; /* Unused */
 					default: tr.trid = TDUMMY; warn("channel type %02x unknown", csd[scan_type][chan_set].c); break;
 				}

 				tr.tracf = bcd ((unsigned  char *) &segd_dem_trace_header.tn, 0, 4);
 				tr.delrt = csd[scan_type][chan_set].tf * 2;

				/* decode data regarding the format */
 				switch (segd_general_header_1.y) { 
 					case 0x8015:                        /* 20 bits binary demultiplexed */
 						tr.ns = ((nread-20)*4)/10; /* number of samples from block length */
 						ns = tr.ns/4;
 						F8015_to_float ((short *) bloc1, (float *) tr.data, ns); break;
 					case 0x8022:                      /* 8 bit quaternary demultiplexed */
 						err("Format 8022 (8 bit quaternary demultiplexed) not yet implemented"); break;
 					case 0x8024:                      /* 16 bit quaternary demultiplexed */
 						err("Format 8024 (16 bit quaternary demultiplexed) not yet implemented"); break;
 					case 0x8036:          /* 24 bit 2's compliment integer demultiplexed */
 						err("Format 8036 (24 bit 2's compliment integer demultiplexed) not yet implemented"); break;
 					case 0x8038:          /* 32 bit 2's compliment integer demultiplexed */
 						err("Format 8038 (32 bit 2's compliment integer demultiplexed) not yet implemented"); break;
 					case 0x8042:                      /* 8 bit hexadecimal demultiplexed */
 						err("Format 8042 (8 bit hexadecimal demultiplexed) not yet implemented"); break;
 					case 0x8044:                     /* 16 bit hexadecimal demultiplexed */
 						err("Format 8044 (16 bit hexadecimal demultiplexed) not yet implemented"); break;
/*Changed R.Herbst 12.12.97*/
 					case 0x8048:                     /* 32 bit hexadecimal demultiplexed */
		warn("Format 8048 probably only supported on HP");
 						tr.ns = (nread-20)/4;
 						ns = nread;
 						F8048_to_float ((short *) bloc1, (float *) tr.data, ns); break; 					
/* end changes R.H.*/ 					
 					case 0x8058:                            /* 32 bit IEEE demultiplexed */
 						err("Format 8058 (32 bit IEEE demultiplexed) not yet implemented"); break;
 					default:
 						err("Data format code: %04x not recognized",segd_general_header_1.y);
 				}

  				/* Apply gain if requested */
 				if (gain) {
 					for (i = 0; i<tr.ns; i++)
 						tr.data[i] *= mmp[scan_type][chan_set];
 				}

 				/* Write the trace */
 				puttr(&tr);

 				/* Echo under verbose option */
 				if (verbose && ++itr % vblock == 0)
 					warn(" %d traces from tape", itr);

 			}
 		}
 	}

 	/***************************
 	* Read the General Trailer *
 	***************************/

 	for (j = 0; j < n_gt; j ++) {
 		(void) memcpy (&segd_general_trailer, bloc1, 32);
 		bloc1 += 32;
 		if (verbose==2) info_gt(&segd_general_trailer);
 	}
 
 	/* EOF = end of shot */
 	if (buff) {
 		if (-1 == (nread = (int) read(tapefd, (void *) bloc1, (size_t) REC_L))){
 			if (verbose)
 				warn("tape read error on header block from shot %d", (ipt+1));
 			if (++errcount > errmax)
 				err("exceeded maximum io errors");
 		} else { /* Reset counter on successful tape IO */
 			errcount = 0;
 		}
 	} else {
 		nread = (int) fread(bloc1, 1, REC_L, tapefp);
 		if (ferror(tapefp)) {
 			if (verbose)
 				warn("tape read error on header block from shot %d", (ipt+1));
 			if (++errcount > errmax)
 				err("exceeded maximum io errors");
 			clearerr(tapefp);
 		} else { /* Reset counter on successful tape IO */
 			errcount = 0;
 		}
 	}
 	if (nread) warn("not at EOF as should be!");
 	ipt++ ;
 }

 /* Clean up */
 ipt = ipt - ptmin + 1;
 if (verbose) warn ("%d shots (%d traces) from tape", ipt, itr);
 (buff) ? eclose(tapefd):
 	efclose(tapefp);
 if (verbose) warn("tape closed successfully");
 free2float (mmp);
 free2 ((void **) csd);

 return EXIT_SUCCESS;
}

/* bcd - convert bcd to int
 *
 * Credits:
 *      EOPG: Marc, Jdt
 *
 * Parameters:
 *    ptr    - address of first byte of the number
 *    begin  - 0 or 1, position of the first digit of the number
 *    n      - number of digits
 *
 */

static int bcd (unsigned char *ptr , int begin , int n)
{
 register int i;
 unsigned int val;

 val = 0;
 if (n == 0) return (val);

 for (i = 0; i<n; i++) {
 	val *= 10;
 	if (begin++ & 1) val += (*ptr++ & 0xf); 
 	else val += (*ptr >> 4) & 0xf;
 }
 return (val);
}

/* F8015_to_float - convert 20 bits binary demultiplexed data into IEEE floating numbers
 *
 * Credits:
 *      EOPG: Marc Schaming, Jean-Daniel Tissot
 *
 * Parameters:
 *    from   - input vector
 *    to     - output vector
 *    len    - number of packets of 4 floats in vectors
 *
 */
static void F8015_to_float (short from[], float to[], int len)
{
 register int i;
 register short ex1_4;
 int expo;

 for (i = 0; i <= len; i++) {
 	ex1_4 = *(from++);
 	expo = ((ex1_4 >> 12) & 0x0F) - 15;
 	*(to++) = *(from++) * pow ((double) 2., (double) expo);

 	expo = ((ex1_4 >> 8) & 0x0F) - 15;
 	*(to++) = *(from++) * pow ((double) 2., (double) expo);

 	expo = ((ex1_4 >> 4) & 0x0F) - 15;
 	*(to++) = *(from++) * pow ((double) 2., (double) expo);

 	expo = (ex1_4 & 0x0F) - 15;
 	*(to++) = *(from++) * pow ((double) 2., (double) expo);
 }
} 

/* Begin additions R.Herbst 07.01.97 */
/* F8048_to_float - convert 32 bits hexadecimal demultiplexed data into IEEE floating numbers
 *
 * Credits:
 *      EOPG: Marc Schaming, Jean-Daniel Tissot
 *
 * Parameters:
 *    from   - input vector
 *    to     - output vector
 *    len    - number of packets of 4 floats in vectors
 *
 */
static void F8048_to_float (short from[], float to[], int len)
{
  unsigned short wort1;
  unsigned short wort2;
  signed short zeichen=1;
  short expo;
  double mantisse;	
  register int i, k;

 for (i = 0; i <= len; i++) {
 	wort1 = *(from++);
 	wort2 = *(from++);
 	switch ((wort1 >> 15 ) & 0x01) {
 	  	case 0 : zeichen = 1; break;
 	  	case 1 : zeichen = -1; break;
 	  	default : warn("Error in bit-wise shifting, see source code"); 
 	  		break;
 	  	}
 	expo = ((wort1 >> 8) & 127) - 64  ;
 	mantisse = 0.0;
	for (k=0; k<2; k++) {
		mantisse = mantisse + ((wort1 >> (4-4*k)) & 15) * (pow ( 16., (-k-1)));
	} 
	for (k=0; k<4; k++) {
		mantisse = mantisse + ((wort2 >> (12-4*k)) & 15) * (pow ( 16., (-k-3)));
	}
	*(to++) = (float) (zeichen * mantisse * pow (16., expo));
    }
} 

/* end changes R.H */

void info_gh1(general_header_1 * gh1)
{
int n_gh, n_str, n_cs;
 n_gh = (*gh1).gh_dy1 >> 4;
 n_str = bcd ((unsigned char *)  (*gh1).str, 0, 2);
 n_cs = bcd ((unsigned char *) (*gh1).cs, 0, 2);

 warn("\n********************************\n"
 	"segd_general_header_1 (%2d bytes)\n"
 	"********************************", sizeof(*gh1));
 warn("file number: %d", tr.fldr);
 warn("\t\tformat code: %d\n", bcd ((unsigned char *) &(*gh1).y, 0, 4));
 warn("general constants K1-K12 not decoded");
 warn("\t\tyear: %d\n", tr.year - 1900);
 warn("#blks in general header extension: %d\n", n_gh);
 warn("day: %02d", tr.day);
 warn("\t\thour: %02d", tr.hour);
 warn("\t\tminute: %02d", tr.minute);
 warn("\t\tsecond: %02d\n", tr.sec);
 warn("manufacturer s code: %2x", (*gh1).m[0]);
 warn("\t\tmanufacturer's serial number: %02x%02x\n", (*gh1).m[1], (*gh1).m[2]);
 warn("bytes per scan (multiplexed formats) : not decoded");
 warn("\t\tbase scan interval: %d microseconds\n", tr.dt);
 warn("polarity: %x", (*gh1).p_sbx >> 4);
 warn("\t\tscan/block: %d x 2 **%d\n", (*gh1).sb, ((*gh1).p_sbx & 0xff));
 warn("record type (8=normal record) : %x", (*gh1).z_r1 >> 4);
 warn("\t\trecord length: %d units\n", bcd ((unsigned char *) &(*gh1).z_r1, 1, 3));
 warn("scan types / records: %d", n_str);
 warn("\t\tchannel sets per scan type: %d\n", n_cs);
 warn("number of 32-bytes fields for sample skew: %x\n", (*gh1).sk);
 warn("extended header length: %x", (*gh1).ec);
 warn("\t\texternal header length: %x\n", (*gh1).ex);
}

void info_gh2(general_header_2 *gh2)
{
 warn("\n********************************\n"
 	"segd_general_header_2 (%2d bytes)\n"
 	"********************************\n", sizeof(*gh2));
 warn("expanded file number: %2x%2x%2x\n", (*gh2).ef[0], (*gh2).ef[1], (*gh2).ef[1] );    
 warn("extended channel sets/scantype: %02x%02x\n", (*gh2).en[0], (*gh2).en[1]);
 warn("extended header blocks: %02x%02x\n", (*gh2).ecx[0], (*gh2).ecx[1] );
 warn("external header blocks: %02x%02x\n", (*gh2).eh[0], (*gh2).eh[1]);
 warn("seg-d revision number: %02x%02x\n", (*gh2).rev[0], (*gh2).rev[1]);
 warn("general trailer number of blocks:  %d\n", (*gh2).gt);
 warn("extended record length: %02x%02x%02x\n", (*gh2).erl[0], (*gh2).erl[1], (*gh2).erl[2]); 
}

void info_ghn(general_header_n *ghn)
{
 warn("\n********************************\n"
 	"segd_general_header_n (%2d bytes)\n"
 	"********************************\n", sizeof(*ghn));
 warn("source line number: %02x%02x%02x%02x%02x\n", (*ghn).sln[0], (*ghn).sln[1], (*ghn).sln[2], (*ghn).sln[3], (*ghn).sln[4]);
 warn("source point number: %02x%02x%02x%02x%02x\n", (*ghn).spn[0], (*ghn).spn[1], (*ghn).spn[2], (*ghn).spn[3], (*ghn).spn[4]);
 warn("source point index: %2x\n", (*ghn).spi);
 warn("phase control: %2x\n", (*ghn).pc);
 warn("vibrator type: %2x\n", (*ghn).v);
 warn("phase angle:  %d\n", bcd ((unsigned char*) &(*ghn).pa, 0, 4));
 warn("general header block number: %2x\n", (*ghn).bn);
 warn("source set number: %2x\n", (*ghn).ss);
}

void info_gn_sn358(gen_head_sn358 * gh358)
{
 warn("\n************************************\n"
 	"segd_general_header_sn358 (%2d bytes)\n"
 	"************************************\n", sizeof(*gh358));
 warn("first channel of seismic parameter set 1: 1");
 warn("\tlast1: %d\n", bcd ((unsigned char*) &(*gh358).fc1, 1, 3));
 warn("first channel of seismic parameter set 2: %d", bcd ((unsigned char*) &(*gh358).fc2, 0, 3));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).f_lc2, 1, 3));
 warn("first channel of seismic parameter set 3: %d", bcd ((unsigned char*) &(*gh358).fc3, 0, 3));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).f_lc3, 1, 3));
 warn("first channel of seismic parameter set 4: %d", bcd ((unsigned char*) &(*gh358).fc4, 0, 3));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).f_lc4, 1, 3));
 warn("first auxiliary channel of scan type 1: %d", bcd ((unsigned char*) &(*gh358).f_lac1, 0, 1));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).f_lac1, 1, 1));
 warn("first seismic channel of scan type 1: %d", bcd ((unsigned char*) &(*gh358).fsc1, 0, 3));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).f_lsc1, 1, 3));
 warn("sample interval of scan type 1: %d\n", ((*gh358).sam_int1*1000) >> 4);
 warn("first auxiliary channel of scan type 2: %d", bcd ((unsigned char*) &(*gh358).fac2, 0, 1));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).fac2, 1, 1));
 warn("first seismic channel of scan type 2: %d", bcd ((unsigned char*) &(*gh358).fsc2, 0, 3));
 warn("\tlast: %d\n", bcd ((unsigned char*) &(*gh358).f_lsc2, 1, 3));
 warn("sample interval of scan type 2: %d\n", ((*gh358).sam_int2*1000) >> 4);
 warn("signature length: %3.1f", ((*gh358).bl_sig_le*.1));
 warn("\trecord length: %4.1f\n", bcd((unsigned char*) &(*gh358).rec_length, 1, 3)*.1);
 warn("dynamically switching delay: %4.1f", bcd((unsigned char*) &(*gh358).dyn_swit_del, 1, 3)*.1);
 warn("\trecording delay: %4.1f\n", bcd((unsigned char*) &(*gh358).rec_del, 1, 3)*.1);
 warn("type of auxiliary channels 1 to 8: %1d %1d %1d %1d %1d %1d %1d %1d\n", 
 	bcd ((unsigned char*) &(*gh358).ty_a_cha12, 0, 1), bcd ((unsigned char*) &(*gh358).ty_a_cha12, 1, 1),
 	bcd ((unsigned char*) &(*gh358).ty_a_cha34, 0, 1), bcd ((unsigned char*) &(*gh358).ty_a_cha34, 1, 1),
 	bcd ((unsigned char*) &(*gh358).ty_a_cha56, 0, 1), bcd ((unsigned char*) &(*gh358).ty_a_cha56, 1, 1),
 	bcd ((unsigned char*) &(*gh358).ty_a_cha78, 0, 1), bcd ((unsigned char*) &(*gh358).ty_a_cha78, 1, 1));
 warn("mode number: %d", bcd ((unsigned char *) &(*gh358).mode_num, 0, 2));
 warn("\tanalog system count: %d", bcd ((unsigned char *) &(*gh358).an_sys_co, 0, 1));
 warn("\ttape transport number: %d\n", bcd ((unsigned char *) &(*gh358).an_sys_co, 1, 1));
 warn("reel number: %d", bcd ((unsigned char*) &(*gh358).reel_num, 0, 4));
 warn("\tfile logicial number: %d", bcd ((unsigned char*) &(*gh358).file_num, 1, 3));
 warn("\tshot point number: %d\n",  bcd ((unsigned char*) &(*gh358).sp_num, 0, 4));
 warn("LC=%d, NF=%d, FG=%d, IC=%d\n", bcd ((unsigned char *)&(*gh358).lc_nf, 0, 1), bcd (&(*gh358).lc_nf, 1, 1),
 	bcd (&(*gh358).fg_ic, 0, 1), bcd ((unsigned char *)&(*gh358).fg_ic, 1, 1));
 warn("oscillator frequency: %d", bcd ((unsigned char *)&(*gh358).of1, 1, 5));
 warn("\toscillator amplitude: %d\n", bcd ((unsigned char *)&(*gh358).osc_att, 0, 2));
 warn("test signal: %d", bcd ((unsigned char *)&(*gh358).t_sig_ph, 1, 1));
 warn("\tmain gain amplifier: %d\n", bcd ((unsigned char *)&(*gh358).m_gain, 0, 2));
}

void info_csh(channel_set_header *csh)
{
 warn("\n**********************************\n"
 	"segd_channel_set_header (%2d bytes)\n"
 	"**********************************\n", sizeof(*csh));
 warn("scan type number: %2x", (*csh).st);
 warn("\tchannel set number: %2x\n", (*csh).cn);
 warn("channel set start time: %d", (*csh).tf*2 );
 warn("\tchannel set end time: %d\n", (*csh).te*2 );
 warn("descale multiplier: %02x%02x\n", (*csh).mp[0], (*csh).mp[1]);
 warn("number of channels: %d", bcd((unsigned char*) &(*csh).cs, 0, 4));
 warn("\tchannel type (1=Seis, 8=Sig/unfiltered): %x\n", (*csh).c >> 4);
 warn("sample/channel: %x", (*csh).sc_j >> 4);
 warn("\tchannel gain: %x\n", (*csh).sc_j & 0xf);
 warn("alias filter frequency: %d", bcd ((unsigned char*) &(*csh).af, 0, 4));
 warn("\talias filter slope: %d\n" , bcd ((unsigned char*) &(*csh).as, 1, 3));
 warn("low cut filter frequency: %d", bcd ((unsigned char*) &(*csh).lc, 0, 4));
 warn("\tlow cut filter slope: %d\n", bcd ((unsigned char*) &(*csh).ls, 1, 3));
 warn("first notch filter: %d", bcd ((unsigned char*) &(*csh).nt[0], 0, 4));
 warn("\tsecond: %d", bcd ((unsigned char*) &(*csh).nt[1], 0, 4));
 warn("\tthird: %d\n", bcd ((unsigned char*) &(*csh).nt[2], 0, 4));
 warn("extended channel set number: %d", bcd ((unsigned char*) &(*csh).ecs, 0, 4));
 warn("\textended header flag: %x\n" , (*csh).efh >> 4);
 warn("vertical stack: %2x\n", (*csh).vs);
 warn("streamer cable number: %2x", (*csh).cab);
 warn("\tarray forming: %2x\n", (*csh).ary); 
}

void info_ssh(sample_skew *ssh)
{
 warn("\n**********************************\n"
 	"segd_sample_skew_header (%2d bytes)\n"
 	"**********************************\n", sizeof(*ssh));
 warn("not decoded\n");
}

void info_ech(extended_header * ech)
{
 register int i;
 warn("\n**********************************\n"
 	"segd_extended_header (%2d bytes)\n"
 	"**********************************\n", sizeof(*ech));
 for (i=0; i<sizeof(*ech); i+=4) {
 	warn("%4x %4x %4x %4x\n", *ech[i], *ech[i+1], *ech[i+2], *ech[i+3]);
 }
}

void info_exh(external_header * exh)
{
 register int i;
 char *ptr;
 ptr= (char *) exh;
 warn("\n*******************************\n"
 	"segd_external_header (%2d bytes)\n"
 	"*******************************\n", sizeof(*exh));
 for (i=0; i<sizeof(*exh); ) {
 	warn("%02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x %02x%02x\n",
		ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++],
		ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++], ptr[i++]);
 }
}

void info_dth(dem_trace_header * dth)
{
 warn("\n********************************\n"
 	"segd_dem_trace_header (%2d bytes)\n"
 	"********************************\n", sizeof(*dth));
 warn("file number: %x", (*dth).f);
 warn("\tscan type: %x, channel set: %x\n", (*dth).st, (*dth).cn);
 warn("trace_number: %x", (*dth).tn);
 warn("\tfirst timing word: %x%x%X\n", (*dth).t[0], (*dth).t[1], (*dth).t[2]);
 warn("trace header extension: %x", (*dth).the);
 warn("\tsample skew: %x", (*dth).ss);
 warn("\ttrace edit: %x\n", (*dth).tr);
 warn("time break window: %02x%02x%02x\n", (*dth).tw[0], (*dth).tw[1], (*dth).tw[2]);
 warn("extended channel set number: %x%x", (*dth).en[0], (*dth).en[1]);
 warn("\textended file number: %x%x%x\n", (*dth).efn[0], (*dth).efn[1], (*dth).efn[2]);
}

void info_gt(general_trailer * gt)
{
 warn("\n********************************\n"
 	"segd_general_traler (%2d bytes)\n"
 	"********************************\n", sizeof(*gt));
 warn("General trailer number: %d", (*gt).gt);
 warn("\tchannel type identification: %01x\n", (*gt).c >> 4);
}

