#! /bin/sh
# why - obscure joke

PATH=/bin:/usr/bin:/usr/ucb

exec echo "Because life is a transient"
