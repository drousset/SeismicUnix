/* Copyright (c) Colorado School of Mines, 1998.*/
/* All rights reserved.                       */

#include <stdio.h>
#include <string.h>
#include <math.h>
/* #include <stdlib.h> */
#include <malloc.h>

#define MAXSAMP 16384l   	/* max of 16Kbyte samples */
#define MAXTRACES 16384  	/* SEG-2 limit */
#define STRINGWIDTH 100  	/* allow up to 100 chars per keyword */
#define MAXKEYWORDS 100  	/* allow up to 100 keywords */
#define MAXPARMS 10      	/* allow up to 10 parameters/keyword (+parm0) */

short outhead[120];        	/* output traceheader */
long *outheadl;
float *outheadf;          	/* used when referencing outhead as a long array */
short i,j,k,ssn;
char string1[STRINGWIDTH];
FILE *f1,*f2;
long  *tracepointers;  
unsigned long numsamples,datalength;
char segykeyword[MAXKEYWORDS][STRINGWIDTH];
char input[STRINGWIDTH],inputbuf[STRINGWIDTH];
short segyfunction[MAXKEYWORDS],segyheader[MAXKEYWORDS],totalkeys;
double segyparms[MAXKEYWORDS][MAXPARMS];
short segyreelheader[1800]; /*reel header area for segy */
short first=1;
FILE *keyfile;
char *token;
short reverse;
double  *dinbuf;
long *linbuf;
short  *iinbuf;
float *finbuf;
unsigned char *cinbuf;
float *outbuf;
short blockid,revnum,pointerbytecount,numtrace;
unsigned short blockleng;
char stringtermcount,stringterm1,stringterm2;
char linetermcount,lineterm1,lineterm2;
char reserved[19];
short stringlength;
unsigned char datatype;

main(argc,argv)
short argc;
char **argv;
{
  short curf,lastf,ssn;
  size_t l,ln;
  float gain;
  char seg2file[20],segyfile[20],prefix[10],suffix[10],str[10];
  char *digits = "1234567890";
  
  tracepointers=(long *) calloc(MAXTRACES,4);
  outbuf=(float *) calloc(MAXSAMP,4);
  dinbuf=(double *) calloc(MAXSAMP,8);
  if ( tracepointers ==NULL  || outbuf ==NULL  || dinbuf==NULL) {
    printf("Unable to allocate necessary memory.\n");
    printf("Free up memory and try again.\n");
    exit(-1);
  }
  iinbuf=(short *) dinbuf;      /*used for integer input (16bit) */
  finbuf=(float *) dinbuf;    /*used for floating point (4 byte) */
  linbuf=(long *) dinbuf;     /*used for long int (32bit) */
  cinbuf=(unsigned char *) dinbuf;  /*used for 20bit packed. */
  outheadl=(long *) outhead;
  outheadf=(float *) outhead;
  
  if (argc < 3 || argc > 4) {
    printf("Usage: seg2segy first_seg2file number_of_files [shot_number]\n");
	exit(1);
  }
  strcpy(seg2file,argv[1]);
  if (strchr(seg2file,'.') == NULL) strcat(seg2file,".dat");
  l=strcspn(seg2file,".");
  strncpy(segyfile,seg2file,l); segyfile[l]='\0';
  strcpy(suffix,seg2file+l);
  l=strcspn(segyfile,digits);
  if (l==strlen(segyfile) || strspn(segyfile+l,digits)!=strlen(segyfile+l)) {
    printf("nom fichier seg2 %s invalide\n",seg2file);
	exit(2);
  }
  strncpy(prefix,segyfile,l); prefix[l]='\0';
  curf=atoi(segyfile+l);
  ln=strlen(segyfile+l);
  strcat(segyfile,".sgy");
  lastf=curf+atoi(argv[2])-1;
  if (argc==4) ssn=atoi(argv[3]); else ssn=1;

  f2=fopen(segyfile,"wb"); /*destroys file if present */
  if(f2 == NULL) {
    printf("**OUTPUT FILE OPEN FAILURE**\n     **ABORTING**\n");
    exit(3);
  }
  readsegykeys();  /*read in segy key words and save them */
  for (; curf<=lastf; curf++) {
    for (k=0; k<120; k++) outhead[k]=0;
    strcpy(seg2file,prefix);
    sprintf(str,"%d",curf);
    l=strlen(str);
    while(l<ln) { strcat(seg2file,"0"); l++; }
    strcat(seg2file,str);
    strcat(seg2file,suffix);
    f1=fopen(seg2file,"rb"); /*open the file for read-binary */
    if(f1 == NULL)  /*make sure it is there. */
      {
      printf("\n*** SYSTEM REPORTS ERROR OPENING FILE %s***\n",seg2file);
      printf("Skipping to next file number.\n");
      continue;  /*goto end of loop and try next one. */
    }
    fread(&blockid,2,1,f1);
    if(blockid != 0x3a55 && blockid != 0x553A) {
      printf("Not SEG-2 data can not continue\n");
      exit(1);
    }
    reverse=(blockid==0x553A ? 1 : 0 );
    fread(&revnum,2,1,f1);
    if (reverse) swapb((char *) &revnum,2);
    fread(&pointerbytecount,2,1,f1);
    if (reverse) swapb((char *) &pointerbytecount,2);
    fread(&numtrace,2,1,f1);
    if (reverse) swapb((char *) &numtrace,2);
    fread(&stringtermcount,1,1,f1);
    fread(&stringterm1,1,1,f1);
    fread(&stringterm2,1,1,f1);
    fread(&linetermcount,1,1,f1);
    fread(&lineterm1,1,1,f1);
    fread(&lineterm2,1,1,f1);
    fread(reserved,1,18,f1);
    if(numtrace > (pointerbytecount/4)) {
      printf("Number of traces greater than number of trace pointers.\n");
      printf("Number of pointers = %d\n",pointerbytecount/4);
      printf("Due to this inconsistency processing must stop\n");
      exit(1);
    }
    fread(tracepointers,4,numtrace,f1);
    for(j=0;j<numtrace;j++) {
      if(reverse) swapb((char *) &tracepointers[j],4);
    }
    fread(&stringlength,2,1,f1);  /*get length*/
    if (reverse) swapb((char *) &stringlength,2);
    while(0 != stringlength) { 
      fread(string1,1,stringlength-2,f1);
      keycheck();  /*call the key checking subroutine! Its assigns headers */
      fread(&stringlength,2,1,f1);
      if (reverse) swapb((char *) &stringlength,2);
    }
    for(j=0;j<numtrace;j++) {
      for (k=0; k<70; k++) outhead[k]=0;
      fseek(f1,tracepointers[j],0);
      fread(&blockid,2,1,f1);
      if((blockid != 0x4422) && (blockid != 0x2244)) {
        printf("Not SEG-2 data. Can not process %x\n",blockid);
        exit(4);
      }
      fread(&blockleng,2,1,f1); /*length of trace descriptor block */
      if (reverse) swapb((char *) &blockleng,2);
      fread(&datalength,4,1,f1);  /*length of data in bytes */
      if (reverse) swapb((char *) &datalength,4);
      fread(&numsamples,4,1,f1); /*number of samples */
      if (reverse) swapb((char *) &numsamples,4);
      if (numsamples >= MAXSAMP){
        printf("I'm sorry. Your data contains more samples than I can handle\n");
        exit(5);
      }
      fread(&datatype,1,1,f1);
      if(datatype > 5  || datatype < 1) {
        printf("Data type %d not available/valid\n",(short) datatype);
        break;
      }
      outhead[57]=numsamples;
      fread(reserved,1,19,f1);
      fread(&stringlength,2,1,f1);  /*get length*/
      if (reverse) swapb((char *) &stringlength,2);
      while(0 != stringlength) {
        fread(string1,1,stringlength-2,f1);
        keycheck();/*call the key checking subroutine! It assigns headers */
        fread(&stringlength,2,1,f1);
        if (reverse) swapb((char *) &stringlength,2);
      }
      fseek(f1,blockleng+tracepointers[j],0);
      switch(datatype) {
        case 1:
        fread(iinbuf,2,(short) numsamples,f1);
        for(k=0;k<numsamples;k++) {
          if(reverse) swapb((char *) &iinbuf[k],2);
          outbuf[k]=iinbuf[k];
        }
        break;
        case 2:
        fread(linbuf,4,(short) numsamples,f1);
        for(k=0;k<numsamples;k++) {
          if(reverse) swapb((char *) &linbuf[k],4);
          outbuf[k]=linbuf[k];
        }
        break;
        case 3: {
        unsigned short totalbytes,subpointer;
        unsigned short expo;
        long longdat;
        totalbytes=(numsamples*5)/2;
        fread(cinbuf,1,totalbytes,f1);
        if(reverse) for(i=0;i<totalbytes/2;i++) swapb((char *) &iinbuf[i],2);
        for(k=0; k<(numsamples);) {
          subpointer=(k/4)*5;
          expo=(unsigned) iinbuf[subpointer++];
          for(i=0;i<4;i++) {
            if(0x8000 & iinbuf[subpointer]) longdat= 0xffff8000;
            else longdat=0l;
            longdat= ( longdat | (long) iinbuf[subpointer++]) << (0x000f & expo);
            expo >>= 4;
            outbuf[k++]=longdat;
          }
        }
        break; }
        case 4:
        fread(finbuf,4,(short) numsamples,f1);
        for(k=0;k<numsamples;k++) {
          if(reverse) swapb((char *) &finbuf[k],4);
          outbuf[k]=finbuf[k];
        }
        break;
        case 5:
        fread(dinbuf,8,(short) numsamples,f1);
        for(k=0;k<numsamples;k++) {
          if(reverse) swapb((char *) &dinbuf[k],8);
          outbuf[k]=dinbuf[k];
        }
        break; 
      }
      if(outhead[15] == 0) outhead[15]=1;
      if(outheadf[59] == 0.0) gain=1.0; else gain=outheadf[59];
      for (k=0;k<numsamples;k++) outbuf[k]=outbuf[k]*gain/outhead[15];
      float_to_ibm(outbuf,outbuf,numsamples);
      float_to_ibm(&outheadf[58],&outheadf[58],2);
      if(outheadl[2]==0) outheadl[2]=curf;
      if(outhead[14] == 0) outhead[14]=1; /*seismic data. */
      outheadl[4]=ssn;
      if(j == numtrace-1) ssn=ssn+1;
      outhead[35]=-100;
      outheadl[9]= (outheadl[20]-outheadl[18])/100;
      if(first == 1) {
        first=0;
        segyreelheader[1606]=numtrace;
        segyreelheader[1608]=outhead[58];
        segyreelheader[1609]=outhead[58];
        segyreelheader[1610]=numsamples;
        segyreelheader[1611]=numsamples;
        segyreelheader[1612]=1;  /*floating point */
        if(reverse==0) {
          for(k=1600;k<1606;k+=2) swapb((char *) &segyreelheader[k],4);
          for(k=1606;k<1630;k++) swapb((char *) &segyreelheader[k],2);
          for(k=78;k<84;k++) swapb((char *) &outhead[k],2);
        }
        fwrite(segyreelheader,1,3600,f2); /*create the segy headers1. */
      }
      if(reverse==0) {
        for(k=0;k<7;k++) swapb((char *) &outheadl[k],4);
        for(k=9;k<17;k++) swapb((char *) &outheadl[k],4);
        for(k=18;k<22;k++) swapb((char *) &outheadl[k],4);
        for(k=58;k<60;k++) swapb((char *) &outheadl[k],4);
        for(k=14;k<18;k++) swapb((char *) &outhead[k],2);
        for(k=34;k<36;k++) swapb((char *) &outhead[k],2);
        for(k=44;k<78;k++) swapb((char *) &outhead[k],2);
        for(k=84;k<116;k++) swapb((char *) &outhead[k],2);
      }
      if(120 != (k=fwrite(outhead,2,120,f2))) {
        printf("Write failure during header write\n");
        exit(6);
      }
      if(reverse==0) for(k=0;k<numsamples;k++) swapb((char *) &outbuf[k],4);
      if((short)numsamples != (k=fwrite(outbuf,4,(short) numsamples,f2))) {
        printf("Write failure during trace write\n");
        exit(6);
      }
    }
    fclose(f1); /*close it */
  }
  fclose(f2);
  return;
}

readsegykeys()
{
  char keypath[STRINGWIDTH]; /*string for path to segykeyw.ord */
  strcpy(keypath, "segykeyw.ord");
  keyfile=fopen(keypath,"r");
  if(keyfile == NULL) {
    printf("segy keyword file  SEGYKEYW.ORD  not found. Can not continue\n");
    exit(7);
  }
  i=0;
  while(fgets(input,STRINGWIDTH,keyfile)) {
    j=0;
    if(strlen(input) > STRINGWIDTH) {
      printf("String too long!\n");
      exit(8);
    }
    if(input[0] == 42 || input[0] == '\n')  continue;
    strcpy(inputbuf,input); /* make a working copy of input */
    token= strtok(inputbuf," ");  /*search out space. */
    strncpy(&segykeyword[i][0],token,1+strlen(token));
    token = strtok(NULL," ");
    segyfunction[i] = atoi(token);  /*convert to value. */
    token = strtok(NULL," ");
    segyheader[i]= atoi(token);
    token = strtok(NULL," ");
    j=0;
    while(token != NULL) {
      segyparms[i][j]= atof(token);
      token = strtok(NULL," ");
      j++;
      if ( j > MAXPARMS ) {
        printf("Too many parameters in %s keyword\n",&segykeyword[i][0]);
        printf("No more than %d allowed per function\n",j-1);
        exit(9);
      }
    }
    i++;  	/*inc counter to keyword number */
  } 		/*end keyword string while loop */
  totalkeys= i;
}

keycheck()
{
  short matchfound;
  char string2[STRINGWIDTH];
  strcpy(string2,string1);
  matchfound=0;
  for(i=0;i<totalkeys;i++) {
    strcpy(string1,string2);
    if(0 == strncmp(string1,&segykeyword[i][0],strlen(&segykeyword[i][0]))) {
      matchfound=1;
      switch(segyfunction[i]) {
        case 0:
        break;
        case 1:
        token=strtok(string1," "); /*find first token which will be keyword */
        token = strtok(NULL," "); /*now we should be a number. */
        outhead[segyheader[i]-1]=(short) (atof(token)*segyparms[i][0]+0.5);
        break;
        case 2:
        token=strtok(string1," "); /*pointing to keyword. */
        token=strtok(NULL," ");/* token points to input char. */
        if(0 == strcmp("AS_ACQUIRED",token)) segyreelheader[segyheader[i]-1]=1;
        if(0 == strcmp("CDP_GATHER",token)) segyreelheader[segyheader[i]-1]=2;
        if(0 == strcmp("CDP_STACK",token)) segyreelheader[segyheader[i]-1]=4;
        if(0 == strcmp("COMMON_OFFSET",token)) segyreelheader[segyheader[i]-1]=3;
        if(0 == strcmp("COMMON_RECEIVER",token)) segyreelheader[segyheader[i]-1]=1;
        if(0 == strcmp("COMMON_SOURCE",token)) segyreelheader[segyheader[i]-1]=1;
        if(0 == strcmp("METERS",token)) segyreelheader[segyheader[i]-1]=1;
        if(0 == strcmp("FEET",token)) segyreelheader[segyheader[i]-1]=2;
        break;
        case 3:
        strncpy((char*) &segyreelheader[80*(segyheader[i]-1)],string1,80);
        break;
        case 4:
        token=strtok(string1," "); /*pointing to keyword. */
        outhead[segyheader[i]-1] = 1; /*assume its seismic */
        token=strtok(NULL," ");/* token points to input char. */
        if(0 == strcmp("SEISMIC_DATA",token)) outhead[segyheader[i]-1]=1;
        if(0 == strcmp("DEAD",token)) outhead[segyheader[i]-1]=2;
        if(0 == strcmp("TEST_DATA",token)) outhead[segyheader[i]-1]=3;
        if(0 == strcmp("UPHOLE",token)) outhead[segyheader[i]-1]=5;
        if(0 == strcmp("RADAR_DATA",token)) outhead[segyheader[i]-1]=1;
        break;
        case 5:
        token=strtok(string1," "); /*pointing to keyword. */
        if(segyheader[i] == 0) {
          short paramcount=1;
          short headindex;
          token=strtok(NULL," :");/* token points to input char. */
          while(token != NULL && paramcount < 10) {
            headindex=segyparms[i][paramcount]-1;
            outhead[headindex]=atoi(token)*segyparms[i][0];
            paramcount++;
            token=strtok(NULL," :");/* token points next input char. */
          }
        }
        if(segyheader[i] == 1) {
          short paramcount=1;
          short headindex;
          long *outpoint;
          token=strtok(NULL," ");/* token points to input char. */
          while(token != NULL && paramcount < 10) {
            headindex=segyparms[i][paramcount]-2;
            outpoint=(long *) &outhead[headindex];
            *outpoint= atol(token) * segyparms[i][0];
            paramcount++;
            token=strtok(NULL," ");/* token points next input char. */
          }
        }
        if(segyheader[i] == 2) {
          short paramcount=1;
          short headindex;
          long *outpoint;
          token=strtok(NULL," ");/* token points to input char. */
          while(token != NULL && paramcount < 10) {
            headindex=segyparms[i][paramcount]-1;
            outpoint=(long *) &outhead[headindex];
            *outpoint=(long) (atof(token)*segyparms[i][0]);
            paramcount++;
            token=strtok(NULL," ");/* token points next input char. */
          }
        }
        if(segyheader[i] == 3) {
          short paramcount=1;
          short headindex;
          float *outpoint;
          token=strtok(NULL," ");/* token points to input char. */
          while(token != NULL && paramcount < 10) {
            headindex=segyparms[i][paramcount]-1;
            outpoint=(float *) &outhead[headindex];
            *outpoint=atof(token)*segyparms[i][0];
            paramcount++;
            token=strtok(NULL," ");/* token points next input char. */
          }
        }
        break;
        case 6: {
        short day,year;
        token=strtok(string1," "); /*pointing to keyword. */
        token=strtok(NULL,"/");/* token points to input char. */
        day=atoi(token);
        token=strtok(NULL,"/");/* token points to input char. */
        if(0 == strcmp("FEB",token) || 0== strcmp("02",token)) day+=31;
        if(0 == strcmp("MAR",token) || 0== strcmp("03",token)) day+=59;
        if(0 == strcmp("APR",token) || 0== strcmp("04",token)) day+=90;
        if(0 == strcmp("MAY",token) || 0== strcmp("05",token)) day+=120;
        if(0 == strcmp("JUN",token) || 0== strcmp("06",token)) day+=151;
        if(0 == strcmp("JUL",token) || 0== strcmp("07",token)) day+=181;
        if(0 == strcmp("AUG",token) || 0== strcmp("08",token)) day+=212;
        if(0 == strcmp("SEP",token) || 0== strcmp("09",token)) day+=243;
        if(0 == strcmp("OCT",token) || 0== strcmp("10",token)) day+=273;
        if(0 == strcmp("NOV",token) || 0== strcmp("11",token)) day+=304;
        if(0 == strcmp("DEC",token) || 0== strcmp("12",token)) day+=334;
        token=strtok(NULL," ");/* token points to input char. */
        year=atoi(token);
        if(!year%4 && day>59) day+=1;
        outhead[segyheader[i]-1]=year;
        outhead[segyheader[i]]=day;
        break; }
        default:     /*case where function not found.. should never happen */
        printf("Function %d not defined.\n",segyfunction[i]);
        break;
      }
    }
  }
  if(!matchfound) printf("No match found for %s\n",string1);
  return;
}

float_to_ibm(long from[], long to[], long n)
{
    register long fconv, fmant, ii, t;

    for (ii=0;ii<n;++ii) {
        fconv = from[ii];
        if (fconv) {
            fmant = (0x007fffff & fconv) | 0x00800000;
            t = (long) ((0x7f800000 & fconv) >> 23) - 126;
            while (t & 0x3) { ++t; fmant >>= 1; }
            fconv = (0x80000000 & fconv) | (((t>>2) + 64) << 24) | fmant;
        }
        to[ii] = fconv;
    }
    return;
}

swapb(char *buf, short size)
{
  char tmp;

  switch (size) {
    case 2:
      tmp=buf[0]; buf[0]=buf[1]; buf[1]=tmp;
      break;
    case 4:
      tmp=buf[0]; buf[0]=buf[3]; buf[3]=tmp;
      tmp=buf[1]; buf[1]=buf[2]; buf[2]=tmp;
      break;
    case 8:
      tmp=buf[0]; buf[0]=buf[7]; buf[7]=tmp;
      tmp=buf[1]; buf[1]=buf[6]; buf[6]=tmp;
      tmp=buf[2]; buf[2]=buf[5]; buf[5]=tmp;
      tmp=buf[3]; buf[3]=buf[4]; buf[4]=tmp;
      break;
    default:
      break;
  }
  return;
}

