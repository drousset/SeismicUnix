/* Copyright (c) Colorado School of Mines, 2001.*/
/* All rights reserved.                       */

#include	"sfstdio.h"

/*	Junk all buffered data
**	Written by Kiem-Phong Vo
*/


#if __STD_C
int fpurge(reg FILE* f)
#else
int fpurge(f)
reg FILE*	f;
#endif
{
	reg Sfio_t*	sf;

	if(!(sf = SFSTREAM(f)))
		return -1;

	return sfpurge(sf);
}
