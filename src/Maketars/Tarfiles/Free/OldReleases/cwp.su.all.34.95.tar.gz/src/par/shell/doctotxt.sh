#! /bin/sh

STRIPPED=$CWPROOT/src/doc/Stripped


cd $STRIPPED

mkdir ../TXT

for i in *
do
	NAME=` echo $i | sed 's/\./ /g' | awk '{ print $1 }'`
	cp $i ../TXT/$NAME.txt
done

exit 0
