#! /bin/sh
# Clean up residue from runs

rm -f vfile*
rm -f t amp a1 b1 d21 d22 d23 d31 d32 d33
rm -f data* *.su *.ps junk* test*
