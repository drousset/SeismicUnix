/* Copyright (c) Colorado School of Mines, 2001.*/
/* All rights reserved.                       */

#include	"../FEATURE/sfio"
#include	"terror.h"
#include	<stdio.h>
