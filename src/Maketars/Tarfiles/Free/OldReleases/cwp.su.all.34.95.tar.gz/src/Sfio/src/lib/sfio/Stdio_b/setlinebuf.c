/* Copyright (c) Colorado School of Mines, 2001.*/
/* All rights reserved.                       */

#include	"sfstdio.h"

/*	Set line mode
**	Written by Kiem-Phong Vo
*/


#if __STD_C
int setlinebuf(reg FILE* f)
#else
int setlinebuf(f)
reg FILE*	f;
#endif
{
	reg Sfio_t*	sf;

	if(!(sf = SFSTREAM(f)))
		return -1;

	sfset(sf,SF_LINE,1);
	return(0);
}
